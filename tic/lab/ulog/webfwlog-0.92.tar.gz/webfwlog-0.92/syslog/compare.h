/* $Id: compare.h,v 1.2 2004/11/09 20:37:38 bhockney Exp $ */

#ifndef _COMPARE_H
#define _COMPARE_H

#include "main.h"

struct conn_data *wfwl_sort(struct conn_data *list1);

#endif
