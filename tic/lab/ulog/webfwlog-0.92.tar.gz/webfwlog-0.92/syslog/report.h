/* $Id: report.h,v 1.2 2004/11/09 20:37:38 bhockney Exp $ */

#ifndef _MODES_H
#define _MODES_H

void generate_report(void);

#endif
