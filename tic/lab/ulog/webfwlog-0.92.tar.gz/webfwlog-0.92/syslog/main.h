/* $Id: main.h,v 1.12 2006/03/03 17:27:38 bhockney Exp $ */

/* (C) 2004-2006 by Bob Hockney <zeus@ix.netcom.com>                         *
 * Based on fwlogwatch written by                                            *
 * Boris Wesslowski <Wesslowski@CERT.Uni-Stuttgart.DE>                       *
 *                                                                           *
 * wfwl_syslog is the backend syslog parser for webfwlog.                    *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program; if not, write to the Free Software               *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#ifndef _MAIN_H
#define _MAIN_H

#include "getdate.h"
#include <netinet/in.h>
#include <inttypes.h>

/* config.h */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

/* Data sizes */

#define BUFSIZE 1024
#define BUFSIZE_S "1023"
#define QUERYSIZE 4096
#define FILESIZE 256
#define TIMESIZE 40
#define SHORTLEN 128
#define SHORTLEN_S "127"
#define SHOSTLEN 33
#define SHOSTLEN_S "32"
#define IPLEN 16
#define MAXSORTSIZE 24

/* Files */

#define INFILE "/var/log/messages" /* Default input file */
#define REPORTDEF "-"

enum {
  MAY_NOT_EXIST,
  MUST_EXIST
};

enum {
  NO,
  YES
};

enum {
  FAILURE,
  SUCCESS
};

enum {
  QUERY_OK,
  QUERY_ERROR
};

enum {
  IGNORE_HASH,
  COMMENT_HASH
};

/* Modes */

enum {
  LOG_SUMMARY,
  LOG_DETAIL
};

/* Parser */

#define PARSER_IPCHAINS 1
#define PARSER_NETFILTER 2
#define PARSER_IPFILTER 4
#define PARSER_WIN_XP 8
#define PARSER_IPFW 16

enum {
  PARSE_OK,
  PARSE_ERROR,
  PARSE_NO_HIT,
  PARSE_WRONG_FORMAT,
  PARSE_TOO_OLD,
  PARSE_EXCLUDED
};

enum {
  IN_ADDR_OK,
  IN_ADDR_ERROR
};

/* TCP flags */

#define TCP_SYN 1
#define TCP_ACK 2
#define TCP_FIN 4
#define TCP_RST 8
#define TCP_PSH 16
#define TCP_URG 32
#define TCP_OPTS_EXACT 64
#define TCP_FLAGS_MATCH 128

/* ipchains support */

#define IPCHAINS_DATE 1
#define IPCHAINS_DATA 2
#define IPCHAINS_IPS 4

/* netfilter support */

#define NF_DATE 1
#define NF_IN 2
#define NF_SRC 4
#define NF_DST 8
#define NF_PROTO 16
#define NF_SPT 32
#define NF_DPT 64
#define NF_TYPE 128

enum {
  NF_OPT_NOPREFIX,
  NF_OPT_PREFIX,
  NF_OPT_SRC,
  NF_OPT_DST
};

/* ipfilter support */

#define IPF_DATE 1
#define IPF_DATA 2
#define IPF_PROTO 4
#define IPF_SRC_IP 8
#define IPF_DST_IP 16
#define IPF_SRC_PORT 32
#define IPF_DST_PORT 64
#define IPF_TYPE 128
#define IPF_NO_HIT 256

#define IPF_OPT_NONE 1
#define IPF_OPT_COUNT 2
#define IPF_OPT_SRC 4
#define IPF_OPT_DST 8
#define IPF_OPT_RES 16
#define IPF_OPT_PORT 32
#define IPF_OPT_RPORT 64

/* ipfw support */

#define IPFW_DATE 1
#define IPFW_CHAIN 2
#define IPFW_PROTO 4
#define IPFW_IPS 8
#define IPFW_IF 16
#define IPFW_NO_HIT 32

enum {
  IPFW_OPT_NONE,
  IPFW_OPT_ICMP,
  IPFW_OPT_OTHER,
  IPFW_OPT_PORTS
};

/* Sorting */

#define SORT_INV_NO_SORT 35767

/* enumerated list of columns by which sorting may be done */
enum {
  SORT_ID = 1,
  SORT_COUNT,
  SORT_START_TIME,
  SORT_END_TIME,
  SORT_DELTA_TIME,
  SORT_CHAINLABEL,
  SORT_PROTOCOL,
  SORT_DATALEN,
  SORT_SOURCEHOST,
  SORT_SOURCEPORT,
  SORT_DESTHOST,
  SORT_DESTPORT,
  SORT_ICMP_TYPE,
  SORT_ICMP_CODE,
  SORT_ICMP_ECHOID,
  SORT_ICMP_ECHOSEQ,
  SORT_ICMP_MTU,
  SORT_ICMP_GW,
  SORT_IP_ID,
  SORT_IP_IHL,
  SORT_IP_TOS,
  SORT_IP_TOTLEN, /* same as DATALEN */
  SORT_IP_TTL,
  SORT_LOCAL_HOST,
  SORT_IN_IF,
  SORT_OUT_IF,
  SORT_FWMARK,
  SORT_PREFIX, /* same as CHAINLABEL?? */
  SORT_LOCAL_TIME,
  SORT_OOB_TIME,
  SORT_TIME_USEC,
  SORT_MAC,
  SORT_FRAGOFF,
  SORT_CSUM,
  SORT_AHESP_SPI,
  SORT_TCP_SEQ,
  SORT_TCP_ACKSEQ,
  SORT_TCP_WINDOW,
  SORT_UDP_LEN,
  SORT_TCP_URGP,
  SORT_TCP_OPTS
};

enum {
  ORDER_ASCENDING,
  ORDER_DESCENDING
};

struct sort_order {
  int field;
  char keyname[SHORTLEN];
  int order;
  int position;
  struct sort_order *next;
};

/* enumerated list of possible fields for report */
enum {
  COL_ID,
  COL_COUNT,
  COL_LOCAL_HOST,
  COL_LOCAL_TIME,
  COL_START_TIME,
  COL_END_TIME,
  COL_LOG_PREFIX,
  COL_FWMARK,
  COL_MAC,
  COL_IN_IF,
  COL_OUT_IF,
  COL_IP_PROTO,
  COL_SOURCEHOST,
  COL_SOURCEHOST_NAME,
  COL_SOURCEPORT,
  COL_SOURCE_SERVICE,
  COL_DESTHOST,
  COL_DESTHOST_NAME,
  COL_DESTPORT,
  COL_DEST_SERVICE,
  COL_IP_ID,
  COL_IP_CSUM,
  COL_IP_FRAGOFF,
  COL_IP_IHL,
  COL_IP_TOS,
  COL_IP_TTL,
  COL_IP_LEN,
  COL_ICMP_TYPE,
  COL_ICMP_CODE,
  COL_TCP_SEQ,
  COL_TCP_ACKSEQ,
  COL_TCP_WINDOW,
  COL_TCP_OPTIONS,
  COL_TCP_URGP,
  COL_UDP_LEN,
  COL_ICMP_ECHOID,
  COL_ICMP_ECHOSEQ,
  COL_ICMP_MTU,
  COL_ICMP_GATEWAY,
  COL_AHESP_SPI
};

#define CACHE_RESOLVE 1
#define CACHE_POPULATE 2
#define CACHE_UPDATE 4

struct field_order {
  int field;
  char keyname[SHORTLEN]; /* human readable for messages */
  int position;
  struct field_order *next;
};

/* Fields in report */
/* this is used to indicate which fields are in report for more efficient summarization */
struct fields_used {
  int count;
  int local_time;
  int earliest;
  int latest;
  int hostname;
  int log_label;
  int protocol;
  int totlen;
  int shost;
  int shost_name;
  int sport;
  int src_service;
  int dhost;
  int dhost_name;
  int dport;
  int dst_service;
  int flags;
  int raw_mac;
  int fwmark;
  int inif;
  int outif;
  int tos;
  int ttl;
  int ihl;
  int csum;
  int ipid;
  int fragoff;
  int tcp_seq;
  int tcp_ack_seq;
  int tcp_window;
  int tcp_urgp;
  int udp_len;
  int icmp_type;
  int icmp_code;
  int icmp_echoid;
  int icmp_echoseq;
  int icmp_gw;
  int icmp_mtu;
  int ahesp_spi;
};

/* Data structures */

/* Used for ICMP type and code tables */
struct icmp_code {
  int code;
  char *name;
};

struct icmp_type {
  int type;
  char *name;
  struct icmp_code *codes;
  int numcodes;
};

/* Used for receiving data from a line in log file */
struct log_line {
  char filename[FILESIZE];
  unsigned long int linenum;
  time_t time;
  char hostname[SHOSTLEN];
  char log_label[SHORTLEN];
  char chainlabel[SHORTLEN];
  char branchname[SHORTLEN];
  char interface[SHORTLEN];
  int protocol;
  unsigned int datalen;
  struct in_addr shost;
  char shostname[SHORTLEN];
  unsigned int sport;
  char sservice[SHORTLEN];
  struct in_addr dhost;
  char dhostname[SHORTLEN];
  unsigned int dport;
  char dservice[SHORTLEN];
  unsigned char flags;
  unsigned long int count;
  char raw_mac[SHORTLEN];
  int fwmark;
  char inif[SHORTLEN];
  char outif[SHORTLEN];
  int tos;
  int ttl;
  int ihl;
  unsigned int csum;
  unsigned int ipid;
  unsigned int fragoff;
  unsigned long int tcp_seq;
  unsigned long int tcp_ack_seq;
  unsigned int tcp_window;
  int tcp_urgp;
  unsigned int udp_len;
  int icmp_type;
  int icmp_code;
  int icmp_echoid;
  int icmp_echoseq;
  struct in_addr icmp_gw;
  int icmp_mtu;
  unsigned long ahesp_spi;
};

/* Linked list of report data */
struct conn_data {
  char filename[FILESIZE];
  unsigned long int rowid;
  unsigned long int linenum;
  unsigned long int count;
  time_t local_time;
  time_t start_time;
  time_t end_time;
  char hostname[SHOSTLEN];
  char log_label[SHORTLEN];
  char chainlabel[SHORTLEN];
  char branchname[SHORTLEN];
  char interface[SHORTLEN];
  int protocol;
  unsigned int datalen;
  struct in_addr shost;
  char shostname[SHORTLEN];
  unsigned int sport;
  char sservice[SHORTLEN];
  struct in_addr dhost;
  char dhostname[SHORTLEN];
  unsigned int dport;
  char dservice[SHORTLEN];
  unsigned char flags;
  char raw_mac[SHORTLEN];
  int fwmark;
  char inif[SHORTLEN];
  char outif[SHORTLEN];
  int tos;
  int ttl;
  int ihl;
  unsigned int csum;
  unsigned int ipid;
  unsigned int fragoff;
  unsigned long int tcp_seq;
  unsigned long int tcp_ack_seq;
  unsigned int tcp_window;
  int tcp_urgp;
  unsigned int udp_len;
  int icmp_type;
  int icmp_code;
  int icmp_echoid;
  int icmp_echoseq;
  struct in_addr icmp_gw;
  int icmp_mtu;
  unsigned long ahesp_spi;
  struct conn_data *next;
};

/* when populating cache for summarized report at runtime, this structure */
/* contains detail for summarized lines for fields that may not appear in */
/* report */
struct conn_data_sum {
  unsigned long int rowid;
  struct in_addr shost;
  struct in_addr dhost;
  int protocol;
  unsigned int sport;
  unsigned int dport;
  struct conn_data_sum *next;
};

/* Linked list of files to be parsed */
struct input_file {
  char *name;
  struct input_file *next;
};

/* enumerated list of matches */
enum {
  P_MATCH_NONE,
  P_MATCH_EXC
};

/* include/exclude bitmap for criteria allowing multiple values and ranges */
#define MATCH_MUL_NONE     0x00000000
#define MATCH_TCP_DPORT    0x00000001
#define MATCH_TCP_SPORT    0x00000002
#define MATCH_UDP_DPORT    0x00000004
#define MATCH_UDP_SPORT    0x00000008
#define MATCH_ICMP_TYPE    0x00000010
#define MATCH_ICMP_CODE    0x00000020
#define MATCH_SRC_HOST     0x00000040
#define MATCH_DST_HOST     0x00000080
#define MATCH_PROTOCOL     0x00000100
#define MATCH_AHESP_SPI    0x00000200
#define MATCH_IP_TOS       0x00000400
#define MATCH_IP_TTL       0x00000800
#define MATCH_IP_IHL       0x00001000
#define MATCH_IP_TOTLEN    0x00002000
#define MATCH_IP_ID        0x00004000
#define MATCH_IP_CSUM      0x00008000
#define MATCH_IP_FRAGOFF   0x00010000
#define MATCH_OOB_MARK     0x00020000
#define MATCH_TCP_SEQ      0x00040000
#define MATCH_TCP_ACKSEQ   0x00080000
#define MATCH_TCP_WINDOW   0x00100000
#define MATCH_TCP_URGP     0x00200000
#define MATCH_ICMP_ECHOID  0x00400000
#define MATCH_ICMP_ECHOSEQ 0x00800000
#define MATCH_ICMP_FRAGMTU 0x01000000
#define MATCH_UDP_LEN      0x02000000
#define MATCH_ICMP_GATEWAY 0x04000000

/* enumerated list of item types in report definitions */
enum {
  DEF_NONE,
  DEF_WHERE,
  DEF_INVERT,
  DEF_SORT,
  DEF_ORDER,
  DEF_COLUMN,
  DEF_SUM,
  DEF_OPTION
};

/* enumerated list of items by which selection may be done */
enum {
  SEL_MIN_DATE = 1,
  SEL_MAX_DATE,
  SEL_PROTOCOL,
  SEL_SOURCEHOST,
  SEL_DESTHOST,
  SEL_UDP_SPORT,
  SEL_UDP_DPORT,
  SEL_ICMP_TYPE,
  SEL_ICMP_CODE,
  SEL_LOCAL_HOST,
  SEL_IN_IF,
  SEL_OUT_IF,
  SEL_PREFIX,
  SEL_TCP_SPORT,
  SEL_TCP_DPORT,
  SEL_TCP_FLAGS,
  SEL_TCP_SYN,
  SEL_TCP_ACK,
  SEL_TCP_FIN,
  SEL_TCP_RST,
  SEL_TCP_PSH,
  SEL_TCP_URG,
  SEL_TCP_OPTS_EXACT,
  SEL_AHESP_SPI,
  SEL_IP_TOS,
  SEL_IP_TTL,
  SEL_IP_IHL,
  SEL_IP_TOTLEN,
  SEL_IP_ID,
  SEL_IP_CSUM,
  SEL_IP_DF,
  SEL_IP_MF,
  SEL_IP_FRAGOFF,
  SEL_OOB_MARK,
  SEL_TCP_SEQ,
  SEL_TCP_ACKSEQ,
  SEL_TCP_WINDOW,
  SEL_TCP_URGP,
  SEL_ICMP_ECHOID,
  SEL_ICMP_ECHOSEQ,
  SEL_ICMP_GATEWAY,
  SEL_ICMP_FRAGMTU,
  SEL_UDP_LEN,
  SEL_RAW_MAC
};

/* enumerated list of selection criteria types */
enum {
  SEL_STRING,
  SEL_NUM,
  SEL_REGEX,
  SEL_BOOLEAN,
  SEL_IPADDR,
  SEL_PROTO,
  SEL_DATE
};

struct selection {
  int field;
  char keyname[SHORTLEN];
  int type;
  unsigned long int value;
  unsigned long int max_value;
  char svalue[SHORTLEN];
  uint32_t netmask;
  int invert;
  int have_value;
  struct selection *next;
};

/* Holds values for aggregate selection criteria */
struct select_sum {
  unsigned long int min_count;
  unsigned long int max_count;
  time_t max_earliest;
  time_t min_latest;
};

/* verbosity levels                                *
 * These are similar to kernel logging levels, and *
 * the labels are for convenience only.            */
enum {
  VERBOSE_OFF,     /* No status messages */
  VERBOSE_INFO,    /* Basic status messages of actions being taken */
  VERBOSE_NOTICE,  /* Detail status messages */
  VERBOSE_WARNING, /* Some detail of progress */
  VERBOSE_ERROR,   /* More detail of progress */
  VERBOSE_DEBUG    /* Great detail of progress */
};

/* Contains parsed global options. */
/* Also contains the current log line being parsed and other reused data */
/* There is one of these with global scope */
struct options {
  unsigned char mode;           /* reporting mode */
  FILE *inputfd;                /* file handle of current input file */
  char pathname[FILESIZE];      /* path to syslog files */
  char filename[FILESIZE];      /* name of file currently being parsed */
  unsigned long int packet;     /* set to line number for packet detail */
  unsigned long int linenum;    /* line number currently being parsed */
  unsigned char std_in;         /* set if no input files; reads stdin */

  unsigned char verbose;        /* verbosity level: 0 to 5 */
  int filecount;                /* number of input files, or 0 if stdin used */
  char reportdef[FILESIZE];     /* name of report definition file */
  char db[SHORTLEN];            /* database to use - mysql or pgsql */
  char mysql_server[SHORTLEN];  /* location of mysql server */
  char mysql_user[SHORTLEN];    /* mysql user name */
  char mysql_pass[SHORTLEN];    /* mysql password */
  char mysql_wfwl_db[SHORTLEN]; /* mysql database */
  unsigned char have_db;        /* set if database support is compiled in */

  char pgsql_server[SHORTLEN];  /* location of postgresql server */
  char pgsql_user[SHORTLEN];    /* postgresql user name */
  char pgsql_pass[SHORTLEN];    /* postgresql password */
  char pgsql_db[SHORTLEN];      /* postgresql database */
  char pgsql_wfwl_schema[SHORTLEN]; /* postgresql schema */
  unsigned char pgsql_have_namespace; /* set if server supports schemas */
 
  struct log_line *line;        /* data for current log line being parsed */
  char format_sel[SHORTLEN];    /* list of parsers from command line */
  unsigned int format;          /* list of parsers to use */
  unsigned int parser;          /* used internally by parser to determine what has been parsed */
  unsigned char repeated;       /* used for repeat expansion */
  int orig_count;               /* 0 or 1; used with repeat expansion */

  unsigned char datalen;        /* set to output total data length */

  unsigned char sortfield;      /* field to sort by */
  unsigned char sortmode;       /* ascending or descending */
  unsigned char resolve_hosts;  /* set if hostnames and service names are to be resolved */

  unsigned char raw;            /* set for raw output */
  unsigned long int report_rows; /* number of total rows in report */
  unsigned long int matched_entries; /* number of log entries meeting selection criteria */
  unsigned char use_out;        /* set if outfile to be used */
  char outputfile[FILESIZE];    /* name of outfile */

  unsigned long int max;        /* maximum number of rows to output */
  unsigned long int begin;      /* starting row to output */

  unsigned char ipchains_check; /* set to check ipchains rules */
};

#endif
