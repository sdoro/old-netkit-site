/* $Id: main.c,v 1.7 2006/03/03 17:27:38 bhockney Exp $ */

/* (C) 2004-2006 by Bob Hockney <zeus@ix.netcom.com>                         *
 * Based on fwlogwatch written by                                            *
 * Boris Wesslowski <Wesslowski@CERT.Uni-Stuttgart.DE>                       *
 *                                                                           *
 * wfwl_syslog is the backend syslog parser for webfwlog.                    *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License for more details.                              *
 *                                                                           *
 * You should have received a copy of the GNU General Public License         *
 * along with this program; if not, write to the Free Software               *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "main.h"
#include "reportdef.h"
#include "parser.h"
#include "report.h"
#include "utils.h"
#include "database.h"

struct options opt;
extern char *optarg;

void usage(char *me, unsigned char exitcode)
{
  printf("%s (C) %s\n\n", PACKAGE_STRING, COPYRIGHT);
  printf("Usage: %s [options] [input_files]\n\n", me);

  printf("Webfwlog syslog parser options:\n");
  printf("  -r <file>    specify report definition file (defaults to stdin)\n");
  printf("  -M <number>  Limit report to this many lines\n");
  printf("  -m <number>  Skip this many line on limited report\n");
  printf("  -l <number>  Print all columns for this line of first input file\n");
  printf("  -P <format>  use only parsers for specific formats\n");
  printf("  -o <file>    specify output file\n");
  printf("  -v           verbose, specify multiple times for increasing detail\n");
  printf("  -V           show version and copyright info\n");
  printf("  -h           this help\n");
  printf("\n");

  exit(exitcode);
}

void info()
{
  /* GNU standards compatible program info */
  /* printed with "-V" */
  fprintf(stdout, "%s\n", PACKAGE_STRING);
  fprintf(stdout, "Copyright (C) %s\n", COPYRIGHT);
  puts("Based on fwlogwatch written by");
  puts("Boris Wesslowski <Wesslowski@CERT.Uni-Stuttgart.DE>");
  puts("");
  puts("wfwl_syslog is the back-end log file parser for the webfwlog package,");
  puts("which is a web-based firewall log analyzer and reporting tool.");
  puts("This program is not intended to be run as a standalone process.");
  puts("");
  puts("This program is free software; you can redistribute it and/or modify");
  puts("it under the terms of the GNU General Public License as published by");
  puts("the Free Software Foundation; either version 2 of the License, or");
  puts("(at your option) any later version.");
  puts("");
  puts("This program is distributed in the hope that it will be useful,");
  puts("but WITHOUT ANY WARRANTY; without even the implied warranty of");
  puts("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the");
  puts("GNU General Public License for more details.");
  puts("");
  puts("You should have received a copy of the GNU General Public License");
  puts("along with this program; if not, write to the Free Software");
  puts("Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA");
  puts("");
  puts("You can contact the author at <zeus@ix.netcom.com>.");
  puts("");
  puts("Compile-time options of this version:");
#ifdef HAVE_MYSQL
  puts("MySQL support enabled");
#endif
#ifdef HAVE_PGSQL
  puts("PostgreSQL enabled");
#endif

  exit(EXIT_SUCCESS);
}

/* sets default options */
void init_options()
{
  opt.mode = LOG_DETAIL;
  opt.inputfd = NULL;
  opt.pathname[0] = '\0';
  opt.filename[0] = '\0';
  opt.linenum = 0;
  opt.packet = 0;
  opt.std_in = 0;

  opt.verbose = VERBOSE_OFF;
  opt.filecount = 0;
  xstrncpy(opt.reportdef, REPORTDEF, FILESIZE);
  opt.db[0] = '\0'; 
  opt.mysql_server[0] = '\0'; 
  opt.mysql_user[0] = '\0'; 
  opt.mysql_pass[0] = '\0'; 
  opt.mysql_wfwl_db[0] = '\0'; 
  opt.pgsql_server[0] = '\0'; 
  opt.pgsql_user[0] = '\0'; 
  opt.pgsql_pass[0] = '\0'; 
  opt.pgsql_db[0] = '\0'; 
  opt.pgsql_wfwl_schema[0] = '\0'; 
  opt.pgsql_have_namespace = 0;
  opt.have_db = 0;

  opt.line = NULL;
  opt.format_sel[0] = '\0';
  opt.format = PARSER_IPCHAINS|PARSER_NETFILTER|PARSER_IPFILTER|PARSER_WIN_XP|PARSER_IPFW;
  opt.parser = 0;
  opt.repeated = 0;
  opt.orig_count = 0;

  opt.datalen = 0;

  opt.sortfield = 0;
  opt.sortmode = 0;
  opt.resolve_hosts = 0;

  opt.raw = 0;
  opt.report_rows = 0;
  opt.matched_entries = 0;
  opt.use_out = 0;
  opt.outputfile[0] = '\0';

  opt.max = 0;
  opt.begin = 0;

  opt.ipchains_check = 0;
}

/* Entry point */
int main(int argc, char **argv)
{
  int iopt;

  /* set default options */
  init_options();

  /* parse command line */
  while ((iopt = getopt(argc, argv, "hl:m:M:o:P:r:vVZ")) != EOF) {
                                     /* used: hlmMoPrvVZ */
    switch (iopt) {
    case 'h':
      usage(argv[0], EXIT_SUCCESS);
      break;
    case 'o':
      xstrncpy(opt.outputfile, optarg, FILESIZE);
      opt.use_out = 1;
      break;
    case 'P':
      xstrncpy(opt.format_sel, optarg, SHORTLEN);
      break;
    case 'v':
      opt.verbose++;
      break;
    case 'V':
      info();
      break;
    case 'r':
      xstrncpy(opt.reportdef, optarg, FILESIZE);
      break;
    case 'M':
      opt.max = atol(optarg);
      break;
    case 'm':
      opt.begin = atol(optarg);
      break;
    case 'l':
      opt.packet = atol(optarg);
      break;
    case 'Z':
      opt.raw = 1;
      break;
    default:
      usage(argv[0], EXIT_FAILURE);
    }
  }

  /* Get files to parse from command line, otherwise use default */
  while (optind < argc)
    add_input_file(argv[optind++]);

  if (opt.filecount == 0)
    add_input_file(INFILE);

  /* If parsers specified on command line or in rcfile, use only those */
  select_parsers();

  /* parse report definition file */
  if (read_reportdef(opt.reportdef) == EXIT_FAILURE)
    return EXIT_FAILURE;

#if HAVE_MYSQL || HAVE_PGSQL
opt.have_db = 1;
#endif

  if (opt.have_db) {
    if (open_db((char *)&opt.db) == FAILURE) {
      close_db((char *)&opt.db);
      opt.have_db = 0;
    }
  } else {
    if (opt.verbose >= VERBOSE_INFO)
      fprintf(stderr, "No database server available.  (Is support compiled in?)\n");
  }

  /* do it */
  switch (opt.mode) {
  case LOG_SUMMARY:
  case LOG_DETAIL:
    generate_report();
    break;
  }

  return EXIT_SUCCESS;
}
