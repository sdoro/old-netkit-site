/* $Id: win_xp.c,v 1.4 2006/03/03 17:27:38 bhockney Exp $ */

/* (C) 2004-2006 by Bob Hockney <zeus@ix.netcom.com>    *
 * Based on fwlogwatch written by                       *
 * Boris Wesslowski <Wesslowski@CERT.Uni-Stuttgart.DE>  *
 *                                                      *
 * Windows XP log parser for wfwl_syslog                  *
 *                                                      *
 * This code is distributed under the terms of GNU GPL  */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include "main.h"
#include "utils.h"

extern struct options opt;

unsigned char win_xp(char *input, int linenum)
{
  char *sinputs=input, *sinpute;
  int retval, year, day, month, hour, minute, second;
  struct tm *t;

  /* Read file header */
  if(*input=='#' || !isdigit((int)*input))
    return PARSE_NO_HIT;
  init_line();
  xstrncpy(opt.line->hostname, "-", SHORTLEN);
  xstrncpy(opt.line->interface, "-", SHORTLEN);

  /* Read time */
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  retval = sscanf(sinputs, "%4d-%2d-%2d", &year, &month, &day);
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  retval = sscanf(sinputs, "%2d:%2d:%2d", &hour, &minute, &second);
  t = xmalloc(sizeof(struct tm));
  t->tm_year = year-1900;
  t->tm_mon = month-1;
  t->tm_mday = day;
  t->tm_hour = hour;
  t->tm_min = minute;
  t->tm_sec = second;
  t->tm_isdst = -1;
  opt.line->time = mktime(t);

  /* Read action */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  xstrncpy(opt.line->log_label, sinputs, SHORTLEN);

  /* Read protocol */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if(strncmp(sinputs, "TCP", 3) == 0) opt.line->protocol = 6;
  else if(strncmp(sinputs, "UDP", 3) == 0) opt.line->protocol = 17;
  else if(strncmp(sinputs, "ICMP", 4) == 0) opt.line->protocol = 1;
  else if(atoi(sinputs)) opt.line->protocol = atoi(sinputs);
  else {
    if(opt.verbose >= VERBOSE_ERROR)
      fprintf(stderr, "win_xp parse error while reading proto in line %d, ignoring.\n", linenum);
    return PARSE_WRONG_FORMAT;
  }

  /* Read src ip */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (*sinputs != '-'){
    if(convert_ip(sinputs, &opt.line->shost) == IN_ADDR_ERROR) return PARSE_NO_HIT;
  } else {
    if(opt.verbose >= VERBOSE_ERROR)
      fprintf(stderr, "win_xp parse error while reading shost in line %d, ignoring.\n", linenum);
    return PARSE_WRONG_FORMAT;
  }

  /* Read dst ip */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (*sinputs != '-'){
    if(convert_ip(sinputs, &opt.line->dhost) == IN_ADDR_ERROR) return PARSE_NO_HIT;
  } else {
    if(opt.verbose >= VERBOSE_ERROR)
      fprintf(stderr, "win_xp parse error while reading dhost in line %d, ignoring.\n", linenum);
    return PARSE_WRONG_FORMAT;
  }

  /* Read src port */
  sinpute=sinpute+1;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (isdigit((int)*sinputs)){
    opt.line->sport=atoi(sinputs);
  } else if (*sinputs == '-' && (opt.line->protocol == 6 || opt.line->protocol == 17)) {
    if(opt.verbose >= VERBOSE_ERROR)
      fprintf(stderr, "win_xp parse error while reading sport in line %d, ignoring.\n", linenum);
    return PARSE_WRONG_FORMAT;
  }

  /* Read dst port */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (isdigit((int)*sinputs)){
    opt.line->dport=atoi(sinputs);
  } else if (*sinputs == '-' && (opt.line->protocol == 6 || opt.line->protocol == 17)) {
    if(opt.verbose >= VERBOSE_ERROR)
      fprintf(stderr, "win_xp parse error while reading dport in line %d, ignoring.\n", linenum);
    return PARSE_WRONG_FORMAT;
  }

  /* Read size */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (isdigit((int)*sinputs)){
    opt.line->datalen=atoi(sinputs);
  }

  /* Read tcp flags */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  while (*sinputs != '\0') {
    switch (*sinputs) {
    case '-':
      break;
    case 'S':
      opt.line->flags |= TCP_SYN;
      break;
    case 'A':
      opt.line->flags |= TCP_ACK;
      break;
    case 'F':
      opt.line->flags |= TCP_FIN;
      break;
    case 'R':
      opt.line->flags |= TCP_RST;
      break;
    case 'P':
      opt.line->flags |= TCP_PSH;
      break;
    case 'U':
      opt.line->flags |= TCP_URG;
      break;
    default:
      if(opt.verbose >= VERBOSE_ERROR)
	fprintf(stderr, "win_xp parse error in line %d, ignoring.\n", linenum);
      return PARSE_WRONG_FORMAT;
    }
    sinputs++;
  }

  /* Read tcpsyn */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (isdigit((int)*sinputs)){
    opt.line->tcp_seq=strtoul(sinputs,NULL,0);
  }

  /* Read tcpack */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (isdigit((int)*sinputs)){
    opt.line->tcp_ack_seq=strtoul(sinputs,NULL,0);
  }

  /* Read tcpwin */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (isdigit((int)*sinputs)){
    opt.line->tcp_window=atol(sinputs);
  }

  /* Read icmp type */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (isdigit((int)*sinputs)){
    opt.line->sport=atoi(sinputs);
  }

  /* Read icmp code */
  sinpute++;
  sinputs=sinpute;
  sinpute = strchr(sinputs, ' ');
  if (sinpute != NULL)
    *sinpute = '\0';
  if (isdigit((int)*sinputs)){
    opt.line->dport=atoi(sinputs);
  }

  /* Ignore info field */

  sinpute++;
  sinpute = strchr(sinpute, ' ');

  /* Read direction field into inif (sp2) */
  if (sinpute != NULL) {
    sinpute++;
    sinputs=sinpute;
    sinpute = strchr(sinputs, '\n');
    if (sinpute != NULL)
      *sinpute = '\0';
    xstrncpy(opt.line->inif, sinputs, SHORTLEN);
  }

  opt.line->count = 1;
  return PARSE_OK;
}
