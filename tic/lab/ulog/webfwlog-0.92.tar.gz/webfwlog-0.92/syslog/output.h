/* $Id: output.h,v 1.2 2004/11/09 20:37:38 bhockney Exp $ */

#ifndef _OUTPUT_H
#define _OUTPUT_H

#include "main.h"

void show_list(FILE *fd);

#endif
