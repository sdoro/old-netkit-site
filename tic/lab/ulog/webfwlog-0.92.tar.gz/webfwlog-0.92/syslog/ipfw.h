/* $Id: ipfw.h,v 1.2 2004/12/28 20:18:25 bhockney Exp $ */

#ifndef _IPFW_H
#define _IPFW_H

unsigned char flex_ipfw(char *input, int linenum);

#endif
