/* $Id: ipchains.h,v 1.2 2004/11/09 20:37:38 bhockney Exp $ */

#ifndef _IPCHAINS_H
#define _IPCHAINS_H

unsigned char flex_ipchains(char *input, int linenum);

#endif
