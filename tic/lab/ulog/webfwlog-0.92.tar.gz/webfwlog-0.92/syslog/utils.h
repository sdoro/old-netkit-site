/* $Id: utils.h,v 1.2 2004/11/09 20:37:38 bhockney Exp $ */

#ifndef _UTILS_H
#define _UTILS_H
#include <netinet/in.h>

char *xstrncpy(char *dest, const char *src, size_t n);
void *xmalloc(int size);
void free_conn_data(void);
void init_line(void);
void build_time(char *smonth, int day, int hour, int minute, int second);
unsigned char convert_ip(char *ip, struct in_addr *addr);
void add_input_file(char *name);
void free_input_file(void);
char * resolve_protocol(int proto);
char * resolve_hostname(struct in_addr ip);
char * get_service(unsigned int port, int proto);
long int get_port(char * service, int proto);
char * strip_nl(char *msg);
int get_icmp_values(char *input);
#endif
