/* $Id: database.h,v 1.4 2005/02/04 03:55:10 bhockney Exp $ */

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#ifndef _DATABASE_H
#define _DATABASE_H
  int open_db(char *db);
  void close_db(char *db);
  void get_hostname(struct in_addr *ip, char * hostname);
  void get_service_name(int proto, unsigned int port, char * service);
  void resolve_hosts();
  void resolve_services();
  void populate_cache();
#endif
