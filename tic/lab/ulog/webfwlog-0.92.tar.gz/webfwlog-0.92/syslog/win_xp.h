/* $Id: win_xp.h,v 1.2 2004/12/28 20:18:25 bhockney Exp $ */

#ifndef _WIN_XP_H
#define _WIN_XP_H

unsigned char win_xp(char *input, int linenum);

#endif
