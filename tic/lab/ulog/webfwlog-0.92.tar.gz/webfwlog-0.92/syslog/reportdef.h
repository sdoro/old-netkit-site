/* $Id: reportdef.h,v 1.2 2004/11/09 20:37:38 bhockney Exp $ */

#ifndef _REPORTDEF_H
#define _REPORTDEF_H

unsigned char read_reportdef(char *reportdef);

#endif
