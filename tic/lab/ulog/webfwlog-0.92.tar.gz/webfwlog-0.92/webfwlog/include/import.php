<?php
/*
$Id: import.php,v 1.10 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

import of report definitions

This code is distributed under the terms of GNU GPL
*/
?>

<?php
if (strtolower($FWLOG["action"]) == "import" and $FWLOG["page"] == "import") {
	// import function
	if (
		!$_FILES['import_report']['error'] and
		 eregi("text", exec("file {$_FILES['import_report']['tmp_name']}")) and
		 $_FILES['import_report']['size'] < 4096 and
		 is_uploaded_file($_FILES['import_report']['tmp_name']) 
	   ) {
		$file = "{$_FILES['import_report']['tmp_name']}";
		unset($params);
		if (is_file("$file"))
		if ($fp = fopen("$file", "r")) {
			While (!feof($fp)) {
			$buffer = fgets($fp, 1024);
			if ($buffer[0] == "#" or $buffer == "" or !isset($buffer)) continue;
			$params[] = explode("=", "$buffer", 2);
			}
			fclose($fp);
		} 
		unset($FWLOG);
		foreach ($params as $param) {
			$FWLOG[trim("{$param[0]}")] = trim(trim(substr("{$param[1]}",1)), "\"'");
		}
		unset($params);
		$FWLOG["report"] = "{$_FILES['import_report']['name']}";
		$imported = 'yes';
		require 'include/orders.php';
		include "include/edit_report.php";
		return;
	} else {
		$status = "\t<div align='center'><font color='red'>SPECIFIED FILE NOT VALID<br>\n";
		$status = $status . "\t{$_FILES['import_report']['name']}</font></div>\n";
	}
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title>Webfwlog - Import Report</title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<form action="<?php print "$self"; ?>" method="POST" enctype="multipart/form-data">

<?php
	foreach ($FWLOG as $a => $b) {
			if (!("$a" == "page"))
			print "<input type='hidden' name=\"".htmlspecialchars("$a", ENT_QUOTES).
			"\" value=\"".htmlspecialchars("$b", ENT_QUOTES)."\">\n";
	}
?>
<input type='hidden' name='page' value='import'>

<div style="margin-top:5em; " align="center">
<font size="+2">
<table border=1>
  <caption>
     IMPORT REPORT DEFINITION<p>
 	 <?php if ($status) print "$status"; ?>
  </caption>
    <tr>
      <td style="text-align: left; ">Filename:</td>
      <td>
		<input
			type="file"
			name="import_report"
			value=""
			accept="text/plain"
		>
      </td>
    </tr>
    <tr>
		<td colspan="2">
			<input style="width: 16ex; " type="submit" name="action" value="Import">&nbsp;&nbsp;
			<input style="width: 16ex; " type="submit" name="import" value="Cancel">
		</td>
	</tr>
</table>
</font>
</div>

</form>

</body>
</html>
