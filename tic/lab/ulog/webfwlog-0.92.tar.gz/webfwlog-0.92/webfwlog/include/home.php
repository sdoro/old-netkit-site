<?php
/*
$Id: home.php,v 1.18 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

home page for webfwlog

This code is distributed under the terms of GNU GPL
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
	<title>Webfwlog</title>
	<LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<?php if ($config["debug"]) include "include/debug.php"; ?>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<font size="+1">
<p>
<form action="<?php print "$self"; ?>" method="POST">
<input type="hidden" name="page" value="home">

<table align=center>
<tr>
<td>

<table border="1">
	<caption>
		<strong>SELECT REPORT <a href="<?php print "$self"; ?>?#welcome">help</a></strong>
	</caption>
<?php
	$link = db("open", "$database");
	$have_last = db("exists", "SELECT last_saved, last_accessed FROM $reports");
	if (db("exists", "SELECT count(*) FROM $reports")) {
		$r_order = strtolower($FWLOG["report_order"]);
		switch ("$r_order") {
			case "code":
				$r_order = "code";
				break;
			case "last accessed":
				$r_order = "last_accessed";
				break;
			case "last saved":
				$r_order = "last_saved";
				break;
			case "unsorted":
				$r_order = "unsorted";
				break;
			default:
				die ("unknown sort order for report list");
				break;
		}
		if (!($r_order == "unsorted") and $have_last) {
			$rpt_order = "$r_order";
			if (!($r_order == "code")) {$ord = "DESC";} else {$ord = "";}; 
		} else {
			$rpt_order = "";
			$ord = "";
		}
		if ($rpt_order <> "") {
			$rptorder = "ORDER BY $rpt_order $ord";
		} else {
			$rptorder = "";
		};
		$query = "SELECT * FROM $reports WHERE code<>'default' $rptorder";
		$result =db("statement", "$query");
	}
?>
	<tr>
		<th scope=col style="width:10em; ">Code</th>
		<th>Edit</th>
			<?php
			if ($have_last) {
				print "<th>";
				if (strtolower("{$FWLOG["report_order"]}") == "last saved") {
					print "Last Saved";
				} else {
					print "Last Accessed";
				}
				print "</th>";
			}
			?>
		<th scope=col >Description</th>
	</tr>
<?php
	if (isset($result)) {
	$rownum = 0;
	while ($line = db("nextrow", $result)) {
?>
	<tr>
		<td align="left">
			<a href="<?php
				print "$self?action=run+report";
				print "&report={$line["code"]}";
				if (isset($_SESSION["fwlog_source"])) {
					$dsource = $_SESSION["fwlog_source"];
				} else {
					$dsource = array();
				}
				if (isset($dsource["data_source"]))
					print "&data_source={$dsource["data_source"]}";
				if (isset($dsource["ulog_table"]))
					print "&ulog_table=".urlencode("{$dsource["ulog_table"]}");
				if (isset($dsource["syslog_file"]))
					print "&syslog_file=".urlencode("{$dsource["syslog_file"]}");
				?>&show_select_data_source=<?php print "{$FWLOG["show_select_data_source"]}"; ?>"
			>
			<?php print "{$line["code"]}"; ?></a>
		</td>
		<td><a href="<?php print "$self"; ?>?action=use+report&select_report=<?php print "{$line["code"]}";
			?>&show_select_data_source=<?php print "{$FWLOG["show_select_data_source"]}"; ?>">edit</a>
		</td>
			<?php
			if ($have_last) {
				print "<td>";
				if (strtolower("{$FWLOG["report_order"]}") == "last saved") {
					if ($line["last_saved"] > 0)
						print date("{$config["dformat"]}", $line["last_saved"]);
				} else {
					if ($line["last_accessed"] > 0)
						print date("{$config["dformat"]}", $line["last_accessed"]);
				}
				print "</td>";
			}
			?>
		<td align="left"><?php print htmlspecialchars("{$line["description"]}", ENT_QUOTES); ?></td>
	</tr>
<?php
	}
	}
	$uri_source = "";
	if (isset($FWLOG["data_source"]))
		$uri_source = $uri_source . "&data_source=".urlencode("{$FWLOG["data_source"]}");
	if (isset($FWLOG["ulog_table"]))
		$uri_source = $uri_source . "&ulog_table=".urlencode("{$FWLOG["ulog_table"]}");
	if (isset($FWLOG["syslog_file"]))
		$uri_source = $uri_source . "&syslog_file=".urlencode("{$FWLOG["syslog_file"]}");
?>
	<tr>
		<td colspan=2 align="left">
			<span style="float: left;">
			<input type="submit" name="action" value="Report Editor">
			</span>
			<span style="float: right">
			<a href="<?php print "$self"; ?>?#editor">help</a>
			</span>
		</td>      
		<td colspan=2 align="left">
			<select name="report_order">
				<option <?php if (strtolower($FWLOG["report_order"]) == "last accessed") print "selected"; ?>>
					Last Accessed
				</option>
				<option <?php if (strtolower($FWLOG["report_order"]) == "last saved") print "selected"; ?>>
					Last Saved
				</option>
				<option <?php if (strtolower($FWLOG["report_order"]) == "code") print "selected"; ?>>
					Code
				</option>
				<option <?php if (strtolower($FWLOG["report_order"]) == "unsorted") print "selected"; ?>>
					Unsorted
				</option>
			</select>
			&nbsp;
			<input type="submit" name="action" value="Sort">
			&nbsp; &nbsp; &nbsp; &nbsp;
			<input type="submit" name="action" value="Update Cache">
			&nbsp;All
			<input type=checkbox name=update_all value=yes <?php if ($FWLOG["update_all"]) print "checked"; ?>>
			&nbsp;&nbsp;&nbsp;
			<a href="<?php print "$self"; ?>?#update_cache">help</a>
		</td>
	</tr>
	<tr class=opts>
		<td align=left colspan="4">
		<input type="hidden" name="show_select_data_source" value="<?php print "{$FWLOG["show_select_data_source"]}"; ?>">
		<?php
			if ($FWLOG["show_select_data_source"]) {
		?>
		<input type="submit" name="action" value="Select Data Source">
			&nbsp;&nbsp;&nbsp;
			<a href="<?php print "$self"; ?>?show_select_data_source=0<?php print "{$uri_source}&keep_source"; ?>">
				Hide
			</a>
			<br>
			<input
				type="radio"
				name="data_source"
				value=""
				tabindex=1
				<?php if(!isset($FWLOG["data_source"])) print "checked\n"; ?>
			>
			Default
			<br>
			<input
				type="radio"
				name="data_source"
				value="ulogd"
				tabindex=1
				<?php if(strtolower("{$FWLOG["data_source"]}") == "ulogd") print "checked\n"; ?>
			>
			Ulogd
			&nbsp;&nbsp;Table:&nbsp;
			<select name="ulog_table">
				<option value="">Default</option>
				<?php
				foreach(db("listtables","$ulogd") as $i) {
					print "<option";
					if("{$FWLOG["ulog_table"]}" == "$i") {
						print " selected";
					}
					print ">".htmlspecialchars("{$i}", ENT_QUOTES)."</option>\n";
				}
				?>
			</select>
			<br>
			<input
				type="radio"
				name="data_source"
				value="syslog"
				tabindex=1
				<?php if(strtolower("{$FWLOG["data_source"]}") == "syslog") print "checked\n"; ?>
			>
			Syslog
			&nbsp;&nbsp;Path:&nbsp;
		 	<?php print "{$config["syslog_dir"]}/"; ?>
			&nbsp;File(s):&nbsp;
			<input
				type="text"
				size="20"
				name="syslog_file"
				value="<?php print htmlspecialchars("{$FWLOG['syslog_file']}", ENT_QUOTES); ?>"
				tabindex=1
			>
			<br><br>
			Use these controls to select the data source for saved reports run from the above links.  Selecting<br>
			Default will use the data source specified in report definition.  Selecting Ulogd will use data logged<br>
			in a database using the ulogd target of linux netfilter.  You can also select the ulog table to use,<br>
			overriding the table specified in report definition.  Selecting Syslog will use the system log files specified.<br>
			After making changes press the Select Data Source button to update the links on this page.

		<?php } else { ?>

			<a href="<?php print "$self"; ?>?show_select_data_source=1<?php print "&restore=yes" ?>">
				Show Select Data Source
			</a>

		<?php } ?>

		</td>
	</tr>
</table>
</td>
</tr>

<tr>
	<td colspan=4>
	<h2><a name=welcome>User&#039;s Guide to Webfwlog</a></h2>
	<h3>Welcome to the Webfwlog Home Page</h3>
	<dl>
		<dt>Report list</dt>
			<dd>Using the <a href='<?php print "$self"; ?>?action=create+new'>Report Editor</a> you can create, import, modify, and save report difinitions,<br>
				and saved report definitions will be listed here.  Clicking on the link in the code column<br>
				will run the report from the saved definition.  If you want to create a link to a report on your desktop<br>
				or on another web page you should copy and paste the link that appears here.<br>
				Clicking on the link in the edit column will bring up the report editor with the saved settings of<br>
				the selected report</dd>
			<dd>You will only be able to save reports and see a list of them here if you have set up webfwlog to use<br>
				a database server and have set up the reports table.  See the README file for more information.</dd>
		<dt><a name=editor>Report Editor button</a></dt>
			<dd>Press the Report Editor button to bring up the report editor with default settings.  From there you<br>
				can create, import, modify and save report definitions.  See the documentation on the Report Editor<br>
				page for more information.</dd>
		<dt>Sorting report list</dt>
			<dd>You can change the order in which reports are sorted by selecting the desired column and pressing<br>
				the Sort button.  You can set the default sort order in the webfwlog.conf file using the report_order<br>
				parameter.</dd>
		<dt>Navigating reports</dt>
			<dd>If selected in the report definition using the report editor, some cells will have links that will allow<br>
				&quot;drill-down&quot; on the report.  Generally, clicking on a link in a report will filter the report by the item<br>
				in the cell selected.  For example, if you have a report that has tcp, udp and icmp packets included,<br>
				clicking on a link in the protocol column that shows &quot;tcp&quot; will redisplay the report with all other<br>
				settings the same but showing only rows for tcp packets.  You can further filter the report by clicking<br>
				on a link in another column.  Continuing the example, clicking on a link in the source IP column<br>
				will filter the report by the source IP selected, and you will now see a report showing only tcp packets<br>
				from that source IP.<br>
				<br>
				One exception to this is the Count column on summarized reports.  Clicking on a link in this column<br>
				will show an unsummarized report showing the individual logged entries that make up that line.  For<br>
				example, if the count column shows &quot;12&quot; clicking on the link will show the 12 logged entries.<br>
				<br>
				The other exception is the Packet column, which shows a unique auto-generated id for each logged<br>
				packet.  Clicking on a link in the Packet column will show all the details for that packet,<br>
				whether or not they appear in the report.<br>
				<br>
				Certain columns will never have links because links would not be meaningful.  These include<br>
				all date/time columns as well as looked-up columns such as hostnames and service names.<br>
				<br>
				In addition, there are always links in the column headings on reports.  Clicking on a link in a column<br>
				heading will sort the report by that column.  Clicking on the column heading again will reverse the order in<br>
				which the column is sorted.<br>
				<br>
				There are also &quot;Home&quot; and &quot;Edit this report&quot; links above the report body that can be used<br>
				to return to the home page or edit the displayed report definition, respectively.</dd>
		<dt><a name="update_cache">Update Cache</a></dt>
			<dd>Press the Update Cache button to update the <a href='<?php print "$self"; ?>?action=create+new#hostname'>hostname and services caches</a> immediately.  Check the<br>
				All box if your data is logged in a ulogd database and you want to update all new hosts and services<br>
				in the logged data.  If this box is not checked then only hosts and services previously marked for<br>
				update with the Populate Hostname Cache option will be updated.<br>
				<br>
				Please be aware that this may take a LONG time depending upon how many new unique IPs are<br>
				found.  You may cancel this operation at any time, and any hostnames already <br>
				updated will be saved and not need to be updated again.</dd>
		<dt>Select Data Source</dt>
			<dd>You can override the data source of a saved report at runtime.  If you see is a link that reads<br>
				&quot;Show Select Data Source&quot;, clicking it will show the controls and documentation.  If you see the<br>
				controls and want to hide them click on the &quot;hide&quot; link.  You can set whether to show or hide these<br>
				controls by default using the show_select_data_source parameter in the webfwlog.conf file.</dd>
	</dl>
	</td>
</tr>
</table>

<?php db("close", $link); ?>

</form>
</font>

</body>
</html>
