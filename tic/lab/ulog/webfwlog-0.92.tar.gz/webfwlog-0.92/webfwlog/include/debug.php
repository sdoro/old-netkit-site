<?php
/*
$Id: debug.php,v 1.13 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

debugging stuff

This code is distributed under the terms of GNU GPL
*/
?>

<!--
<?php
print "PHP version:\t\t" . phpversion() . "\n";
print "PHP_SELF:\t\t$self\n";
print "Database version:\t" . "{$dbver["version"]}\n";
?>
-->
<!--
<?php
if ($config["debug"] >= 10) {
	readfile("$conffile");
	print "\n";
}
echo "\t\$config\n";
foreach ($config as $a => $b) {
	echo "$a\t\t$b\n";
}
?>
-->
<!--
<?php
echo "\t\$_SERVER\n\n";
foreach ($_SERVER as $a => $b) {
	echo "$a\t\t$b\n";
}
?>
-->
<!--
<?php
echo "\t\$_SESSION\n\n";
foreach ($_SESSION as $a => $b) {
	if (is_array($b)) {
		echo "$a\t\t$b\n";
		foreach ($b as $j => $k) {
			echo "  $j\t\t".str_replace("-->", "--&gt;", "$k")."\n";
		}
	} else {
		echo "$a\t\t$b\n";
	}
}
print "SID = " . SID . "\n";
?>
-->
<!--
<?php
echo "\t\$_COOKIE\n\n";
foreach ($_COOKIE as $a => $b) {
	echo "$a\t\t$b\n";
}
?>
-->
<!--
<?php
echo "\t\$_POST\n\n";
foreach ($_POST as $a => $b) {
	echo "$a\t\t".str_replace("-->", "--&gt;", "$b")."\n";
}
?>
-->
<!--
<?php
echo "\t\$_GET\n\n";
foreach ($_GET as $a => $b) {
	echo "$a\t\t".str_replace("-->", "--&gt;", "$b")."\n";
}
?>
-->
<!--
<?php
echo "\t\$state_get\n";
foreach($state_get as $lev => $params) {
	echo "\n\tLevel $lev\n";
	foreach ($params as $a => $b) {
		echo "$a\t\t".str_replace("-->", "--&gt;", "$b")."\n";
	}
}
?>
-->
<!--
<?php
echo "\t\$fwlog_source\n\n";
if ($_SESSION["fwlog_source"])
foreach ($_SESSION["fwlog_source"] as $a => $b) {
	echo "$a\t\t".str_replace("-->", "--&gt;", "$b")."\n";
}
?>
-->
<!--
<?php
echo "\t\$options\n\n";
if ($_SESSION["options"])
foreach ($_SESSION["options"] as $a => $b) {
	echo "$a\t\t$b\n";
}
?>
-->
<!--
<?php
echo "\t\$FWLOG\n\n";
foreach ($FWLOG as $a => $b) {
	echo "$a\t\t".str_replace("-->", "--&gt;", "$b")."\n";
}
?>
-->
