<?php
/*
$Id: syslog.php,v 1.9 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

syslog report generation for webfwlog

Webfwlog is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
    
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
?>

<?php
	unset ($FWLOG["action"]); // don't save these
	unset ($FWLOG["page"]);
	unset ($FWLOG["orig_report"]);
	unset ($FWLOG["select_report"]);
	unset ($FWLOG["export_report"]);
	unset ($FWLOG["update_all"]);

	$query = $query . "db={$config["db"]}\n";

	$query = $query . "mysql_user={$config["mysql_user"]}\n";
	$query = $query . "mysql_server={$config["mysql_server"]}\n";
	$query = $query . "mysql_pass={$config["mysql_pass"]}\n";
	$query = $query . "mysql_wfwl_db={$config["mysql_wfwl_db"]}\n";

	$query = $query . "pgsql_user={$config["pgsql_user"]}\n";
	$query = $query . "pgsql_server={$config["pgsql_server"]}\n";
	$query = $query . "pgsql_pass={$config["pgsql_pass"]}\n";
	$query = $query . "pgsql_db={$config["pgsql_db"]}\n";
	$query = $query . "pgsql_wfwl_schema={$config["pgsql_wfwl_schema"]}\n";

	$query = $query . "w_tcp_flags=yes\n";
	if ($have_namespace)
		$query = $query . "have_namespace=yes\n";

	foreach ($FWLOG as $k => $v) {
		if ($k == "report") continue;
		$query = $query . "$k=$v\n";
	}

	if (!isset($config["verbosity_level"])) $config["verbosity_level"] = 2;
	$params = " -" . str_repeat("v", max (1, min (5, $config["verbosity_level"])));

	if (isset($FWLOG["page_length"])) {
		$params = $params . " -M{$FWLOG["page_length"]}";

	if (!isset($FWLOG["start"])) {$start = 0;} else {$start = $FWLOG["start"];}
		$params = $params . " -m$start";
	}

	$wfwl_report = tempnam("", "RPT");
	$rptfile = fopen($wfwl_report, "w");
	if (!fwrite($rptfile, "$query"))
		die("Connot create temporary file");

	fclose($rptfile);
	$params = $params . " -r $wfwl_report";

	$files = preg_split("/[ ]+/","{$FWLOG["syslog_file"]}");
	foreach ($files as $f) {
		if (substr_count(stripslashes("/$f"), "/.."))
			die("Cannot use '..' in filename $f");
		if (!($f == ""))
			$filelist = $filelist . " {$FWLOG["syslog_dir"]}$f";
	}

	$params = $params . "$filelist";
	$params = $params . " 2>&1";

	if (!exec("ls $filelist")) // true if return code <> 0, e.g., no such file(s)
		die("Cannot locate input file(s) $filelist");

	exec("{$config["wfwl_syslog"]} $params", $result, $retval);
	unlink("$wfwl_report");

	$querytime = time() - $time;

?>
