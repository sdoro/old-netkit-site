<?php
/*
$Id: update_cache.php,v 1.23 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

update hostnames cache

This code is distributed under the terms of GNU GPL
*/
?>

<?php

if (!isset($sql_update)) {

	$refresh = 1;
	$link = db("open", "$database");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title>Webfwlog - Update Cache</title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<?php if ($config["debug"]) include "include/debug.php"; ?>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<?php
	$have_hostnames = db("exists", "SELECT count(*) FROM $hostnames LIMIT 1");
	$have_services  = db("exists", "SELECT count(*) FROM $services LIMIT 1");
?>
	<font size="+2">
	<p>
	Updating hostname cache now..<br>
	<br>
	This may take a LONG time...<br>
	<br>

	<form action="<?php print "$self"; ?>" method="POST">
<?php
	foreach ($FWLOG as $a => $b) {
		if (!($a == "action")) {
			print "<input type='hidden' name='".htmlspecialchars("$a", ENT_QUOTES).
				"' value='".htmlspecialchars("$b", ENT_QUOTES)."'>\n";
		}
	}
?>

	<input type="submit" name="action" value="cancel">
	<p>

<?php

} else {

// If cache is being updated at time report is run, only update
// hostnames and services appearing in report

	$refresh = 2;
}

flush();

if (isset($config["php_update_timeout"]))
	set_time_limit("{$config["php_update_timeout"]}");

if (!(strtolower("{$FWLOG["action"]}") == "update cache")
	and !(strtolower("{$FWLOG["action"]}") == "resolve hosts")
	and !($FWLOG["reporttype"] == "packet")) {
	foreach ($columnorder as $col) {
		if (!isset($FWLOG["$col"])) continue;
		switch ("$col") {
			case 'c_local_hostname': $update_where = $update_where .
				"\tAND ($ulog.local_hostname IS NULL OR ".
				"$ulog.local_hostname=$output.$q{$shortnames['local_hostname']}$q)\n";
				break;
			case 'c_oob_prefix': $update_where = $update_where .
				"\tAND ($ulog.oob_prefix IS NULL OR ".
				"$ulog.oob_prefix=$output.$q{$shortnames['oob_prefix']}$q)\n";
				break;
			case 'c_oob_in': $update_where = $update_where .
				"\tAND ($ulog.oob_in IS NULL OR ".
				"$ulog.oob_in=$output.$q{$shortnames['oob_in']}$q)\n";
				break;
			case 'c_oob_out': $update_where = $update_where .
				"\tAND ($ulog.oob_out IS NULL OR ".
				"$ulog.oob_out=$output.$q{$shortnames['oob_out']}$q)\n";
				break;
			case 'c_raw_mac': $update_where = $update_where .
				"\tAND ($ulog.raw_mac IS NULL OR ".
				"$ulog.raw_mac=$output.$q{$shortnames['raw_mac']}$q)\n";
				break;
			case 'c_pwsniff_user': $update_where = $update_where .
				"\tAND ($ulog.pwsniff_user IS NULL OR ".
				"$ulog.pwsniff_user=$output.$q{$shortnames['pwsniff_user']}$q)\n";
				break;
			case 'c_pwsniff_pass': $update_where = $update_where .
				"\tAND ($ulog.pwsniff_pass IS NULL OR ".
				"$ulog.pwsniff_pass=$output.$q{$shortnames['pwsniff_pass']}$q)\n";
				break;
			case 'c_ip_saddr':
				if ($config["iptype"] == "int") {
					$update_where = $update_where .
					"\tAND ip_saddr=$inet_aton($output.$q{$shortnames['ip_saddr']}$q)\n";
				} else {
					$update_where = $update_where .
					"\tAND ip_saddr=$output.$q{$shortnames['ip_saddr']}$q\n";
				}
				break;
			case 'c_ip_daddr':
				if ($config["iptype"] == "int") {
					$update_where = $update_where .
					"\tAND ip_daddr=$inet_aton($output.$q{$shortnames['ip_daddr']}$q)\n";
				} else {
					$update_where = $update_where .
					"\tAND ip_daddr=$output.$q{$shortnames['ip_daddr']}$q\n";
				}
				break;
			case 'c_icmp_gateway': $update_where = $update_where .
				"\tAND ($ulog.icmp_gateway IS NULL OR ".
				"$ulog.icmp_gateway=$inet_aton($output.$q{$shortnames['icmp_gateway']}$q))\n";
				break;
			case 'c_dport': $update_where = $update_where .
				"\tAND ($ulog.ip_protocol<>6 AND $ulog.ip_protocol<>17\n".
				"\t\tOR $ulog.ip_protocol=6 AND $ulog.tcp_dport=".cast_int("$output.$q{$shortnames['dport']}$q")."\n".
				"\t\tOR $ulog.ip_protocol=17 AND $ulog.udp_dport=".cast_int("$output.$q{$shortnames['dport']}$q").")\n";
				break;
			case 'c_sport': $update_where = $update_where .
				"\tAND ($ulog.ip_protocol<>6 AND $ulog.ip_protocol<>17\n".
				"\t\tOR $ulog.ip_protocol=6 AND $ulog.tcp_sport=".cast_int("$output.$q{$shortnames['sport']}$q")."\n".
				"\t\tOR $ulog.ip_protocol=17 AND $ulog.udp_sport=".cast_int("$output.$q{$shortnames['sport']}$q").")\n";
				break;
			case 'c_ip_protocol': $update_where = $update_where .
				"\tAND $ulog.ip_protocol=\n".
				"\t\tCASE $output.$q{$shortnames['ip_protocol']}$q\n".
				"\t\t\tWHEN 'icmp' THEN 1 WHEN 'tcp' THEN 6 WHEN 'udp' THEN 17\n".
				"\t\t\tELSE ".cast_int("$output.$q{$shortnames['ip_protocol']}$q")."\n".
				"\t\tEND\n";
				break;
			case 'c_tcp_options': $update_where = $update_where .
				"\tAND ($ulog.ip_protocol<>6 OR (\n".
				"\t\t    CASE WHEN $output.$q{$shortnames['tcp_options']}$q $regexp '[Ss]' AND $ulog.tcp_syn\n".
				"\t\t\tTHEN $ulog.tcp_syn ELSE NOT $ulog.tcp_syn END\n".
				"\t\tAND CASE WHEN $output.$q{$shortnames['tcp_options']}$q $regexp 'a' AND $ulog.tcp_ack\n".
				"\t\t\tTHEN $ulog.tcp_ack ELSE NOT $ulog.tcp_ack END\n".
				"\t\tAND CASE WHEN $output.$q{$shortnames['tcp_options']}$q $regexp 'f' AND $ulog.tcp_fin\n".
				"\t\t\tTHEN $ulog.tcp_fin ELSE NOT $ulog.tcp_fin END\n".
				"\t\tAND CASE WHEN $output.$q{$shortnames['tcp_options']}$q $regexp 'r' AND $ulog.tcp_rst\n".
				"\t\t\tTHEN $ulog.tcp_rst ELSE NOT $ulog.tcp_rst END\n".
				"\t\tAND CASE WHEN $output.$q{$shortnames['tcp_options']}$q $regexp 'p' AND $ulog.tcp_psh\n".
				"\t\t\tTHEN $ulog.tcp_psh ELSE NOT $ulog.tcp_psh END\n".
				"\t\tAND CASE WHEN $output.$q{$shortnames['tcp_options']}$q $regexp 'u' AND $ulog.tcp_urg\n".
				"\t\t\tTHEN $ulog.tcp_urg ELSE NOT $ulog.tcp_urg END\n".
				"\t))\n";
				break;
			case 'c_oob_time_usec': $update_where = $update_where .
				"\tAND ($ulog.oob_time_usec IS NULL OR ".
				"$ulog.oob_time_usec=".cast_int("$output.$q{$shortnames['oob_time_usec']}$q").")\n";
				break;
			case 'c_oob_mark': $update_where = $update_where .
				"\tAND ($ulog.oob_mark IS NULL OR ".
				"$ulog.oob_mark=".cast_int("$output.$q{$shortnames['oob_mark']}$q").")\n";
				break;
			case 'c_ip_tos': $update_where = $update_where .
				"\tAND ($ulog.ip_tos IS NULL OR ".
				"$ulog.ip_tos=".cast_int("$output.$q{$shortnames['ip_tos']}$q").")\n";
				break;
			case 'c_ip_ttl': $update_where = $update_where .
				"\tAND ($ulog.ip_ttl IS NULL OR ".
				"$ulog.ip_ttl=".cast_int("$output.$q{$shortnames['ip_ttl']}$q").")\n";
				break;
			case 'c_ip_totlen': $update_where = $update_where .
				"\tAND ($ulog.ip_totlen IS NULL OR ".
				"$ulog.ip_totlen=".cast_int("$output.$q{$shortnames['ip_totlen']}$q").")\n";
				break;
			case 'c_ip_ihl': $update_where = $update_where .
				"\tAND ($ulog.ip_ihl IS NULL OR ".
				"$ulog.ip_ihl=".cast_int("$output.$q{$shortnames['ip_ihl']}$q").")\n";
				break;
			case 'c_ip_csum': $update_where = $update_where .
				"\tAND ($ulog.ip_csum IS NULL OR ".
				"$ulog.ip_csum=".cast_int("$output.$q{$shortnames['ip_csum']}$q").")\n";
				break;
			case 'c_ip_id': $update_where = $update_where .
				"\tAND ($ulog.ip_id IS NULL OR ".
				"$ulog.ip_id=".cast_int("$output.$q{$shortnames['ip_id']}$q").")\n";
				break;
			case 'c_ip_fragoff': $update_where = $update_where .
				"\tAND ($ulog.ip_fragoff IS NULL OR ".
				"$ulog.ip_fragoff=".cast_int("$output.$q{$shortnames['ip_fragoff']}$q").")\n";
				break;
			case 'c_tcp_seq': $update_where = $update_where .
				"\tAND ($ulog.tcp_seq IS NULL OR ".
				"$ulog.tcp_seq=".cast_int("$output.$q{$shortnames['tcp_seq']}$q").")\n";
				break;
			case 'c_tcp_ackseq': $update_where = $update_where .
				"\tAND ($ulog.tcp_ackseq IS NULL OR ".
				"$ulog.tcp_ackseq=".cast_int("$output.$q{$shortnames['tcp_ackseq']}$q").")\n";
				break;
			case 'c_tcp_window': $update_where = $update_where .
				"\tAND ($ulog.tcp_window IS NULL OR ".
				"$ulog.tcp_window=".cast_int("$output.$q{$shortnames['tcp_window']}$q").")\n";
				break;
			case 'c_tcp_urgp': $update_where = $update_where .
				"\tAND ($ulog.tcp_urgp IS NULL OR ".
				"$ulog.tcp_urgp=".cast_int("$output.$q{$shortnames['tcp_urgp']}$q").")\n";
				break;
			case 'c_udp_len': $update_where = $update_where .
				"\tAND ($ulog.udp_len IS NULL OR ".
				"$ulog.udp_len=".cast_int("$output.$q{$shortnames['udp_len']}$q").")\n";
				break;
			case 'c_icmp_type': $update_where = $update_where .
				"\tAND ($ulog.icmp_type IS NULL OR ".
				"$ulog.icmp_type=".cast_int("$output.$q{$shortnames['icmp_type']}$q").")\n";
				break;
			case 'c_icmp_code': $update_where = $update_where .
				"\tAND ($ulog.icmp_code IS NULL OR ".
				"$ulog.icmp_code=".cast_int("$output.$q{$shortnames['icmp_code']}$q").")\n";
				break;
			case 'c_icmp_echoid': $update_where = $update_where .
				"\tAND ($ulog.icmp_echoid IS NULL OR ".
				"$ulog.icmp_echoid=".cast_int("$output.$q{$shortnames['icmp_echoid']}$q").")\n";
				break;
			case 'c_icmp_echoseq': $update_where = $update_where .
				"\tAND ($ulog.icmp_echoseq IS NULL OR ".
				"$ulog.icmp_echoseq=".cast_int("$output.$q{$shortnames['icmp_echoseq']}$q").")\n";
				break;
			case 'c_icmp_fragmtu': $update_where = $update_where .
				"\tAND ($ulog.icmp_fragmtu IS NULL OR ".
				"$ulog.icmp_fragmtu=".cast_int("$output.$q{$shortnames['icmp_fragmtu']}$q").")\n";
				break;
			case 'c_ahesp_spi': $update_where = $update_where .
				"\tAND ($ulog.ahesp_spi IS NULL OR ".
				"$ulog.ahesp_spi=".cast_int("$output.$q{$shortnames['ahesp_spi']}$q").")\n";
				break;
		default: break;
		}
	}
}

if ($update_where) { // Remove leading ' AND '
	$update_where = substr($update_where,5);
} else {
	$update_where = "$true\n";
}

if (!$where)
	$where = "$true\n";

if (!(strtolower("{$FWLOG["action"]}") == "update cache" and !isset($FWLOG["update_all"]))) {
	if (!db("exists", "SELECT 1 from $output limit 1")) {
		db("statement", "CREATE TEMPORARY TABLE $output (refresh integer)");
		db("statement", "INSERT INTO $output VALUES (1)");
	}
	db("statement",
		"CREATE TEMPORARY TABLE $tmp_output AS\n".
			"\tSELECT $ulog.* FROM $output, $ulog\n".
			"\tWHERE $where".
			"\tAND $update_where;"
	);
}

if ($config["iptype"] == "int") {
	$ip_saddr = "$tmp_output.ip_saddr";
	$ip_daddr = "$tmp_output.ip_daddr";
} else {
	$ip_saddr = "$inet_aton($tmp_output.ip_saddr)";
	$ip_daddr = "$inet_aton($tmp_output.ip_daddr)";
}

$hostupdatetime = 0;
$servicesupdatetime = 0;
$cachepopulatetime = 0;

if ($have_hostnames and (isset($FWLOG["c_dst_host"]) or isset($FWLOG["c_src_host"])
		or $FWLOG["populate_cache"] 
		or strtolower("{$FWLOG["action"]}") == "update cache"
		or strtolower("{$FWLOG["action"]}") == "resolve hosts")) {
	if (isset($sql_update) and $config["db"] == "mysql") { 
		db("statement",
			"CREATE TEMPORARY TABLE $update\n".
				"\t(refresh INTEGER UNSIGNED NOT NULL DEFAULT 1,\n".
				"\tip_addr INTEGER UNSIGNED DEFAULT NULL)"
		);
	}
	if (isset($sql_update) and isset($FWLOG["upd_hosts"]) and isset($FWLOG["c_dst_host"])) {
		if ($config["db"] == "mysql") {
			db("statement",
				"INSERT INTO $update (refresh, ip_addr)\n".
					"\tSELECT DISTINCT 2, $ip_daddr FROM $tmp_output\n".
					"\t\tLEFT JOIN $hostnames ON $ip_daddr=$hostnames.ip_addr\n".
					"\tWHERE $hostnames.ip_addr IS NULL OR $hostnames.refresh=1"
			);
		} elseif ($config["db"] == "pgsql") {
			db("statement",
				"UPDATE $hostnames SET refresh=2 FROM $tmp_output\n".
					"\tWHERE $hostnames.ip_addr=$ip_daddr\n".
					"\tAND $hostnames.refresh=1;"
			);
			db("statement",
				"INSERT INTO $hostnames (refresh, ip_addr)\n".
					"\tSELECT DISTINCT 2, $ip_daddr FROM $tmp_output\n".
					"\t\tLEFT JOIN $hostnames ON $ip_daddr=ip_addr\n".
					"\tWHERE ip_addr IS NULL;"
			);
		}
	}
	if (isset($sql_update) and isset($FWLOG["upd_hosts"]) and isset($FWLOG["c_src_host"])) {
		if ($config["db"] == "mysql") {
			db("statement",
				"INSERT INTO $update (refresh, ip_addr)\n".
					"\tSELECT DISTINCT 2, $ip_saddr FROM $tmp_output\n".
					"\t\tLEFT JOIN $hostnames ON $ip_saddr=$hostnames.ip_addr\n".
					"\tWHERE $hostnames.ip_addr IS NULL OR $hostnames.refresh=1"
			);
		} elseif ($config["db"] == "pgsql") {
			db("statement",
				"UPDATE $hostnames SET refresh=2 FROM $tmp_output\n".
					"\tWHERE $hostnames.ip_addr=$ip_saddr\n".
					"\tAND $hostnames.refresh=1;"
			);
			db("statement",
				"INSERT INTO $hostnames (refresh, ip_addr)\n".
					"\tSELECT DISTINCT 2, $ip_saddr FROM $tmp_output\n".
					"\t\tLEFT JOIN $hostnames ON $ip_saddr=ip_addr\n".
					"\tWHERE ip_addr IS NULL;"
			);
		}
	}
	if (isset($sql_update) and isset($FWLOG["upd_hosts"]) and $config["db"] == "mysql") {
		db("statement",
			"REPLACE INTO $hostnames (refresh, ip_addr)\n".
				"\tSELECT DISTINCT refresh, ip_addr FROM $update"
		);
		db("statement", "DROP TABLE $update");
	}
	$hostupdatetime = time() - $time - $querytime;
	if ((isset($sql_update) and isset($FWLOG["populate_cache"]))
		or (strtolower("{$FWLOG["action"]}") == "update cache" and isset($FWLOG["update_all"]))) {
		if ($config["db"] == "mysql") {
			db("statement",
				"INSERT IGNORE INTO $hostnames (refresh, ip_addr)\n".
					"\tSELECT DISTINCT 1, $ip_daddr FROM $tmp_output\n"
			);
			db("statement",
				"INSERT IGNORE INTO $hostnames (refresh, ip_addr)\n".
					"\tSELECT DISTINCT 1, $ip_saddr FROM $tmp_output\n"
			);
		} elseif ($config["db"] == "pgsql") {
			db("statement",
				"INSERT INTO $hostnames (refresh, ip_addr)\n".
					"\tSELECT DISTINCT 1, $ip_daddr FROM $tmp_output\n".
					"\t\tLEFT JOIN $hostnames ON $ip_daddr=ip_addr\n".
					"\tWHERE ip_addr IS NULL\n".
					"\tUNION\n".
					"\tSELECT DISTINCT 1, $ip_saddr FROM $tmp_output\n".
					"\t\tLEFT JOIN $hostnames ON $ip_saddr=ip_addr\n".
					"\tWHERE ip_addr IS NULL;"
			);
		}
	}
	$cachepopulatetime = time() - $time - $hostupdatetime - $querytime;
	$newhosts = db("statement", "SELECT ip_addr FROM $hostnames WHERE refresh>=$refresh;");
	$newrows = db("totalrows", $newhosts);
	if (!isset($sql_update)) {
		print "$newrows New unique hosts found!<br>\n";
		if ($newrows) print "Resolving $newrows new hostnames ";
		flush();
	}

	$tick_count = 10;
	$progress = $tick_count;
	$rownum = 0;
	while ($line = db("nextrow", $newhosts)) {
		if (!isset($sql_update) and ++$progress > $tick_count) {
			print ". ";
			flush();
			$progress = 0;
		}
		$addr = "{$line["ip_addr"]}";
		$dotted = long2ip($addr);
		$host = gethostbyaddr("$dotted");
		if ($host == "$dotted") $host = "-";
		db("statement", "UPDATE $hostnames SET refresh=0, hostname='$host' WHERE ip_addr=$addr;");
	}
	if (!isset($sql_update))
		print "<br>\n";

	$hostupdatetime = time() - $time - $cachepopulatetime - $querytime;
}
if (!isset($sql_update)) {
	print "<br>\n";
	$hostupdatetime = $hostupdatetime + $cachepopulatetime;
	$cachepopulatetime = 0;
}

if ($have_services and (isset($FWLOG["c_dst_service"]) or isset($FWLOG["c_src_service"])
		or $FWLOG["populate_cache"] 
		or strtolower("{$FWLOG["action"]}") == "update cache"
		or strtolower("{$FWLOG["action"]}") == "resolve hosts")) {
	if ($config["db"] == "mysql") {
		if (isset($sql_update) and isset($FWLOG["upd_hosts"])) 
			db("statement",
				"CREATE TEMPORARY TABLE $update\n".
					"\t(refresh INTEGER UNSIGNED NOT NULL DEFAULT 1,\n".
					"\tip_protocol INTEGER UNSIGNED DEFAULT NULL,\n".
					"\tport INTEGER UNSIGNED NULL DEFAULT NULL)"
			);
	}
	if (isset($sql_update) and isset($FWLOG["upd_hosts"]) and isset($FWLOG["c_dst_service"])) {
		if ($config["db"] == "mysql") {
			db("statement",
				"INSERT INTO $update (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 2, $tmp_output.ip_protocol, $tmp_output.tcp_dport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND tcp_dport=$services.port\n".
					"\tWHERE (tcp_dport IS NOT NULL AND ($services.port IS NULL OR $services.refresh=1))"
			);
			db("statement",
				"INSERT INTO $update (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 2, $tmp_output.ip_protocol, $tmp_output.udp_dport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND udp_dport=$services.port\n".
					"\tWHERE (udp_dport IS NOT NULL AND ($services.port IS NULL OR $services.refresh=1))"
			);
		} elseif ($config["db"] == "pgsql") {
			db("statement",
				"UPDATE $services SET refresh=2 FROM $tmp_output\n".
					"\tWHERE $services.ip_protocol=$tmp_output.ip_protocol\n".
					"\tAND (port=tcp_dport OR port=udp_dport)\n".
					"\tAND $services.refresh=1;"
			);
			db("statement",
				"INSERT INTO $services (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 2, $tmp_output.ip_protocol, udp_dport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND udp_dport=port\n".
					"\tWHERE (udp_dport IS NOT NULL AND port IS NULL)\n".
					"\tUNION\n".
					"\tSELECT DISTINCT 2, $tmp_output.ip_protocol, tcp_dport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND tcp_dport=port\n".
					"\tWHERE (tcp_dport IS NOT NULL AND port IS NULL);"
			);


		}
	}
	if (isset($sql_update) and isset($FWLOG["upd_hosts"]) and isset($FWLOG["c_src_service"])) {
		if ($config["db"] == "mysql") {
			db("statement",
				"INSERT INTO $update (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 2, $tmp_output.ip_protocol, $tmp_output.tcp_sport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND tcp_sport=$services.port\n".
					"\tWHERE (tcp_sport IS NOT NULL AND ($services.port IS NULL OR $services.refresh=1))"
			);
			db("statement",
				"INSERT INTO $update (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 2, $tmp_output.ip_protocol, $tmp_output.udp_sport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND udp_sport=$services.port\n".
					"\tWHERE (udp_sport IS NOT NULL AND ($services.port IS NULL OR $services.refresh=1))"
			);
		} elseif ($config["db"] == "pgsql") {
			db("statement",
				"UPDATE $services SET refresh=2 FROM $tmp_output\n".
					"\tWHERE $services.ip_protocol=$tmp_output.ip_protocol\n".
					"\tAND (port=tcp_sport OR port=udp_sport)\n".
					"\tAND $services.refresh=1;"
			);
			db("statement",
				"INSERT INTO $services (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 2, $tmp_output.ip_protocol, udp_sport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND udp_sport=port\n".
					"\tWHERE (udp_sport IS NOT NULL AND port IS NULL)\n".
					"\tUNION\n".
					"\tSELECT DISTINCT 2, $tmp_output.ip_protocol, tcp_sport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND tcp_sport=port\n".
					"\tWHERE (tcp_sport IS NOT NULL AND port IS NULL);"
			);
		}
	}
	if (isset($sql_update) and isset($FWLOG["upd_hosts"]) and $config["db"] == "mysql") {
		db("statement",
			"REPLACE INTO $services (refresh, ip_protocol, port)\n".
				"\tSELECT DISTINCT refresh, ip_protocol, port FROM $update"
		);
		db("statement", "DROP TABLE $update");
	}
	$servicesupdatetime = time() - $time - $hostupdatetime - $cachepopulatetime - $querytime;
	if ((isset($sql_update) and isset($FWLOG["populate_cache"])) 
		or strtolower("{$FWLOG["action"]}") == "update cache" and isset($FWLOG["update_all"])) {
		if ($config["db"] == "mysql") {
			db("statement",
				"INSERT IGNORE INTO $services (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 1, ip_protocol, tcp_dport FROM $tmp_output\n".
					"\tWHERE tcp_dport IS NOT NULL;"
			);
			db("statement",
				"INSERT IGNORE INTO $services (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 1, ip_protocol, tcp_sport FROM $tmp_output\n".
					"\tWHERE tcp_sport IS NOT NULL;"
			);
			db("statement",
				"INSERT IGNORE INTO $services (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 1, ip_protocol, udp_dport FROM $tmp_output\n".
					"\tWHERE udp_dport IS NOT NULL;"
			);
			db("statement",
				"INSERT IGNORE INTO $services (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 1, ip_protocol, udp_sport FROM $tmp_output\n".
					"\tWHERE udp_sport IS NOT NULL;"
			);
		} elseif ($config["db"] == "pgsql") {
			db("statement",
				"INSERT INTO $services (refresh, ip_protocol, port)\n".
					"\tSELECT DISTINCT 1, $tmp_output.ip_protocol, tcp_dport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND tcp_dport=port\n".
					"\tWHERE (tcp_dport IS NOT NULL AND port IS NULL)\n".
					"\tUNION\n".
					"\tSELECT DISTINCT 1, $tmp_output.ip_protocol, udp_dport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND udp_dport=port\n".
					"\tWHERE (udp_dport IS NOT NULL AND port IS NULL)\n".
					"\tUNION\n".
					"\tSELECT DISTINCT 1, $tmp_output.ip_protocol, tcp_sport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND tcp_sport=port\n".
					"\tWHERE (tcp_sport IS NOT NULL AND port IS NULL)\n".
					"\tUNION\n".
					"\tSELECT DISTINCT 1, $tmp_output.ip_protocol, udp_sport FROM $tmp_output\n".
					"\t\tLEFT JOIN $services\n".
					"\t\t\tON $tmp_output.ip_protocol=$services.ip_protocol AND udp_sport=port\n".
					"\tWHERE (udp_sport IS NOT NULL AND port IS NULL);"
			);

		}
	}
	$cachepopulatetime = time() - $time - $hostupdatetime - $servicesupdatetime - $querytime;
	$newservices = db("statement", "SELECT port, ip_protocol FROM $services WHERE refresh>=$refresh;");
	$newrows = db("totalrows", $newservices);
	if (!isset($sql_update)) {
		print "$newrows New services found!<br>\n";
		if ($newrows) print "Resolving $newrows new services . . . <br>\n";
		flush();
	}
	$rownum = 0;
	while ($line = db("nextrow", $newservices)) {
		$port = $line["port"];
		$proto = $line["ip_protocol"];
		$service = getservbyport($port, getprotobynumber($proto));
		if ($service == "") $service = "-";
		db("statement", "UPDATE $services SET refresh=0, service='$service' WHERE port=$port AND ip_protocol=$proto;");
	}
	$servicesupdatetime = time() - $time - $hostupdatetime - $cachepopulatetime - $querytime;
}
if (!isset($sql_update)) {
	print "<br>\n";

	$serviceupdatetime = $servicesupdatetime + $cachepopulatetime;

	db("close", $link);

	print "Host Update time was $hostupdatetime seconds<br>\n";
	print "Services Update time was $servicesupdatetime seconds<br>\n";

?>
	<p>
	<input type="submit" name="action" value="Done">
	</font>
	
</body>
</html>
<?php
}
?>
