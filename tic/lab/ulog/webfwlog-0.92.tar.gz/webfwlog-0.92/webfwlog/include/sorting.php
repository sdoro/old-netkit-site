<?php
/*
$Id: sorting.php,v 1.11 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

report defintion order by form

This code is distributed under the terms of GNU GPL
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title>Webfwlog - Edit Report <?php print "{$FWLOG["report"]}" ?> - Sorting</title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<?php if ($config["debug"]) include "include/debug.php"; ?>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<table align="center">
<tr>
<td>
<form action="<?php print "$self"; ?>" method="POST">
<?php
	foreach ($FWLOG as $a => $b) {
		if   (!(substr($a,0,2) == "s_")
		  and !(substr($a,0,2) == "o_")
		  and !($a == "page")
		  and !($a == "summarize")
		  and !($a == "sorting")) {
			print "<input type='hidden' name='".htmlspecialchars("$a", ENT_QUOTES).
				"' value='".htmlspecialchars("$b", ENT_QUOTES)."'>\n";
		}
	}
?>
<input type="hidden" name="page" value="sorting">

<table align="center" border="1">
	<tr>
	<td>
	 <!-- Sorting menu -->
	<table>
		<caption align="left" style="{font-size: 110%; font-weight: bold;}">
			SUMMARIZE REPORT: <input type="checkbox" name="summarize" value="on" 
			<?php if ($FWLOG["summarize"]) print "checked"; ?>></caption>
	<?php 
		$numrows = 15;
		$numcols = 3;
		print "<tr>";
		for ($a = 0; $a <= ($numcols - 1);  $a++) {
			echo "<th scope=col>Sort</th>",
				 "<th title='Check to sort in Decending order' scope=col>Dec</th>",
				 "<th scope=col style='width: 10em'>Sort by:</th>";
		}
		print "</tr>\n";
		for ($i = 0; $i <= ($numrows - 1);  $i++) {
			print "<tr>";
			for ($j = 0; $j <= ($numcols - 1); $j++) {
				$colnum = $i + $j * $numrows;
				if (!($a = $sortorder["$colnum"])) continue;
					$t = substr("$a",2);
					$o = $a; $o[0] = "o";
					$l = $longnames["$t"];
	?> 
		<td align="center">
			<input
				type="text"
				class="num"
				size="3"
				maxlength="4"
				name="<?php print "$a"?>"
				value="<?php echo "{$FWLOG["$a"]}"?>"
				tabindex=<?php print "$j"; ?>
			>
		</td>
		<td align="center">
			<input
				type="checkbox"
				<?php if ("{$FWLOG["$o"]}") print "checked"; ?>
				name="<?php print "$o"?>"
				value="on"
				tabindex=<?php print "$j"; ?>
			>
		</td>
		<td ><?php print "{$longnames["$t"]}";?></td>
	<?php
			}
		print "</tr>\n";
		}
	?>
	</table>
	</td>
	</tr>
	<tr>
		<td>
		<input type="submit" name="action" value="Refresh">&nbsp;
		<input type="reset" value="Reset">
		<input type="submit" name="action" value="Accept">&nbsp;
		</td>
	</tr>
</table>
</form>
</td>
</tr>
<?php
	$doc_page = "sort";
	include "include/edit_doc.php";
?>
</table>

</body>
</html>
