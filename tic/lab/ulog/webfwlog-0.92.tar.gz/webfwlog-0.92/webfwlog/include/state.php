<?php
/*
$Id: state.php,v 1.32 2006/03/04 15:41:26 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

state maintainence for webfwlog

This code is distributed under the terms of GNU GPL
*/

// Get state from saved session data if it exists

if (isset($config["session_save_path"]))
	session_save_path("{$config["session_save_path"]}");

session_name("webfwlog_sessid");
session_start();

if(!$_SESSION["sessiontest"]) { 
	if ($_GET["sessiontest"]) {
		if ($config["debug"]) include "include/debug.php";
		die("Cookies must be enabled or session IDs must be propagated transparently in order to use webfwlog");
	} else {
		$_SESSION["sessiontest"] = 1;
			$loc = "sessiontest=1&original_request=".urlencode("{$_SERVER["QUERY_STRING"]}");
			if (ini_get("session.use_trans_sid")) $loc = "$loc&" . SID;
			header("location: $self?$loc"); 
	}
} else {
	if (isset($_GET["original_request"])) {
		unset ($loc);
		if ($_GET["original_request"]) $loc = "?{$_GET["original_request"]}";
		if (ini_get("session.use_trans_sid")) {
			if ($loc) {$loc = "$loc&";} else {$loc = "?";}
			$loc = "$loc" . SID;
		}
		$loc = "$self$loc";
		header("location: $loc");
	}
}

$link = db("open", "$database");

if ("{$config["db"]}" <> "none")
	$result = db("exists", "SELECT version() AS version");

if ($config["db"] == "pgsql") {
	$pg_version = array();
	$row = 0;
	$dbver = db("nextrow", $result);
	if (ereg("^ *PostgreSQL ([^ ]+) .*$", "{$dbver["version"]}", $pgver))
		$pg_version = explode('.', "{$pgver[1]}", 3);	

	if ($pg_version[0] < 7 or ($pg_version[0] == 7 and $pg_version[1] < 1))
		die("PostgresSQL >= 7.1 is required\n");

	if (db("exists", "SELECT count(*) from pg_catalog.pg_namespace")) {
		$have_namespace = 1;
		$ulog = "$ulogd.{$config["pgsql_ulog_table"]}";
		$reports = "{$config["pgsql_wfwl_schema"]}.reports";
		$hostnames = "{$config["pgsql_wfwl_schema"]}.hostnames";
		$services = "{$config["pgsql_wfwl_schema"]}.services";
		$webfwlog_aton = "{$config["pgsql_wfwl_schema"]}.webfwlog_aton";
		$webfwlog_ntoa = "{$config["pgsql_wfwl_schema"]}.webfwlog_ntoa";
	} else {
		$have_namespace = 0;
		$ulog = "{$config["pgsql_ulog_table"]}";
		$reports = "reports";
		$hostnames = "hostnames";
		$services = "services";
		$webfwlog_aton = "webfwlog_aton";
		$webfwlog_ntoa = "webfwlog_ntoa";
	}
	$inet_aton="$webfwlog_aton";
	$inet_ntoa="$webfwlog_ntoa";

} else if ($config["db"] == "mysql") {
	$my_version = array();
	$dbver = db("nextrow", $result);
	if ($dbver)
		$my_version = explode('.', "{$dbver["version"]}", 3);

	if ($my_version[0] < 3 or
		(  $my_version[0] == 3 and $my_version[1] < 23) or
		(  $my_version[0] == 3 and $my_version[1] == 23 and $my_version[2] < 52)) {
			die("MySQL >= 3.23.52 is required\n"); 
	} else if ($my_version[0] == 4 and $my_version[1] == 0  and $my_version[2] < 12) {
			die("MySQL 4.0.xx >= 4.0.12 is required\n");
	} else if ($my_version[0] == 4 and $my_version[1] == 1  and $my_version[2] <  7) {
			die("MySQL 4.1.xx >= 4.1.7 is required\n");
	} else if ($my_version[0] == 5 and $my_version[1] == 0  and $my_version[2] <  15)
			die("MySQL 5.0.xx >= 5.0.15 is required\n");
}

if ($_SESSION["fwlog"]) {
	$STATE = $_SESSION["fwlog"];
	unset ($STATE["action"]);
} else {
	$STATE = array();
}

if (get_magic_quotes_gpc()) {
   $_POST = array_map('stripslashes_deep', $_POST);
   $_GET = array_map('stripslashes_deep', $_GET);
}

// Combine input in order of precedence
$FWLOG = $_POST + $STATE;

// Clear parameters if new value is null
foreach ($FWLOG as $param => $value) {
	if (!empty($_POST) and $_POST["$param"] == "") {
		unset ($FWLOG["$param"]);
	}
}

$options = array();
if (isset($_SESSION["options"]))
	$options = $_SESSION["options"];

if (isset($_POST["update_all"])) {
	$options["update_all"] = $_POST["update_all"];
} else {
	if (count($_POST))
		unset($options["update_all"]);
} 

if (isset($_POST["report_order"])) {
	$options["report_order"] = "{$_POST["report_order"]}";
} else {
	if (isset($options["report_order"])) {
		$FWLOG["report_order"] = "{$options["report_order"]}";
	} else {
		$FWLOG["report_order"] = "{$config["report_order"]}";
	}
}

// If running report from link, use those settings
if (isset($_GET["report"])) {
	$rownum = 0;
	$result = db("nextrow", db("statement", "SELECT definition FROM $reports WHERE code ='"
		.db("escape", "{$_GET['report']}")."'"));
	if ($result["definition"]) {
		unset($_SESSION["fwlog_get"]);
		unset($FWLOG);
		$FWLOG = unserialize($result["definition"]);
		$FWLOG["report"] = $_GET["report"];
	} else {
		die ("<p>Report <strong>" . htmlspecialchars("{$_GET['report']}", ENT_QUOTES)
			. "</strong> not defined!<br></p>");
	}
}

if ("{$FWLOG["action"]}" == "Resolve Hosts")
	unset($FWLOG["reporttype"]);

require 'include/orders.php';

// Save state in session data -- not from GET
$_SESSION["fwlog"] = $FWLOG;

$state_get = array();

if ($_GET) {

    if (isset($_GET["keep_source"]) or isset($_GET["restore"])) {
		unset ($FWLOG["data_source"]);
		unset ($FWLOG["ulog_table"]);
		unset ($FWLOG["syslog_file"]);

		if (isset($_GET["keep_source"])) {
			$source_state = array();
			if (isset($_GET["data_source"]))
				$source_state["data_source"] = "{$_GET["data_source"]}";
			if (isset($_GET["ulog_table"]))
				$source_state["ulog_table"] = "{$_GET["ulog_table"]}";
			if (isset($_GET["syslog_file"]))
				$source_state["syslog_file"] = "{$_GET["syslog_file"]}";
			$_SESSION["fwlog_source"] = $source_state; 
		}

		if (isset($_GET["restore"]) and $_SESSION["fwlog_source"])
			$FWLOG = $_SESSION["fwlog_source"] + $FWLOG;

		$FWLOG = $_GET + $FWLOG ;

	} else {
		if (!isset($_GET["level"]) or $_GET["level"] == "") {
			$_GET["level"] = 0;
		}

		if ($_SESSION["fwlog_get"]) {
			$state_get = $_SESSION["fwlog_get"];
		}

		if (isset($_GET["keep"])) {
			unset ($_GET["keep"]);
			$level = $_GET["level"] + 1;
			$state_get[$_GET["level"]] = $_GET;
		} else {
			$level = $_GET["level"];
		}

		// run through get levels in order to get current state of things
		$l = 0;
		while ($l <= $level - 1) {
			$old_get = $state_get[$l];
			unset($old_get["reporttype"]);
			$FWLOG = $old_get + $FWLOG ;
			foreach ($FWLOG as $param => $value) {
				if ($old_get["$param"] == "" and isset($old_get["$param"])) {
					if ($param == "c_count" or  $param == "summarize") $FWLOG["nocount"] = "on";
					unset ($FWLOG["$param"]);
				}
			}
			$FWLOG = sortit ($FWLOG);
			$l = $l + 1;
		}
		// Use parameters from GET first

		$FWLOG = $_GET + $FWLOG ;

		// Clear parameters if new value is null
		foreach ($FWLOG as $param => $value) {
			if ($_GET["$param"] == "" and isset($_GET["$param"])) {
				if ($param == "c_count" or  $param == "summarize") $FWLOG["nocount"] = "on";
				unset ($FWLOG["$param"]);
			}
		}
		require 'include/orders.php';
		$_SESSION["fwlog_get"] = $state_get;
	}	
}

if (isset($FWLOG["ulog_table"])) {
	$ulog = "$ulogd.{$FWLOG["ulog_table"]}";
}

$FWLOG["syslog_dir"] = $config["syslog_dir"] . "/";

if (!isset($FWLOG["syslog_file"]))
	$FWLOG["syslog_file"] = "{$config["syslog_filespec"]}";

if (!isset($FWLOG["show_select_data_source"]) and isset($config["show_select_data_source"]))
	$FWLOG["show_select_data_source"] = $config["show_select_data_source"];

if (isset($FWLOG["show_sql"])) {
	$FWLOG["be_verbose"] = "{$FWLOG["show_sql"]}"; // show_sql is deprecated
	unset ($FWLOG["show_sql"]);
}

if ($config["allow_raw_sql"]) { 
	if (isset($FWLOG["c_extra_value"]))
		$label = eregi_replace("^.+ *as *['\"]?([^'\"]*)['\"]? *$","\\1","{$FWLOG["c_extra_value"]}");
		$shortnames["extra"] = "$label";
		if ("$label" == "{$FWLOG["c_extra_value"]}") {
			$label = " AS \"$label\"";
		} else $label = "";
		$longnames["extra"] = "{$FWLOG["c_extra_value"]}";
}

$FWLOG = $FWLOG + $options;
$_SESSION["options"] = $options;

db("close", $link);

?>
