<?php
/*
$Id: packet.php,v 1.19 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

packet detail web output

This code is distributed under the terms of GNU GPL
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title><?php print "{$config["title"]}"; ?></title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<?php if ($config["debug"]) include "include/debug.php"; ?>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>
<?php
	$link = db("open", "$database");

	$have_hostnames = db("exists", "SELECT count(*) FROM $hostnames LIMIT 1");

	$rownum = 0;

	if ($source == "syslog") {
		$FWLOG["c_oob_in"]=0;
		$FWLOG["c_oob_out"]=0;
		$FWLOG["c_count"]=0;
		$FWLOG["c_id"]=0;
		$FWLOG["c_raw_mac"]=0;
		$FWLOG["c_local_time"]=0;
		$FWLOG["c_local_hostname"]=0;
		$FWLOG["c_earliest"]=0;
		$FWLOG["c_latest"]=0;
		$FWLOG["c_oob_earliest"]=0;
		$FWLOG["c_oob_latest"]=0;
		$FWLOG["c_oob_prefix"]=0;
		$FWLOG["c_oob_mark"]=0;
		$FWLOG["c_ip_protocol"]=0;
		$FWLOG["c_ip_saddr"]=0;
		$FWLOG["c_src_host"]=0;
		$FWLOG["c_ip_daddr"]=0;
		$FWLOG["c_dst_host"]=0;
		$FWLOG["c_ip_tos"]=0;
		$FWLOG["c_ip_ttl"]=0;
		$FWLOG["c_ip_totlen"]=0;
		$FWLOG["c_ip_ihl"]=0;
		$FWLOG["c_ip_csum"]=0;
		$FWLOG["c_ip_id"]=0;
		$FWLOG["c_ip_fragoff"]=0;
		$FWLOG["c_sport"]=0;
		$FWLOG["c_src_service"]=0;
		$FWLOG["c_dport"]=0;
		$FWLOG["c_dst_service"]=0;
		$FWLOG["c_tcp_seq"]=0;
		$FWLOG["c_tcp_ackseq"]=0;
		$FWLOG["c_tcp_window"]=0;
		$FWLOG["c_tcp_options"]=0;
		$FWLOG["c_tcp_urgp"]=0;
		$FWLOG["c_udp_len"]=0;
		$FWLOG["c_icmp_type"]=0;
		$FWLOG["c_icmp_code"]=0;
		$FWLOG["c_icmp_echoid"]=0;
		$FWLOG["c_icmp_echoseq"]=0;
		$FWLOG["c_icmp_gateway"]=0;
		$FWLOG["c_icmp_fragmtu"]=0;
		$FWLOG["c_pwsniff_user"]=0;
		$FWLOG["c_pwsniff_pass"]=0;
		$FWLOG["c_ahesp_spi"]=0;
		$FWLOG["c_tcp_options"]=0;

		require "syslog.php";

		$fields = array();

		if ($config["debug"] >= 2) print "<pre>".htmlspecialchars("$query", ENT_QUOTES)."</pre>";
		if ($FWLOG["be_verbose"] and $config["allow_be_verbose"]) {
			print "<pre>\n";
			print "Exit code: $retval\n";
			print htmlspecialchars("$params", ENT_QUOTES)."\n";
			while($line = db("nextrow", $result, "$source")) {
				print htmlspecialchars("$line", ENT_QUOTES)."\n";
			}
			print "</pre>\n";
		} else while($line = db("nextrow", $result, "$source")) {}

		$colnum = 0;
		while ($name = db("nextfield", $result, "$source")) {
			$fields[] = "$name";
		}
		$rownum = $rownum + 1;
	} else { // $source = "sql"
		$query = "select * from $ulog where $ulog.id={$FWLOG["w_id"]}";
		if ($FWLOG["be_verbose"] and $config["allow_be_verbose"]) {
			print "<pre>";
			print htmlspecialchars("$query", ENT_QUOTES)."\n";
			print "</pre>\n\n";
		}
		if ($FWLOG["upd_hosts"]) {
			$sql_update = "yes";
			$where = "$ulog.id={$FWLOG["w_id"]}\n";
			db("statement", "CREATE TEMPORARY TABLE $output AS\n$query");
			include "include/update_cache.php";
		}
		$result = db("statement", "$query");
		$rownum = 0;
	}

	$line = db("nextrow", $result, "$source");

?>

<table align="center">
<tr>
<td colspan="2" align="center">
	<h1>
		<?php
			if ($source == "syslog") {
				print "Details for log file ".htmlspecialchars("{$FWLOG['syslog_file']}", ENT_QUOTES).
					", line ".htmlspecialchars("{$FWLOG['w_id']}", ENT_QUOTES);
			} else {
				print "Details for packet ".htmlspecialchars("{$line['id']}", ENT_QUOTES);
			}
		?>
	</h1>
	<table border=1>
	<caption><strong><font size="+2">Local Info</font></strong></caption>
		<tr class=t_sheader>
			<td><?php print "{$longnames["local_hostname"]}"; ?></td>
			<td><?php print "".htmlspecialchars("{$line["local_hostname"]}", ENT_QUOTES); ?></td>
		</tr>
		<tr>
			<td><?php print "{$longnames["local_time"]}"; ?></td>
			<td><?php print date("{$config["dformat"]}", $line["local_time"]); ?></td>
		</tr>
		
		<?php if (!($source == "syslog")) { /* don't print for syslog */ ?>
		<tr>
			<td><?php print "{$longnames["oob_time_sec"]}"; ?></td>
			<td><?php print date("{$config["dformat"]}", $line["oob_time_sec"]); ?></td>
		</tr>
		<?php } ?>

<?php
	$localdata = array();
	if (!($source == "syslog"))
		$localdata[] = "oob_time_usec";
	$localdata[] = "oob_in";
	$localdata[] = "oob_out";
	$localdata[] = "oob_prefix";
	$localdata[] = "oob_mark";
	$localdata[] = "raw_mac";

	foreach ($localdata as $l) {
?>
		<tr>
			<td><?php print "{$longnames["$l"]}"; ?></td>
			<td><?php print "".htmlspecialchars("{$line["$l"]}", ENT_QUOTES); ?></td>
		</tr>
<?php
	}
?>
	</table>
</td>
</tr>

<tr>
<td valign="top">
	<br>
	<table border=1>
	<caption><strong><font size="+2">IP headers</font></strong></caption>
		<tr>
			<td>
			<?php print "{$longnames["ip_saddr"]}"; ?></td>
			<td>
			<?php
				if ($config["iptype"] == "int") {
					print long2ip($line["ip_saddr"]);
				} else {
					print "{$line["ip_saddr"]}";
					$line["ip_saddr"] = ip2long("{$line["ip_saddr"]}");
					if ($line["ip_saddr"] < 0) $line["ip_saddr"] += pow(2,32);
				}
			?>
			</td>
		</tr>
<?php
	if (isset ($line["src_host"]) and "{$line["src_host"]}" <> "-") {
		$host = "{$line["src_host"]}";
	} else {
		if ($have_hostnames) {
			$res = db("statement", "SELECT hostname FROM $hostnames WHERE ip_addr={$line["ip_saddr"]};");
			$rownum = 0;
			$l = db("nextrow", $res);
			$host = $l["hostname"];
			if ($host == "") $host = "-";
		}
	}
 ?>
		<tr>
			<td colspan="2" align="center"><?php print "$host"; ?></td>
		</tr>
		<tr>
			<td><?php print "{$longnames["ip_daddr"]}"; ?></td>
			<td>
			<?php
				if ($config["iptype"] == "int") {
					print long2ip($line["ip_daddr"]);
				} else {
					print "{$line["ip_daddr"]}";
					$line["ip_daddr"] = ip2long("{$line["ip_daddr"]}");
					if ($line["ip_daddr"] < 0) $line["ip_daddr"] += pow(2,32);
				}
			?>
			</td>
		</tr>
<?php
	if (isset ($line["dst_host"]) and "{$line["dst_host"]}" <> "-") {
		$host = "{$line["dst_host"]}";
	} else {
		if ($have_hostnames) {
			$res = db("statement", "SELECT hostname FROM $hostnames WHERE ip_addr={$line["ip_daddr"]};");
			$rownum = 0;
			$l = db("nextrow", $res);
			$host = $l["hostname"];
			if ($host == "") $host = "-";
		}
	}
 ?>
		<tr>
			<td colspan="2" align="center"><?php print "$host"; ?></td>
		</tr>
<?php
	$ipdata = array(
		"ip_tos",
		"ip_ttl",
		"ip_totlen",
		"ip_ihl",
		"ip_csum",
		"ip_id",
		"ip_fragoff"
	);

	foreach ($ipdata as $l) {
?>
		<tr>
			<?php if ($l == "ip_fragoff") {
				$flags = " ";
				$offset = $line["$l"] & ~0x4000; // IP_DF
				$offset = $offset & ~0x2000; // IP_MF
				if (($line["$l"] & 0x4000) <> 0 ) $flags = $flags . "DF ";
				if (($line["$l"] & 0x2000) <> 0 ) $flags = $flags . "MF ";
			?>
				<td><?php print "Fragment Flags"; ?></td>
				<td><?php print "$flags";?></td>
				</tr>
				<tr>
				<td><?php print "Fragment offset"; ?></td>
				<td><?php print "$offset";?></td>
			<?php } else { ?>
				<td><?php print "{$longnames["$l"]}"; ?></td>
				<td><?php print "{$line["$l"]}" ?></td>
			<?php } ?>
		</tr>
<?php
	}
?>
	</table>
</td>
<td valign="top">
<?php
	if (!($source == "syslog")){
		$proto = $line["ip_protocol"]; 
	} else {
	 	$proto=getprotobyname($line["ip_protocol"]);
	}

	switch ($proto) {
		case 17:
	$udpdata = array(
		"udp_sport",
		"udp_dport",
		"udp_len",
	);
?>
	<br>
	<table border=1>
	<caption><strong><font size="+2">Protocol UDP</font></strong></caption>
<?php
	foreach ($udpdata as $l) {
		unset ($servicename);
		if ($l == "udp_dport" or $l == "udp_sport") {
		if ($source == "syslog") {
			$l = substr($l, 4);
			if ("$l" == "sport") $servicename = "{$line["src_service"]}";
			if ("$l" == "dport") $servicename = "{$line["dst_service"]}";
		}
		if (!isset($servicename) or "$servicename" == "-"){
			$servicename = getservbyport($line["$l"], "udp");
		}
?>
		<tr>
			<td><?php print "{$longnames["$l"]}"; ?></td>
			<td><?php print "{$line["$l"]}" ?></td>
			<td><?php print "&nbsp; $servicename"; ?></td>
		</tr>
<?php
		} else {
?>
		<tr>
			<td><?php print "{$longnames["$l"]}"; ?></td>
			<td><?php print "{$line["$l"]}" ?></td>
			<td>&nbsp;</td>
		</tr>
<?php		}
	}
?>
	</table>

<?php
			break;
		case  6:
	$tcpdata = array(
		"tcp_sport",
		"tcp_dport",
		"tcp_seq",
		"tcp_ackseq",
		"tcp_window",
	);
?>
	<br>
	<table border=1>
	<caption><strong><font size="+2">Protocol TCP</font></strong></caption>
<?php
	foreach ($tcpdata as $l) {
		unset ($servicename);
		if ($l == "tcp_dport" or $l == "tcp_sport") {
		if ($source == "syslog") {
			$l = substr($l, 4);
			if ("$l" == "sport") $servicename = "{$line["src_service"]}";
			if ("$l" == "dport") $servicename = "{$line["dst_service"]}";
		}
		if (!isset($servicename) or "$servicename" == "-"){
			$servicename = getservbyport($line["$l"], "tcp");
		}
?>
		<tr>
			<td><?php print "{$longnames["$l"]}"; ?></td>
			<td><?php print "{$line["$l"]}" ?></td>
			<td><?php print "&nbsp; $servicename"; ?></td>
		</tr>
<?php
		} else {
?>
		<tr>
			<td><?php print "{$longnames["$l"]}"; ?></td>
			<td><?php print "{$line["$l"]}" ?></td>
			<td>&nbsp;</td>
		</tr>
<?php
		}
	}
?>
	</table>
	<table border=1>
		<tr class=t_sheader>
			<td>SYN</td>
			<td>ACK</td>
			<td>FIN</td>
			<td>RST</td>
			<td>PSH</td>
			<td>URG</td>
			<td>URGP</td>
		</tr>

<?php
		if ($source == "syslog") {
			$flags = $line["tcp_options"];
			if (ereg("s.....", $flags ) or $flags == "SYN" ) { $line["tcp_syn"] = 1; } else { $line["tcp_syn"] = 0; } 
			if (ereg(".a....", $flags )) { $line["tcp_ack"] = 1; } else { $line["tcp_ack"] = 0; }
			if (ereg("..f...", $flags )) { $line["tcp_fin"] = 1; } else { $line["tcp_fin"] = 0; }
			if (ereg("...r..", $flags )) { $line["tcp_rst"] = 1; } else { $line["tcp_rst"] = 0; }
			if (ereg("....p.", $flags )) { $line["tcp_psh"] = 1; } else { $line["tcp_psh"] = 0; }
			if (ereg(".....u", $flags )) { $line["tcp_urg"] = 1; } else { $line["tcp_urg"] = 0; }
		}
?>
		<tr class=t_datas>

			<td><?php if ("{$line["tcp_syn"]}" == 't' or $line["tcp_syn"] == 1)
					print 1; else print 0; ?></td>
			<td><?php if ("{$line["tcp_ack"]}" == 't' or $line["tcp_ack"] == 1)
					print 1; else print 0; ?></td>
			<td><?php if ("{$line["tcp_fin"]}" == 't' or $line["tcp_fin"] == 1)
					print 1; else print 0; ?></td>
			<td><?php if ("{$line["tcp_rst"]}" == 't' or $line["tcp_rst"] == 1)
					print 1; else print 0; ?></td>
			<td><?php if ("{$line["tcp_psh"]}" == 't' or $line["tcp_psh"] == 1)
					print 1; else print 0; ?></td>
			<td><?php if ("{$line["tcp_urg"]}" == 't' or $line["tcp_urg"] == 1)
					print 1; else print 0; ?></td>
			<td><?php print "{$line["tcp_urgp"]}" ?></td>
		</tr>
	</table>
<?php			break;
		case  1:
	$icmpdata = array(
		"icmp_type",
		"icmp_code",
		"icmp_echoid",
		"icmp_echoseq",
		"icmp_gateway",
		"icmp_fragmtu",
	);
?>
	<br>
	<table border=1>
	<caption><strong><font size="+2">Protocol&nbsp;ICMP</font></strong></caption>
<?php
	foreach ($icmpdata as $l) {
?>
		<tr>
			<td><?php print "{$longnames["$l"]}"; ?></td>
			<td><?php print "{$line["$l"]}" ?></td>
		</tr>
<?php
	}
?>
	</table>
<?php
			break;
		default:
	$p = getprotobynumber($proto);
?>
	<br>
	<table border=1>
	<caption><strong><font size="+2">Protocol&nbsp;<?php print "$p" ?></font></strong></caption>
		<tr>
			<td><?php print "No header information available for protocol $p" ?></td>
		</tr>
	</table>
<?php
			break;
	}
?>
</td>
</tr>
<tr>
<td colspan=2>
	<form action="<?php print "$self"; ?>" method="post">
		<input type="submit" name="action" value="Resolve Hosts">
		<input type="hidden" name="w_id" value="<?php print "{$FWLOG["w_id"]}"; ?>">
<?php
		$fw_data = array();
		if (is_array($_SESSION["fwlog_source"]))
			$fw_data = $fw_data + $_SESSION["fwlog_source"];
		if (!isset($fw_data["data_source"]) and isset($FWLOG["data_source"]))
			$fw_data["data_source"] = $FWLOG["data_source"];
		if (!isset($fw_data["ulog_table"]) and isset($FWLOG["ulog_table"]))
			$fw_data["ulog_table"] = $FWLOG["ulog_table"];
		if (!isset($fw_data["syslog_file"]) and isset($FWLOG["syslog_file"]))
			$fw_data["syslog_file"] = $FWLOG["syslog_file"];
		if (isset ($_SESSION["fwlog"]))
			$fw_data = $fw_data + $_SESSION["fwlog"];
		foreach ($fw_data as $k => $v) {
			if ("$k" == "action" or "$k" == "w_id") continue;
			print "\t\t<input type=\"hidden\" name=\"".htmlspecialchars("$k", ENT_QUOTES).
				"\" value=\"".htmlspecialchars("$v", ENT_QUOTES)."\">\n";
		}
?>
	</form>
</td>
</tr>
</table>

<?php
	db("close", $link);
?>

</body>
</html>
