<?php
/*
$Id: selection.php,v 1.11 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

column selection form

This code is distributed under the terms of GNU GPL
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title>Webfwlog - Edit Report <?php print "{$FWLOG["report"]}" ?> - Selection</title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<?php if ($config["debug"]) include "include/debug.php"; ?>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<table align="center">
<tr>
<td>
<form action="<?php print "$self"; ?>" method="POST">
<?php
	foreach ($FWLOG as $a => $b) {
		if (!(substr($a,0,2) == "c_") and !(substr($a,0,2) == "l_") and !($a == "selection") and !($a == "page")) {
			print "<input type='hidden' name='".htmlspecialchars("$a", ENT_QUOTES).
				"' value='".htmlspecialchars("$b", ENT_QUOTES)."'>\n";
		}
	}
?>
<input type="hidden" name="page" value="selection">

<table align="center" border="1">
	<tr>
	<td>  
	<!-- Select to include menu -->
	<table>
		<caption style="text-align: left; "><strong>Select report columns and order</strong></caption>
	<?php
		$numrows = 12;
		$numcols = 4;
		for ($a = 0; $a <= ($numcols - 1);  $a++) {
			print "<col><col align='center'><col>";
		}
		print "\n";
		print "<tr>";
		for ($a = 0; $a <= ($numcols - 1);  $a++) {
	    	print "<th scope=col>Link</th><th scope=col>Order</th><th scope=col>Item</th>";
		}
		print "</tr>\n";
		for ($i = 0; $i <= ($numrows - 1);  $i++) {
			print "<tr>";
			for ($j = 0; $j <= ($numcols - 1); $j++) {
				$colnum = $i + $j * $numrows;
				if (!($a = $columnorder["$colnum"])) continue;
					$t = substr("$a",2);
					$l = $a; $l[0] = "l";
					$n = $longnames["$t"];
?> 
	<td align="center">
<?php			switch ("$l") {
				case "l_oob_time_sec":
				case "l_oob_time_usec":// These never get
				case "l_dst_host":	   // links.
				case "l_src_host":	 
				case "l_dst_service":
				case "l_src_service":
				case "l_local_time":
				case "l_oob_earliest":
				case "l_oob_latest":
				case "l_earliest":
				case "l_latest":
					continue;
					break;
				default:
?>
		<input
			type="checkbox"<?php if ("{$FWLOG["$l"]}") print " checked"; print "\n"; ?>
			name="<?php print "$l"?>"
			value="on"
			tabindex=<?php print "$j\n"; ?>
		>
<?php   		        break;
				}
?>
	</td>
	<td>
		<input
			type="text"
			class=num
			size="3"
			maxlength="4"
			name="<?php print "$a"?>"
			value="<?php echo "{$FWLOG["$a"]}"?>"
			tabindex=<?php print "$j\n"; ?>
		>
	</td>
<?php if ("$a" == "c_extra") { ?>
	<td>Grp:
		<input
			type="checkbox"<?php if ("{$FWLOG["g_extra"]}") print " checked"; print "\n"; ?>
			name="<?php print "g_extra"?>"
			value="on"
			tabindex=<?php print "$j\n"; ?>
		>
		<input
			style="height: auto;"
			type="text"
			size=20
			name="c_extra_value"
			value="<?php  print htmlspecialchars("{$FWLOG["c_extra_value"]}", ENT_QUOTES); ?>"
			tabindex=<?php print "$j\n"; ?>
		>
	</td>
<?php } else { ?>
	<td><?php print "$n";?></td>
<?php
	}
			}
			print "</tr>\n";
		}
?>
	</table>
	<!-- End of Select to include menu -->
	</td>
</tr>
<tr>
	<td>
	<input type="submit" name="action" value="Refresh">&nbsp;
	<input type="reset" value="Reset">
	<input type="submit" name="action" value="Accept">&nbsp;
	</td>
</tr>
</table>
</form>
</td>
</tr>
<?php
	$doc_page = "selection";
	include "include/edit_doc.php";
?>
</table>

</body>
</html>
