<?php
/*
$Id: save_report.php,v 1.10 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

confirm save of report definitions

This code is distributed under the terms of GNU GPL
*/
?>

<?php
$link = db("open", "$database");

if (strtolower($FWLOG["action"]) == "commit") {
	$FWLOG["report"] = $FWLOG["save_report"];
	if (db("exists", "SELECT count(*) FROM $reports")) {
		$name = trim($FWLOG["save_report"]);
		if (ereg("^[a-zA-Z0-9_]+\$", "$name") or $name == "") {
			$report = $name;
			//if committing, UPDATE if report code already exists, otherwise INSERT
			unset ($FWLOG["action"]); // don't save these
			unset ($FWLOG["page"]);
			unset ($FWLOG["report"]);
			unset ($FWLOG["orig_report"]);
			unset ($FWLOG["save_report"]);
			unset ($FWLOG["select_report"]);
			unset ($FWLOG["update_all"]);
			unset ($FWLOG["show_sql"]); // deprecated, use be_verbose
			$definition = db("escape", serialize($FWLOG));
			$rownum = 0;
			if (db("nextrow", db("statement", "SELECT code FROM $reports WHERE code ='".db("escape", "$report")."'"))) {
				if (db("exists", "SELECT last_saved FROM $reports")) {
					$l_saved = ", last_saved = $time ";
				} else {
					$l_saved = "";
				}
				if (!db("statement", "UPDATE $reports 
					SET description = '".db("escape", "{$FWLOG["description"]}")."',
						definition  = '$definition'
						$l_saved
					WHERE code='".db("escape", "$report")."'")
					)
					$status = "\tERROR: REPORT NOT SAVED\n";
			} else {
				if (db("statement", "INSERT INTO $reports
					(code, description, definition) 
					VALUES ('".db("escape", "$report")."','"
					.db("escape", "{$FWLOG["description"]}")."', '$definition')")) {
					if (db("exists", "SELECT last_saved, last_accessed FROM $reports")) {
						db("statement", "UPDATE $reports 
							SET last_saved = $time,
								last_accessed = $time
							WHERE code='".db("escape", "$report")."'");
					}
				} else {
					$status = "\tERROR: REPORT NOT SAVED\n";
				}
			}
			$FWLOG["report"] = $report;
			unset ($name); 
			$status = "\tREPORT {$FWLOG["report"]} SAVED\n";
			db("close", $link);
			include "include/edit_report.php";
			exit();
		}
	} else {
		$status = "<font color='red'>CANNOT OPEN DATATBASE<br>REPORT NOT SAVED</font>";
		$FWLOG["report"] = $FWLOG["save_report"];
	} // End of "save"
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title>Webfwlog - Save Report</title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<form action="<?php print "$self"; ?>" method="POST">

<?php
	if (isset($FWLOG["save_report"])) {
		$code = $FWLOG["save_report"];
	} else {
		$code = $FWLOG["report"];
	}
	$rownum = 0;
	if (db("exists", "SELECT count(*) FROM $reports") and
		$result = db("statement", "SELECT code FROM $reports WHERE code='".db("escape", "$code")."'") and
		db("nextrow", $result))
			$savecode = $code;

	db("close", $link);

	foreach ($FWLOG as $a => $b) {
			if (!($a == "page"))
			print "<input type='hidden' name=\"".htmlspecialchars("$a", ENT_QUOTES)
				."\" value=\"".htmlspecialchars("$b", ENT_QUOTES)."\">\n";
	}
?>
<input type='hidden' name='page' value='save'>

<div style="margin-top:5em; " align="center">
<font size="+2">
<table border=1>
  <caption>
     SAVE REPORT DEFINITION<p>
	 <?php if ($status) print "$status"; ?>
  </caption>
    <tr>
    	<td colspan="2">
			<font size="+2">
			<strong>
			<?php if (isset($savecode)) {
				 print "\t<font color='red'>$code exists:<br>Committing will overwrite existing definition!</font>\n";
			} else {
				print "\t<font color='blue'>PLEASE ENTER A REPORT CODE<br>\n" .
					  "\tMust Contain only Alphanumeric + '_' : [a-zA-Z0-9_]+</font>\n";
			}
			?>
			</strong>
			</font>
		</td>	
	</tr>
	<tr>
		<td style="width:8em; text-align: left; ">Description:</td>
		<td style="width:15em; text-align: left; " colspan=2><?php print htmlspecialchars("{$FWLOG["description"]}", ENT_QUOTES); ?></td>      
    </tr>
    <tr>
      <td style="text-align: left; ">Report Code:</td>
      <td style="text-align: left; "><input type="text" name="save_report" size="20" value="<?php print htmlspecialchars("$code", ENT_QUOTES); ?>"></td>
    </tr>
    <tr>
    	<td colspan="2">
			<input style="width: 16ex; " type="submit" name="action" value="Refresh">&nbsp;&nbsp;
			<input style="width: 16ex; " type="submit" name="action" value="Commit">&nbsp;&nbsp;
			<input style="width: 16ex; " type="submit" name="save" value="Cancel">
		</td>
	</tr>
</table>
</font>
</div>

</form>

</body>
</html>
