<?php
/*
$Id: html_out.php,v 1.36 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

html output for webfwlog

Webfwlog is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
    
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title><?php print "{$config["title"]}"; ?></title>
<?php
if (is_numeric("{$FWLOG["refresh"]}") and $FWLOG["refresh"]) {
?>
  <meta http-equiv="refresh" content="<?php print "{$FWLOG["refresh"]};url=$self?{$_SERVER["QUERY_STRING"]}"; ?>">
<?php
}
?>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<?php if ($config["debug"]) include "include/debug.php"; ?>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<?php

if ($source <> "sql")
	$link = db("open", "$database");

$rownum = 0;

print "<pre>";
if ($FWLOG["be_verbose"] and $config["allow_be_verbose"]) {
	if ($source == "sql") {
		print htmlspecialchars("{$query}", ENT_QUOTES)."\n";
	}


	if ($source == "syslog") {
		if ($config["debug"] >= 2) print htmlspecialchars("{$query}", ENT_QUOTES);
		print htmlspecialchars("{$params}", ENT_QUOTES)."\n";
		while($line = db("nextrow", $result, "$source")) {
			print htmlspecialchars("{$line}", ENT_QUOTES)."\n";
		}
	}
} else {
	if ($source == "syslog") {
		while($line = db("nextrow", $result, "$source")) {
			if ($retval) //bad exit status
				print htmlspecialchars("{$line}", ENT_QUOTES)."\n";
		}
	}
}

if ($source == "syslog" and $retval) { //bad exit status
	print "<font color=red>";
	print "Exit code: $retval\n";
	print "syslog parser terminated abnormally\n";
	die;
}

print "</pre>\n\n";

// Output Report
{
	print "<div align=center><h2>".htmlspecialchars("{$FWLOG["report_title"]}", ENT_QUOTES)."</h2></div>\n";
	$dsource = "$self?data_source=".urlencode("{$FWLOG["data_source"]}");
	if (isset($FWLOG["ulog_table"]))
		$dsource = "$dsource&ulog_table=".urlencode("{$FWLOG["ulog_table"]}");
	if (isset($FWLOG["syslog_file"]))
		$dsource = "$dsource&syslog_file=".urlencode("{$FWLOG["syslog_file"]}");
	$muri = "$dsource";
	if (isset($FWLOG["upd_hosts"]) and !$FWLOG["page_length"])
		$muri = "$muri&upd_hosts=";
	if (isset($FWLOG["populate_cache"]) and !$FWLOG["page_length"])
		$muri = "$muri&populate_cache=";
	$muri = "${muri}&action=run+report&level=$level";

    $table_opts = "cellpadding=1 cellspacing=1 align=\"center\"";
    $class1 = "html_r1";
    $class2 = "html_r2";
	$row_opts = "align=\"center\"";
    
	$class = $class1;

    print "<table $table_opts>\n";

    print "\t<tr><td colspan=4>\n";
    print "\t\t<a href=$dsource&show_select_data_source={$FWLOG["show_select_data_source"]}>Home</a>&nbsp;\n";
    print "\t\t<a href=$self?action=use+report&select_report={$FWLOG["report"]}&level=$level&drill_down=yes&show_select_data_source={$FWLOG["show_select_data_source"]}>Edit this report</a>&nbsp;\n";
    print "\t</td></tr>\n";
	
	if ($source == "syslog") {
		$temp = $shortnames;
	} else {
		$temp = array_flip($shortnames);
	}

	$colnum = 0;
	while ($name = db("nextfield", $result, "$source")) {
		$fields[] = "$name";
	}

	print "\t<tr $row_opts class='$class'>\n";
	foreach ($fields as $col) {
		if ($source == "syslog") {
			$name = $col;
		} else {
			$name = "{$temp["$col"]}";
		}
		switch ("$name") {
			case "dst_host":	// Would never sort
			case "src_host":	// by these so no
			case "dst_service":	// link in header
			case "src_service":	//
				print "\t\t<th>{$shortnames["$name"]}</th>\n";
				break;
			default:
				$s = "s_$name";
				$o = "o_$name";
				$h_uri = "$muri&keep=yes&start=0&$s=0";
				if ($FWLOG["$s"] == 1)
					if (isset($FWLOG["$o"])) {
						$h_uri = "$h_uri&$o=";
					} else {
						$h_uri = "$h_uri&$o=on";
					}
				print "\t\t<th><A HREF=\"$h_uri\">{$shortnames["$name"]}</A></th>\n";
				break;
		}
    }
    print "\t</tr>\n";
	
	if ($source == "syslog")
		$rownum = $rownum + 1;

	while ($line = db("nextrow", $result, "$source")) {

		switch ($class) {
    		case $class1: $class = $class2; break;
			case $class2: $class = $class1; break;
		}

		print "\t<tr $row_opts class='$class'>\n";
		foreach ($line as $column => $value) {
			//format dates
			switch ("$column") {
				// ulogd
				case "{$shortnames['oob_time_sec']}":
				case "{$shortnames['local_time']}":
				case "{$shortnames['earliest']}":
				case "{$shortnames['latest']}":
				// syslog
				case "local_time":
				case "earliest":
				case "latest":
					$value = date("{$config["dformat"]}", $value);
					break;
				default:
					break;	
			}

			if ($source == "syslog") {
				$l = "l_$column";
				$colkey = $column;
			} else {
				$l = "l_{$temp["$column"]}";
				$colkey = $temp["$column"];
			}

			// add link if requested
			$count = "";
			if (("$colkey" == "dport" or "$colkey" == "sport") and $value > 65535 ) {
				print "\t\t<td></td>\n";
			} elseif (isset($FWLOG["$l"]) and ($a = makewhere("$colkey", "$value"))) {
				$uri = "$muri";
				$uri = "{$uri}&keep=yes&start=0&w_extra=";
				if (isset($FWLOG["w_extra"]) and $source <> "syslog") {
					$uri = "$uri".urlencode("{$FWLOG["w_extra"]}\t")."$a";
				} else {
					$uri = "$uri".urlencode("{$FWLOG["w_extra"]}")."$a";
				}
				print "\t\t<td><A HREF=\"$uri\">".htmlspecialchars("$value", ENT_QUOTES)."</A></td>\n";
			} else
				print "\t\t<td>".htmlspecialchars("$value", ENT_QUOTES)."</td>\n";
		}
        print "\t</tr>\n";
    }

	if ($source == "syslog") {
		$matched_rows = $result[$rownum];
		$rownum = $rownum + 1;
		$matched_records = $result[$rownum];
		$rownum = $rownum + 1;
		$hostupdatetime = $result[$rownum];
		$rownum = $rownum + 1;
		$servicesupdatetime = $result[$rownum];
		$rownum = $rownum + 1;
		$cachepopulatetime = $result[$rownum];
		$rownum = $rownum + 1;

		$querytime = $querytime - $hostupdatetime - $servicesupdatetime - $cachepopulatetime;
	} else { //source = sql
		flush();
		$rownum = 0;
		$result = db("nextrow", db("statement", "SELECT count(*) AS count FROM $allrows"));
		$matched_rows = $result["count"];
		if ($FWLOG["summarize"]) {
			$rownum = 0;
			db("statement", "DROP TABLE $allrows");
			db("statement", "CREATE TEMPORARY TABLE $allrows AS\n$allrows_query");
			$result = db("nextrow",	db("statement", "SELECT sum(recordcount) AS count FROM $allrows"));
			$matched_records = $result["count"];
		}
	}
	// add paging links on LIMITed report
	if ($FWLOG["page_length"]) {
		if ($matched_rows > $FWLOG["page_length"]) {
			print "<tr>\n";
			print "<td colspan=" . count($fields) .">\n";
			print_scrollbar("$muri&start=",$start,$matched_rows,$FWLOG["page_length"],count($fields) * 4);
			print "</td>\n";
			print "</tr>\n";
		}
	}

	print "<tr>\n";
	print "<td colspan=4>";
	if ($FWLOG["page_length"]) {
		$begin = $start + 1;
		$end = min($start + $FWLOG["page_length"], $matched_rows);
		print "Rows $begin to $end of $matched_rows displayed";
	} else {
		print "$matched_rows rows returned";
	}
	print "</td>";
	print "</tr>\n";

	if ($FWLOG["summarize"]) {
		print "<tr>\n";
		print "<td colspan=4>";
		print "$matched_records logged entries matched";
		print "</td>";
		print "</tr>\n";
	}

	print "</table>\n";

	print "<p>";

	$reporttime = time() - $time -  $querytime - $hostupdatetime - $servicesupdatetime - $cachepopulatetime;
	$totaltime = time() - $time;

	if ($FWLOG["upd_hosts"]) {
		print "Host update time was $hostupdatetime Seconds<br>\n";
		print "Services update time was $servicesupdatetime Seconds<br>\n";
	}

	if ($FWLOG["populate_cache"]) {
		print "Cache Populate time was $cachepopulatetime Seconds<br>\n";
	}

	print "Query time was $querytime Seconds.<br>\n";
	print "Report time was $reporttime Seconds.<br>\n";
	print "Total time was $totaltime Seconds.<br>\n";
}

db("close", $link);

?>
<p>
<em><font size="-2">Powered by
	<font color="blue"><a href="http://www.webfwlog.net">Webfwlog <?php print "$webfwlog_version"; ?></a>
	</font></font>
</em>

</body>
</html>
