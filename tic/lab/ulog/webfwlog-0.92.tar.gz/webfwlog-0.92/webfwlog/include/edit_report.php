<?php
/*
$Id: edit_report.php,v 1.27 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

report editing form for webfwlog

Webfwlog is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
    
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
?>

<?php
	$link = db("open", "$database");

	if (!isset($FWLOG["refresh"]))
		$FWLOG["refresh"] = $config["refresh"];

	if (strtolower($FWLOG["save"]) == "cancel" 
		or strtolower($FWLOG["export"]) == "cancel"
		or strtolower($FWLOG["delete"]) == "cancel") 
		$FWLOG["report"] = $FWLOG["orig_report"];

	$code = $FWLOG["report"];

	switch (strtolower($FWLOG["action"])) {
	
	case "use report":
	if (db("exists", "SELECT count(*) FROM $reports")) {
		$code = $FWLOG["select_report"];
		$rownum = 0;
		$result = db("nextrow", db("statement", "SELECT definition FROM $reports WHERE code ='".db("escape", "$code")."'"));
		if (db("exists", "SELECT last_accessed FROM $reports")) {
			db("statement", "UPDATE $reports SET last_accessed = $time WHERE code = '".db("escape", "$code")."'");
		}
		if ($result["definition"]) {
			$definition = unserialize($result["definition"]);
			if ($FWLOG["drill_down"]) {
				unset ($FWLOG["action"]);
			} else {
				$FWLOG = $definition;
			}
			$FWLOG["report"] = "$code";
			require 'include/orders.php';
			// new report definition may have arbitrary column defined
			if ($config["allow_raw_sql"]) { 
				if (isset($FWLOG["c_extra_value"]))
					$label = eregi_replace("^.+ *as *['\"]?([^'\"]*)['\"]? *$","\\1","{$FWLOG["c_extra_value"]}");
					$shortnames["extra"] = "$label";
					if ("$label" == "{$FWLOG["c_extra_value"]}") {
						$label = " AS \"$label\"";
					} else $label = "";
					$longnames["extra"] = "{$FWLOG["c_extra_value"]}";
			}
			require 'include/edit_report.php';
			return; // Restart edit_report with new definition, so return upon return
		} else {
			$status = "\tReport Not Defined!\n";
		}
	} // End of "use report"
		break;

	case "save as default":
	if (!isset($status) and db("exists", "SELECT count(*) FROM $reports")) {
		unset ($FWLOG["action"]);
		unset ($FWLOG["page"]);
		unset ($FWLOG["select_report"]);
		$definition = db("escape", serialize($FWLOG));
		$rownum = 0;
		if (db("nextrow", db("statement", "SELECT code FROM $reports WHERE code ='default'"))) {
			if (!db("statement", "UPDATE $reports 
				SET description = '".db("escape", "{$FWLOG["description"]}")."',
					definition  = '$definition'
				WHERE code='default'")
				)
				$status = "\tERROR: REPORT NOT SAVED\n";
		} else {
			if (!db("statement", "INSERT INTO $reports
					(code, description, definition)
					VALUES ('default', '".db("escape", "{$FWLOG["description"]}")."', '$definition')"
				))
				$status = "\tERROR: REPORT NOT SAVED\n";
		}
		$status = "\tSETTINGS SAVED AS DEFAULT!\t";
	} else {
		if (isset($status)) $status = "$status<br><font color='red'>REPORT NOT SAVED</font>";
	} //End of "save as default"
		break;

	case "create new":
	case "report editor":
	if (db("exists", "SELECT count(*) FROM $reports")) {
		$rownum = 0;
		$result = db("nextrow", db("statement", "SELECT definition FROM $reports WHERE code ='default'"));
		if ($result["definition"]) {
			$definition = unserialize($result["definition"]);
			unset($FWLOG);
			$FWLOG = $definition;
			unset ($FWLOG["report"]);
		} else {
			unset ($FWLOG);
			$FWLOG = set_defaults($FWLOG);
			$status = "\tNo Default Report Not Defined!\n";
		}
		$name = "<NEW>";
		require 'include/orders.php';
	} else {
		unset ($FWLOG);
		$FWLOG = set_defaults($FWLOG);
		$name = "<NEW>";
		require 'include/orders.php';
	} // End of "create new"
		break;

	default:
		 break;
	} // end switch

	$FWLOG = $FWLOG + $options;

	if (!$columns)
		$status = "\t<font color='red'>No Columns Selected!</font>\n";

	if (!isset($FWLOG["summarize"])
		and (  isset($FWLOG["c_count"])
			or isset($FWLOG["c_earliest"]) 
			or isset($FWLOG["c_latest"])
			or isset($FWLOG["c_oob_earliest"]) 
			or isset($FWLOG["c_oob_latest"]))) {
		$status = "\t<font color='red'> Cannot use grouping column<br>" .
										"if no Summarization!<br>" .
										"i.e., Occurrences,  Earliest,  Local Time ...</font>\n";
	}

	if (isset($FWLOG["summarize"])
		and (  isset($FWLOG["c_local_time"])
			or isset($FWLOG["c_oob_time_sec"]) 
			or isset($FWLOG["c_oob_time_usec"]))) {
		$status = "\t<font color='red'> Cannot use date/time column<br>" .
										"if Summarization!<br>" .
										"i.e., Local Time, OOB Time ...</font>\n";
	}

	if (isset($imported)) {
		$status = "Report {$FWLOG["report"]} Imported";
	}

		// Always executes
	$rownum = 0;
	if (db("exists", "SELECT count(*) FROM $reports") and !isset($name)) {
		$name = "$code";
	}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title>Webfwlog - Edit Report <?php print htmlspecialchars("$name", ENT_QUOTES); ?></title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<?php if ($config["debug"]) include "include/debug.php"; ?>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<table align="center">
<tr>
<td>

<form action="<?php print "$self"; ?>" method="POST">  <!-- Begin of Form -->
	<input
		type="hidden"
		name="show_select_data_source"
		value=<?php print $FWLOG["show_select_data_source"] ; ?>
	>

<table border="1"> <!-- Begin of Main Table -->
<tr>  <!-- Begin of First row -->
	<td valign="top" rowspan="2" colspan="1"> <!-- Begin of basic report info -->
	<table>
		<tr>
			<td>
				<input
					style="width: 16ex; "
					type="submit"
					name="action"
					value="Refresh"
					tabindex=1
				>
				<input
					style="width: 16ex; "
					type="submit"
					name="action"
					value="Run Report"
					tabindex=1
				>
				<br>
				<input
					type="submit"
					name="action"
					value="Return to Main Menu"
					tabindex=1
				>
				<hr>
				<strong>Select Report:</strong><br>
				<select name="select_report" tabindex=1>
					<option></option> <!-- Blank at top of list -->
				<?php
					if (db("exists", "SELECT count(*) FROM $reports")) {
					 	$reportlist = db("statement", "SELECT code FROM $reports");
						$rownum = 0;
						while ($item = db("nextrow", $reportlist)) {
							if ($item["code"] == 'default') continue;
							print "\t<option>{$item["code"]}</option>\n";
						}
					}
				?>
				</select>
				<br>
				<input
					type="submit"
					name="action"
					value="Use Report"
					tabindex=1
				>
				&nbsp;&nbsp;&nbsp;
				<a href='<?php print "$self"; ?>?action=use+report&select_report=<?php print urlencode("$name"); ?>#report_help'
					tabindex=1
				>Help</a>
				<br>
				<span style="margin-top: 1ex; ">
<?php
	// only last set status message is printed, so most critical tests should be done last
	// If no other message, use default
	if (!isset($status)) {
	 	$status = "\t<font size='+2'>Editing . . .</font>\n";
	}
	print "<br><strong>$status</strong><BR>";
?>
				</span>
				<font size="+1"><strong>Report:&nbsp;</strong></font>
					<span class="report_code"><strong><?php print htmlspecialchars("$name", ENT_QUOTES); ?></strong></span>
				<input type="hidden" name="report" value="<?php print htmlspecialchars("$name", ENT_QUOTES); ?>">
				<br>
				<div style="margin-top: 1ex; ">
					<font size="+1">Description:</font><br>
					<textarea style="font-size: 100%;"
						rows=3
						wrap
						cols=25
						name="description"
						tabindex=1
					><?php print htmlspecialchars("{$FWLOG["description"]}", ENT_QUOTES); ?></textarea>
					<input type="hidden" name="page" value="spec">
				</div>
				<div style="margin-top: 1ex; ">
				<table>
				<tr>
					<td>
						<input
							style="width: 16ex; "
							type="submit"
							name="action"
							value="Save"
							tabindex=1
						>
					</td>
					<td align="right">
						<input
							type="submit"
							name="action"
							value="Delete"
							tabindex=1
						>
					</td>
				</tr>
				<tr>
					<td>
						<input
							style="width: 16ex; "
							type="submit"
							name="action"
							value="Save as Default"
							tabindex=1
						>
					</td>
					<td>
						<input
							style="width: 16ex; "
							type="submit"
							name="action"
							value="Import"
							tabindex=1
						>
					</td>
				</tr>
				<tr>
					<td>
						<input
							style="width: 16ex; "
							type="submit"
							name="action"
							value="Create New"
							tabindex=1
						>
					</td>
					<td>
						<input
							style="width: 16ex; "
							type="submit"
							name="action"
							value="Export"
							tabindex=1
						>
					</td>
				</tr>
				</table>
				</div><hr>
			</td>          
		</tr>
		<tr>
			<td valign="top" colspan=2>
				<table>
					<caption ><strong>Report Options</strong>&nbsp;&nbsp;&nbsp;
						<a href='<?php print "$self"; ?>?action=use+report&select_report=<?php print urlencode("$name"); ?>#options_help'
							tabindex=1
						>Help</a>
					</caption>
					<col align="left">
					<col align="center">
					<tr class=opts>
						<td colspan="2">
						Select Data Source:<br>
							<input
								type="radio"
								name="data_source"
								value=""
								tabindex=1
								<?php if(!isset($FWLOG["data_source"])) print "checked\n"; ?>
							>
							&nbsp;Default
						</td>
					</tr>
					<tr class=opts>
						<td colspan="2">
							<input
								type="radio"
								name="data_source"
								value="ulogd"
								tabindex=1
								<?php if(strtolower("{$FWLOG["data_source"]}") == "ulogd") print "checked\n"; ?>
							>
							&nbsp;Ulogd&nbsp;&nbsp;Table:&nbsp;
							<select name="ulog_table">
								<option value="">Default</option>
								<?php
								foreach(db("listtables","$ulogd") as $i) {
									print "<option";
									if("{$FWLOG["ulog_table"]}" == "$i") {
										print " selected";
									}
									print ">$i</option>\n";
								}
								?>
							</select>
						</td>
					</tr>
					<tr class=opts>
						<td>
							<input
								type="radio"
								name="data_source"
								value="syslog"
								tabindex=1
								<?php if(strtolower("{$FWLOG["data_source"]}") == "syslog") print "checked\n"; ?>
							>
							&nbsp;Syslog&nbsp;Path:&nbsp;
						 	<?php print "{$config["syslog_dir"]}/"; ?><br>
							File(s)&nbsp;
							<input
								type="text"
								size="20"
								name="syslog_file"
								value="<?php print htmlspecialchars("{$FWLOG["syslog_file"]}", ENT_QUOTES); ?>"
								tabindex=1
							>
							<hr>
						</td>
					</tr>
					<tr class=opts>
						<td colspan="2">Title (for heading of report)</td>
					</tr>
					<tr class=opts>
						<td colspan="2">
							<input
								style="width: 32ex"
								type="text"
								size="30"
								name="report_title"
								value="<?php print htmlspecialchars("{$FWLOG["report_title"]}", ENT_QUOTES); ?>"
								tabindex=1
							>
						</td>
					</tr>
					<tr class=opts>
						<td>Rows per page</td>
						<td>
							<input
								style="width: 3em; vertical-align: middle; margin-left: .5ex;"
								type="text"
								size=4
								name="page_length"
								value="<?php print htmlspecialchars("{$FWLOG["page_length"]}", ENT_QUOTES); ?>"
								tabindex=1
						>
						</td>
					</tr>
					<tr class=opts>
						<td>Page Refresh Rate</td>
						<td>
							<input
								style="width: 3em; vertical-align: middle; margin-left: .5ex;"
								type="text"
								size=4
								name="refresh"
								value="<?php print htmlspecialchars("{$FWLOG["refresh"]}", ENT_QUOTES); ?>"
								tabindex=1
						>
						</td>
					</tr>
					<tr class=opts>
						<td>Update Hostname Cache</td>
						<td>
							<input
								type="checkbox"
								<?php if ($FWLOG["upd_hosts"]) print "checked"; ?>
								name="upd_hosts"
								value="on"
								tabindex=1
							>
						</td>
					</tr>
					<tr class=opts>
						<td>Populate Hostname Cache</td>
						<td>
							<input
								type="checkbox"
								<?php if ($FWLOG["populate_cache"]) print "checked"; ?>
								name="populate_cache"
								value="on"
								tabindex=1
							>
						</td>
					</tr>
					<?php if ($config["allow_be_verbose"]) { ?>
					<tr class=opts>
						<td>Be Verbose</td>
						<td>
							<input
								type="checkbox"
								<?php if ($FWLOG["be_verbose"]) print "checked"; ?>
								name="be_verbose"
								value="on"
								tabindex=1
						>
						</td>
					</tr>
					<?php } ?>
				</table>
			</td>
        </tr>
	</table>
	<hr>
	Update Hostname cache now.<br>
	This may take a LONG time.<br>
	<input
		style="width: 16ex; margin-top: .5ex; "
		type="submit"
		name="action"
		value="Update Cache"
		tabindex=1
	>
	&nbsp;All
	<input
		type=checkbox
		name=update_all
		value=yes
		<?php if ($FWLOG["update_all"]) print "checked"; ?>
		tabindex=1
	>
	</td> <!-- End of basic report info -->

	<td valign="top"> <!-- Sorting menu -->
	<table>
		<caption style="{font-size: 110%; font-weight: bold;}">
			<strong>SUMMARIZE REPORT:</strong>
				<input
					type="checkbox"
					name="summarize"
					value="on" 
					<?php if ($FWLOG["summarize"]) print "checked"; ?>
					tabindex=10
				>
		</caption>
	<thead>
		<tr>
			<th align="left" scope=col style="width: 10em">Sort by:</th>
			<th scope=col>Order</th>
			<th title="Check to sort in Decending order" scope=col>Desc</th>
		</tr>
	</thead>
	<tbody>
		<?php
			$numrows = 11;
			for ($i=1; $i<=$numrows; $i++) {
				$a = $sortorder[$i - 1];
				$t = substr("$a",2);
				$o = $a; $o[0] = "o";
				$l = $longnames["$t"];
		?> 
		<tr>
			<td ><?php print "{$longnames["$t"]}";?></td>
			<td align="center">
				<input
					type="text"
					class="num"
					size="3"
					maxlength="4"
					name="<?php print "$a"?>"
					value="<?php print htmlspecialchars("{$FWLOG["$a"]}", ENT_QUOTES)?>"
					tabindex=11
				>
			</td>
			<td align="center">
				<input
					type="checkbox"
					<?php if ("{$FWLOG["$o"]}") print "checked"; ?>
					name="<?php print "$o"?>"
					value="on"
					tabindex=11
				>
			</td>
		</tr>
		<?php } ?>
		<tr>
			<td align="center">
				<a href="<?php print "$self"; ?>?action=use+report&select_report=<?php print urlencode("$name"); ?>#sort_help"
					tabindex=19
				>Help</a>
			</td>
			<td align="center" colspan="2">
				<input
					type="submit"
					name="sorting"
					value="More"
					tabindex=19
				>
			</td>
		</tr>
	</tbody>
	</table>
	<?php  // Add hidden controls for any columns not showing on main form
		$offset = $numrows;
		while (isset($FWLOG["$sortorder[$offset]"])) {
			$a = $sortorder[$offset];
			$t = substr("$a",2);
			$o = $a; $o[0] = "o";
			print "\t<input type='hidden' name='{$sortorder[$offset]}' value='{$FWLOG["$sortorder[$offset]"]}'>\n";
			print "\t<input type='hidden' name='{$o}' value='{$FWLOG["$o"]}'>\n";
			$offset++;
		}
	?>
	</td> <!-- Sorting menu -->

	<td valign="top"> <!-- Begin of Columns to include menu -->
	<table>
		<caption style="text-align: left; "><strong>Select columns to include in report and order:</strong></caption>
	  	<?php
		$numrows = 11;
		$numcols = 2;
		for ($a = 0; $a <= ($numcols - 1);  $a++) {
			print "<col><col align='center'><col>";
		}
		print "\n";
		print "<tr>";
		for ($a = 0; $a <= ($numcols - 1);  $a++) {
    		print "<th scope=col>Link</th><th scope=col>Order</th><th scope=col>Item</th>";
		}
		print "</tr>\n";
		for ($i = 0; $i <= ($numrows - 1);  $i++) {
			print "<tr>"; // row begin
			for ($j = 0; $j <= ($numcols - 1); $j++) {
				$colnum = $i + $j * $numrows ;
				if (!($a = $columnorder["$colnum"])) continue;
					$t = substr("$a",2);
					$l = $a; $l[0] = "l";
					$n = $longnames["$t"];
		?>
			<td align="center">
			<?php	switch ("$l") {
						case "l_oob_time_sec":
						case "l_oob_time_usec":// These never get
						case "l_dst_host":	   // links.
						case "l_src_host":	 
						case "l_dst_service":
						case "l_src_service":
						case "l_local_time":
						case "l_oob_earliest":
						case "l_oob_latest":
						case "l_earliest":
						case "l_latest":
							continue;
							break;
						default:
			?>
				<input
					type="checkbox"
					<?php if ("{$FWLOG["$l"]}") print "checked\n"; ?>
					name="<?php print "$l"?>"
					value="on"
					tabindex=<?php $tindex = $j + 20; print "$tindex"; ?>
				>
			<?php 			break;
					}
			?>
			</td>
			<td>
				<input
					type="text"
					class=num size="3"
					maxlength="4"
					name="<?php print "$a"?>"
					value="<?php echo "{$FWLOG["$a"]}"?>"
					tabindex=<?php $tindex = $j + 20; print "$tindex"; ?>
				>
			</td>
<?php if ("$a" == "c_extra") { ?>
	<td>Grp:
		<input
			type="checkbox"<?php if ("{$FWLOG["g_extra"]}") print " checked"; print "\n"; ?>
			name="<?php print "g_extra"?>"
			value="on"
			tabindex=<?php print "$j\n"; ?>
		>
		<input
			style="height: auto;"
			type="text"
			size=25
			name="c_extra_value"
			value="<?php  print htmlspecialchars("{$FWLOG["c_extra_value"]}", ENT_QUOTES); ?>"
			tabindex=<?php print "$tindex\n"; ?>
		>
	</td>
<?php
	$have_extra = 1;
	} else { ?>
			<td style="width: 10em"><?php print "$n";?></td>
<?php
	}
			}
			print "</tr>\n"; //row end
		}
		?>
		<tr><td></td><td></td>
		<td align="left" colspan=2>
			<input
				type="submit"
				name="selection"
				value="More"
				tabindex=20
			>
		</td>
		<td></td>
		<td>
			<a href='<?php print "$self"; ?>?action=use+report&select_report=<?php print urlencode("$name"); ?>#columns_help'
				tabindex=29
			>Help</a>
		</td>
		</tr>
	</table>
	<?php  // Add hidden controls for any columns not showing on main form
		$offset = $numcols * $numrows;
		while (isset($FWLOG["$columnorder[$offset]"])) {
			$a = $columnorder[$offset];
			$l = $a; $l[0] = "l";
			print "\t<input type='hidden' name='{$columnorder[$offset]}' value='{$FWLOG["$columnorder[$offset]"]}'>\n";
			print "\t<input type='hidden' name='{$l}' value='{$FWLOG["$l"]}'>\n";
			$offset++;
		} 
		if (!$have_extra and $config["allow_raw_sql"]) {
 			print "\t<input type='hidden' name='c_extra_value' value='".htmlspecialchars("{$FWLOG["c_extra_value"]}", ENT_QUOTES)."'>\n";
			print "\t<input type='hidden' name='g_extra' value='{$FWLOG["g_extra"]}'>\n";
		}

	?>
	</td> <!-- End of Columns to include menu -->
</tr> <!-- Emd of first row -->

<tr> <!-- Begin of Second row -->
	<td rowspan="1" colspan="2"> <!-- Begin Criteria Menu -->
	<table>
		<caption style="text-align: left; ">
			<strong>Selection Criteria:</strong>
			&nbsp;&nbsp;&nbsp;&nbsp;
			<a href='<?php print "$self"; ?>?action=use+report&select_report=<?php print urlencode("$name"); ?>#crit_help'
				tabindex=30
			>Help</a>
		</caption>
		<colgroup>
			<col style="{width: 12.7em; }">
			<col style="{width: auto; }">
			<col align="center">
			<col style="padding-left: 1em;">
		</colgroup>
		<colgroup>
			<col style="{width: 11.7em; }">
			<col style="{width: auto; }">
			<col align="center">
		</colgroup>
	<thead>
		<tr><th scope=col>Item</th><th scope=col>Search Value</th><th scope=col>Inv</th><th scope=col></th>
			<th scope=col>Item</th><th scope=col>Search Value</th><th scope=col>Inv</th></tr>
	</thead>
	<tbody>
		<tr><td>Min date:&nbsp;&nbsp;&nbsp;oob time
				<input
					type="checkbox"
					name="w_oob_min_date"
					<?php if ($FWLOG["w_oob_min_date"]) print "checked"; ?>
					value="on"
					tabindex=30
				>
			</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_min_date"
					value="<?php print htmlspecialchars("{$FWLOG["w_min_date"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td></td>
			<td></td>
			<td>Max date:&nbsp;&nbsp;&nbsp;oob time
				<input
					type="checkbox"
					name="w_oob_max_date"
					<?php if ($FWLOG["w_oob_max_date"]) print "checked"; ?>
					value="on"
					tabindex=31
				>
			</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_max_date"
					value="<?php print htmlspecialchars("{$FWLOG["w_max_date"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td></td>
		</tr>
		<tr><td><?php print "{$longnames['local_hostname']}"?> (regexp):</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14 name="w_local_hostname"
					value="<?php print htmlspecialchars("{$FWLOG["w_local_hostname"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_local_hostname"]) print "checked"; ?>
					name="i_local_hostname"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td style="{width: auto; border: thin solid #D3D3D3; }" colspan="2" rowspan="4">
				<table>
				<tr class=opts><td colspan="3">TCP Options to include:</td></tr>
				<tr class=opts>  
				<td><span style="float:left;" class=opts>
					<input
						 class=opts
						 type="checkbox"
						 <?php if ($FWLOG["w_tcp_syn"]) print "checked"; ?>
						 name="w_tcp_syn"
						 value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_syn</span>
				</td>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_fin"]) print "checked"; ?>
						name="w_tcp_fin"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_fin</span>
				</td>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_rst"]) print "checked"; ?>
						name="w_tcp_rst"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_rst</span>
				</td>
				</tr>
				<tr class=opts>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_ack"]) print "checked"; ?>
						name="w_tcp_ack"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_ack</span>
				</td>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_urg"]) print "checked"; ?>
						name="w_tcp_urg"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_urg</span>
				</td>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_psh"]) print "checked"; ?>
						name="w_tcp_psh"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_psh</span>
				</td>
				</tr>
				<tr class=opts>
				<td colspan="3" class=opts>
					TCP Options exact match:
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_options"]) print "checked"; ?>
						name="w_tcp_options"
						value="on"
						tabindex=31
					>
				</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['oob_prefix']}"?> (regexp):</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_oob_prefix"
					value="<?php print htmlspecialchars("{$FWLOG["w_oob_prefix"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_oob_prefix"]) print "checked"; ?>
					name="i_oob_prefix"
					value="on"
					tabindex=30
				>
			</td>
		</tr>
		<tr style="line-height: .1em;">
			<td style="font-size: xx-small">&nbsp;</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['ip_protocol']}"?> (name or number):</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_protocol"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_protocol"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_protocol"]) print "checked"; ?>
					name="i_ip_protocol" value="on"
					tabindex=30
				>
			</td>
		</tr>
		<tr><td><?php print "{$longnames['tcp_sport']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_tcp_sport"
					value="<?php print htmlspecialchars("{$FWLOG["w_tcp_sport"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_tcp_sport"]) print "checked"; ?>
					name="i_tcp_sport"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['tcp_dport']}"?>:</td>
			<td>
				<input style="height: auto;"
					type="text"
					size=14
					name="w_tcp_dport"
					value="<?php print htmlspecialchars("{$FWLOG["w_tcp_dport"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_tcp_dport"]) print "checked"; ?>
					name="i_tcp_dport"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['udp_sport']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_udp_sport"
					value="<?php print htmlspecialchars("{$FWLOG["w_udp_sport"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_udp_sport"]) print "checked"; ?>
					name="i_udp_sport"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['udp_dport']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_udp_dport"
					value="<?php print htmlspecialchars("{$FWLOG["w_udp_dport"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_udp_dport"]) print "checked"; ?>
					name="i_udp_dport"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['icmp_type']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_icmp_type"
					value="<?php print htmlspecialchars("{$FWLOG["w_icmp_type"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_icmp_type"]) print "checked"; ?>
					name="i_icmp_type"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
		    <td><?php print "{$longnames['icmp_code']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_icmp_code"
					value="<?php print htmlspecialchars("{$FWLOG["w_icmp_code"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_icmp_code"]) print "checked"; ?>
					name="i_icmp_code"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['ip_saddr']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_saddr"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_saddr"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_saddr"]) print "checked"; ?>
					name="i_ip_saddr"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['ip_daddr']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_daddr"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_daddr"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_daddr"]) print "checked"; ?>
					name="i_ip_daddr"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['oob_in']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_oob_in"
					value="<?php print htmlspecialchars("{$FWLOG["w_oob_in"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_oob_in"]) print "checked"; ?>
					name="i_oob_in"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['oob_out']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_oob_out"
					value="<?php print htmlspecialchars("{$FWLOG["w_oob_out"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_oob_out"]) print "checked"; ?>
					name="i_oob_out"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "Minimum Count"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_min_count"
					value="<?php print htmlspecialchars("{$FWLOG["w_min_count"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td></td>
			<td></td>
			<td><?php print "Maximum Count"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_max_count"
					value="<?php print htmlspecialchars("{$FWLOG["w_max_count"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td></td>
		</tr>
		<tr>
		<td align="left" colspan=7>
			<br>
			<em>There may be additional criteria specified.  Press More to review.</em>&nbsp;
			<input
				type="submit"
				name="criteria"
				value="More"
				tabindex=30
			>
		</td>
		<td colspan=5></td>
		</tr>
	</tbody>
	</table>
	<?php  // Add hidden controls for any criteria not showing on main form
		print "\t<input type='hidden' name='w_min_latest' value='".htmlspecialchars("{$FWLOG['w_min_latest']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_max_earliest' value='".htmlspecialchars("{$FWLOG['w_max_earliest']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_oob_min_latest' value='".htmlspecialchars("{$FWLOG['w_oob_min_latest']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_oob_max_earliest' value='".htmlspecialchars("{$FWLOG['w_oob_max_earliest']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_tos' value='".htmlspecialchars("{$FWLOG['w_ip_tos']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_ip_tos' value='".htmlspecialchars("{$FWLOG['i_ip_tos']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_ttl' value='".htmlspecialchars("{$FWLOG['w_ip_ttl']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_ip_ttl' value='".htmlspecialchars("{$FWLOG['i_ip_ttl']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_ihl' value='".htmlspecialchars("{$FWLOG['w_ip_ihl']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_ip_ihl' value='".htmlspecialchars("{$FWLOG['i_ip_ihl']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_totlen' value='".htmlspecialchars("{$FWLOG['w_ip_totlen']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_ip_totlen' value='".htmlspecialchars("{$FWLOG['i_ip_totlen']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_id' value='".htmlspecialchars("{$FWLOG['w_ip_id']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_ip_id' value='".htmlspecialchars("{$FWLOG['i_ip_id']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_csum' value='".htmlspecialchars("{$FWLOG['w_ip_csum']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_ip_csum' value='".htmlspecialchars("{$FWLOG['i_ip_csum']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_oob_mark' value='".htmlspecialchars("{$FWLOG['w_oob_mark']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_oob_mark' value='".htmlspecialchars("{$FWLOG['i_oob_mark']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_df' value='".htmlspecialchars("{$FWLOG['w_ip_df']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_mf' value='".htmlspecialchars("{$FWLOG['w_ip_mf']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ip_fragoff' value='".htmlspecialchars("{$FWLOG['w_ip_fragoff']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_ip_fragoff' value='".htmlspecialchars("{$FWLOG['i_ip_fragoff']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_tcp_seq' value='".htmlspecialchars("{$FWLOG['w_tcp_seq']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_tcp_seq' value='".htmlspecialchars("{$FWLOG['i_tcp_seq']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_tcp_ackseq' value='".htmlspecialchars("{$FWLOG['w_tcp_ackseq']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_tcp_ackseq' value='".htmlspecialchars("{$FWLOG['i_tcp_ackseq']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_tcp_window' value='".htmlspecialchars("{$FWLOG['w_tcp_window']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_tcp_window' value='".htmlspecialchars("{$FWLOG['i_tcp_window']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_tcp_urgp' value='".htmlspecialchars("{$FWLOG['w_tcp_urgp']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_tcp_urgp' value='".htmlspecialchars("{$FWLOG['i_tcp_urgp']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_icmp_echoid' value='".htmlspecialchars("{$FWLOG['w_icmp_echoid']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_icmp_echoid' value='".htmlspecialchars("{$FWLOG['i_icmp_echoid']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_icmp_echoseq' value='".htmlspecialchars("{$FWLOG['w_icmp_echoseq']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_icmp_echoseq' value='".htmlspecialchars("{$FWLOG['i_icmp_echoseq']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_icmp_gateway' value='".htmlspecialchars("{$FWLOG['w_icmp_gateway']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_icmp_gateway' value='".htmlspecialchars("{$FWLOG['i_icmp_gateway']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_icmp_fragmtu' value='".htmlspecialchars("{$FWLOG['w_icmp_fragmtu']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_icmp_fragmtu' value='".htmlspecialchars("{$FWLOG['i_icmp_fragmtu']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_udp_len' value='".htmlspecialchars("{$FWLOG['w_udp_len']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_udp_len' value='".htmlspecialchars("{$FWLOG['i_udp_len']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_raw_mac' value='".htmlspecialchars("{$FWLOG['w_raw_mac']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_raw_mac' value='".htmlspecialchars("{$FWLOG['i_raw_mac']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_ahesp_spi' value='".htmlspecialchars("{$FWLOG['w_ahesp_spi']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_ahesp_spi' value='".htmlspecialchars("{$FWLOG['i_ahesp_spi']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_oob_time_usec' value='".htmlspecialchars("{$FWLOG['w_oob_time_usec']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='i_oob_time_usec' value='".htmlspecialchars("{$FWLOG['i_oob_time_usec']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='w_extra' value='".htmlspecialchars("{$FWLOG['w_extra']}", ENT_QUOTES)."'>\n";
		print "\t<input type='hidden' name='h_extra' value='".htmlspecialchars("{$FWLOG['h_extra']}", ENT_QUOTES)."'>\n";
	?>
	</td> <!-- End of Criteria Menu -->
</tr> <!-- End of Second row -->
</table> <!-- End of Main Table -->

</form> <!-- End of Form -->
</td>
</tr>
<?php
	db("close", $link);
	$doc_page = "editor";
	include "include/edit_doc.php";
?>
</table>

</body>
</html>
