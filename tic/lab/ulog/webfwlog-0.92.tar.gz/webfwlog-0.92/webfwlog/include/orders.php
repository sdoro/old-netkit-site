<?php
/*
$Id: orders.php,v 1.5 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

functions to sort column and order by lists

This code is distributed under the terms of GNU GPL
*/
?>
<?php
// TODO: Make this a function!

// Update order of Column Options
// $columnorder is set to presentation list of all possible columns
// $columns is set to only those with 'c_' elements that are set upon entry

unset ($columnorder);
$temp = array();
$columns = array();

foreach ($dcolumnorder as $a) {
	if (isset($FWLOG["$a"])) {
		$temp["$a"] = $FWLOG["$a"];
	}
}

asort($temp);
$columnorder = array_keys($temp);

foreach ($dcolumnorder as $a) {
	if (!isset($temp["$a"])) {
		$columnorder[] = $a;
	}
}

foreach ($columnorder as $a => $b) {
	if (isset($FWLOG["$b"])) $FWLOG["$b"] = "$a" + 1;
}

$columns = array_flip($temp);
unset ($temp);

if (!isset($sortorder)) $sortorder = array();
if ($FWLOG["upd_hosts"] and strtolower($FWLOG["action"]) == "run report" and $FWLOG["page_length"]) {
	if ((isset($FWLOG["c_src_service"]) or isset($FWLOG["c_dst_service"])) and !isset($FWLOG["s_ip_protocol"]))
		$FWLOG["s_ip_protocol"] = 95;
	if (isset($FWLOG["c_src_service"]) and !isset($FWLOG["s_sport"])) $FWLOG["s_sport"] = 96;
	if (isset($FWLOG["c_src_host"]) and !isset($FWLOG["s_ip_saddr"])) $FWLOG["s_ip_saddr"] = 97;
	if (isset($FWLOG["c_dst_service"]) and !isset($FWLOG["s_dport"])) $FWLOG["s_dport"] = 98;
	if (isset($FWLOG["c_dst_host"]) and !isset($FWLOG["s_ip_daddr"])) $FWLOG["s_ip_daddr"] = 99;
}
$FWLOG = sortit ($FWLOG);

?>
