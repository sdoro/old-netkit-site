<?php
/*
$Id: delete_report.php,v 1.9 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

confirm deletion of report definitions

This code is distributed under the terms of GNU GPL
*/
?>

<?php
	$link = db("open", "$database");
	if (db("exists", "SELECT count(*) FROM $reports")) {
		if ($FWLOG["report"] == "default") {
			$status = "<font color='red'>\tCANNOT DELETE DEFAULT</font>\n";
			include "include/edit_report.php";
			exit();
		} elseif (db("totalrows", db("statement", "SELECT code FROM $reports "
			."WHERE code='".db("escape", "{$FWLOG["report"]}")."'")) == 0) {
			$status = "Cannot Delete report code {$FWLOG["report"]}.<br>It does not exist!";
			include "include/edit_report.php";
			exit();
		}
	}
	if (isset($FWLOG["delete_report"])) {
		$code = $FWLOG["delete_report"];
		if (db("exists", "SELECT count(*) FROM $reports")) {
			if (db("statement", "DELETE FROM $reports WHERE code = '".db("escape", "$code")."'")) {
				$status = "\tREPORT $code DELETED!\n";
			} else {
				$status = "Couldn't Delete Report '$code'";
			}
			include "include/edit_report.php";
			exit();
		}
	} // End of "delete"
	db("close", $link);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title>Webfwlog - Delete Report</title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<form action="<?php print "$self"; ?>" method="POST">

<?php
	foreach ($FWLOG as $a => $b) {
			if (!($a == "page"))
			print "<input type='hidden' name=\"".htmlspecialchars("$a", ENT_QUOTES).
				"\" value=\"".htmlspecialchars("$b", ENT_QUOTES)."\">\n";
	}
?>
<input type='hidden' name='page' value='delete'>

<div style="margin-top:5em; " align="center">
<font size="+2">
<table border=1>
  <caption>
     DELETE REPORT DEFINITION<p>
	 <?php if ($status) print "$status"; ?>
  </caption>
    <tr>
    	<td colspan="2">
			<font size="+2">
			<strong>
				<?php
					print "<font color='red'>Deleting {$FWLOG["report"]}:  Are you sure?</font>";
				?>
			</strong>
			</font>
		</td>
	</tr>
	<tr>
		<td style="width:8em; text-align: left; ">Description:</td>
		<td style="width:15em; text-align: left; " colspan=2><?php print htmlspecialchars("{$FWLOG["description"]}"); ?></td>      
    </tr>
    <tr>
      <td style="text-align: left; ">Report Code:</td>
      <td style="text-align: left; ">
		<input type="hidden" name="delete_report" value="<?php print "{$FWLOG["report"]}"; ?>">
			<?php print "{$FWLOG["report"]}"; ?>
		</td>
    </tr>
    <tr>
    	<td colspan="2">
			<input style="width: 16ex; " type="submit" name="action" value="Delete">&nbsp;&nbsp;
			<input style="width: 16ex; " type="submit" name="delete" value="Cancel">
		</td>
	</tr>
</table>
</font>
</div>

</form>

</body>
</html>
