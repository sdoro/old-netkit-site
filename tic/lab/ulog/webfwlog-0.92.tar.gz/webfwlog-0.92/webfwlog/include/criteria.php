<?php
/*
$Id: criteria.php,v 1.9 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

selection criteria form

This code is distributed under the terms of GNU GPL
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" 
		"http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
  <title>Webfwlog - Edit Report <?php print "{$FWLOG["report"]}" ?> - Selection</title>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
</head>

<body bgcolor=#FFFFFF>
	<?php if ($config["debug"]) include "include/debug.php"; ?>
	<div align="center"><h1><?php print "{$config["title"]}"; ?></h1></div>

<table align="center">
<tr>
<td>
<form action="<?php print "$self"; ?>" method="POST">
<?php
	foreach ($FWLOG as $a => $b) {
		if (!(substr($a,0,2) == "w_") 
		  and !(substr($a,0,2) == "i_")
		  and !($a == "page")
		  and !($a == "criteria")) {
			print "<input type='hidden' name='".htmlspecialchars("$a", ENT_QUOTES).
				"' value='".htmlspecialchars("$b", ENT_QUOTES)."'>\n";
		}
	}
?>
<input type="hidden" name="page" value="criteria">

<table align="center" border="1">
	<tr>
	<td>
	<table>
		<caption style="text-align: left; ">
			<strong>Selection Criteria:</strong>
		</caption>
		<colgroup>
			<col style="{width: 12.7em; }">
			<col style="{width: auto; }">
			<col align="center">
			<col style="padding-left: 1em;">
		</colgroup>
		<colgroup>
			<col style="{width: 11.7em; }">
			<col style="{width: auto; }">
			<col align="center">
		</colgroup>
	<thead>
		<tr><th scope=col>Item</th><th scope=col>Search Value</th><th scope=col>Inv</th><th scope=col></th>
			<th scope=col>Item</th><th scope=col>Search Value</th><th scope=col>Inv</th></tr>
	</thead>
	<tbody>
		<tr><td>Min date:&nbsp;&nbsp;&nbsp;oob time
				<input
					type="checkbox"
					name="w_oob_min_date"
					<?php if ($FWLOG["w_oob_min_date"]) print "checked"; ?>
					value="on"
					tabindex=30
				>
			</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_min_date"
					value="<?php print htmlspecialchars("{$FWLOG["w_min_date"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td></td>
			<td></td>
			<td>Max date:&nbsp;&nbsp;&nbsp;oob time
				<input
					type="checkbox"
					name="w_oob_max_date"
					<?php if ($FWLOG["w_oob_max_date"]) print "checked"; ?>
					value="on"
					tabindex=31
				>
			</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_max_date"
					value="<?php print htmlspecialchars("{$FWLOG["w_max_date"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td></td>
		</tr>
		<tr><td><?php print "{$longnames['local_hostname']}"?> (regexp):</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14 name="w_local_hostname"
					value="<?php print htmlspecialchars("{$FWLOG["w_local_hostname"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_local_hostname"]) print "checked"; ?>
					name="i_local_hostname"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td style="{width: auto; border: thin solid #D3D3D3; }" colspan="2" rowspan="4">
				<table>
				<tr class=opts><td colspan="3">TCP Options to include:</td></tr>
				<tr class=opts>  
				<td><span style="float:left;" class=opts>
					<input
						 class=opts
						 type="checkbox"
						 <?php if ($FWLOG["w_tcp_syn"]) print "checked"; ?>
						 name="w_tcp_syn"
						 value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_syn</span>
				</td>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_fin"]) print "checked"; ?>
						name="w_tcp_fin"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_fin</span>
				</td>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_rst"]) print "checked"; ?>
						name="w_tcp_rst"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_rst</span>
				</td>
				</tr>
				<tr class=opts>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_ack"]) print "checked"; ?>
						name="w_tcp_ack"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_ack</span>
				</td>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_urg"]) print "checked"; ?>
						name="w_tcp_urg"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_urg</span>
				</td>
				<td><span style="float:left;" class=opts>
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_psh"]) print "checked"; ?>
						name="w_tcp_psh"
						value="on"
						tabindex=31
					>
					</span>
					<span style="float:none;" class=opts>tcp_psh</span>
				</td>
				</tr>
				<tr class=opts>
				<td colspan="3" class=opts>
					TCP Options exact match:
					<input
						class=opts
						type="checkbox"
						<?php if ($FWLOG["w_tcp_options"]) print "checked"; ?>
						name="w_tcp_options"
						value="on"
						tabindex=31
					>
				</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['oob_prefix']}"?> (regexp):</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_oob_prefix"
					value="<?php print htmlspecialchars("{$FWLOG["w_oob_prefix"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_oob_prefix"]) print "checked"; ?>
					name="i_oob_prefix"
					value="on"
					tabindex=30
				>
			</td>
		</tr>
		<tr style="line-height: .1em;">
			<td style="font-size: xx-small">&nbsp;</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['ip_protocol']}"?> (name or number):</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_protocol"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_protocol"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_protocol"]) print "checked"; ?>
					name="i_ip_protocol" value="on"
					tabindex=30
				>
			</td>
		</tr>
		<tr><td><?php print "{$longnames['tcp_sport']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_tcp_sport"
					value="<?php print htmlspecialchars("{$FWLOG["w_tcp_sport"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_tcp_sport"]) print "checked"; ?>
					name="i_tcp_sport"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['tcp_dport']}"?>:</td>
			<td>
				<input style="height: auto;"
					type="text"
					size=14
					name="w_tcp_dport"
					value="<?php print htmlspecialchars("{$FWLOG["w_tcp_dport"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_tcp_dport"]) print "checked"; ?>
					name="i_tcp_dport"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['udp_sport']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_udp_sport"
					value="<?php print htmlspecialchars("{$FWLOG["w_udp_sport"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_udp_sport"]) print "checked"; ?>
					name="i_udp_sport"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['udp_dport']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_udp_dport"
					value="<?php print htmlspecialchars("{$FWLOG["w_udp_dport"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_udp_dport"]) print "checked"; ?>
					name="i_udp_dport"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['icmp_type']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_icmp_type"
					value="<?php print htmlspecialchars("{$FWLOG["w_icmp_type"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_icmp_type"]) print "checked"; ?>
					name="i_icmp_type"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
		    <td><?php print "{$longnames['icmp_code']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_icmp_code"
					value="<?php print htmlspecialchars("{$FWLOG["w_icmp_code"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_icmp_code"]) print "checked"; ?>
					name="i_icmp_code"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['ip_saddr']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_saddr"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_saddr"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_saddr"]) print "checked"; ?>
					name="i_ip_saddr"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['ip_daddr']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_daddr"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_daddr"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_daddr"]) print "checked"; ?>
					name="i_ip_daddr"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['oob_in']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_oob_in"
					value="<?php print htmlspecialchars("{$FWLOG["w_oob_in"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_oob_in"]) print "checked"; ?>
					name="i_oob_in"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['oob_out']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_oob_out"
					value="<?php print htmlspecialchars("{$FWLOG["w_oob_out"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_oob_out"]) print "checked"; ?>
					name="i_oob_out"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "Minimum Count"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_min_count"
					value="<?php print htmlspecialchars("{$FWLOG["w_min_count"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td></td>
			<td></td>
			<td><?php print "Maximum Count"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_max_count"
					value="<?php print htmlspecialchars("{$FWLOG["w_max_count"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td></td>
		</tr>
		<tr>
			<td>Latest Earliest:&nbsp;&nbsp;&nbsp;oob time
				<input
					type="checkbox"
					name="w_oob_max_earliest"
					<?php if ($FWLOG["w_oob_max_earliest"]) print "checked"; ?>
					value="on"
					tabindex=30
				>
			</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_max_earliest"
					value="<?php print htmlspecialchars("{$FWLOG["w_max_earliest"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td></td>
			<td></td>
			<td>Earliest Latest:&nbsp;&nbsp;&nbsp;oob time
				<input
					type="checkbox"
					name="w_oob_min_latest"
					<?php if ($FWLOG["w_oob_min_latest"]) print "checked"; ?>
					value="on"
					tabindex=31
				>
			</td>
			<td>

				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_min_latest"
					value="<?php print htmlspecialchars("{$FWLOG["w_min_latest"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td></td>
		</tr>
		<tr>
			<td><?php print "{$longnames['ip_tos']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_tos"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_tos"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_tos"]) print "checked"; ?>
					name="i_ip_tos"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['ip_ttl']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_ttl"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_ttl"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_ttl"]) print "checked"; ?>
					name="i_ip_ttl"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['ip_ihl']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_ihl"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_ihl"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_ihl"]) print "checked"; ?>
					name="i_ip_ihl"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['ip_totlen']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_totlen"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_totlen"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_totlen"]) print "checked"; ?>
					name="i_ip_totlen"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['ip_id']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_id"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_id"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_id"]) print "checked"; ?>
					name="i_ip_id"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['ip_csum']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_csum"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_csum"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_csum"]) print "checked"; ?>
					name="i_ip_csum"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['oob_mark']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_oob_mark"
					value="<?php print htmlspecialchars("{$FWLOG["w_oob_mark"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_oob_mark"]) print "checked"; ?>
					name="i_oob_mark"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['ip_fragoff']}"?>
				<br>
				DF
				<input
					type="checkbox"
					name="w_ip_df"
					<?php if ($FWLOG["w_ip_df"]) print "checked"; ?>
					value=0x4000
					tabindex=31
				>
				&nbsp;&nbsp;
				MF
				<input
					type="checkbox"
					name="w_ip_mf"
					<?php if ($FWLOG["w_ip_mf"]) print "checked"; ?>
					value=0x2000
					tabindex=31
				>

			</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ip_fragoff"
					value="<?php print htmlspecialchars("{$FWLOG["w_ip_fragoff"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ip_fragoff"]) print "checked"; ?>
					name="i_ip_fragoff"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['tcp_seq']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_tcp_seq"
					value="<?php print htmlspecialchars("{$FWLOG["w_tcp_seq"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_tcp_seq"]) print "checked"; ?>
					name="i_tcp_seq"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['tcp_ackseq']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_tcp_ackseq"
					value="<?php print htmlspecialchars("{$FWLOG["w_tcp_ackseq"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_tcp_ackseq"]) print "checked"; ?>
					name="i_tcp_ackseq"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['tcp_window']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_tcp_window"
					value="<?php print htmlspecialchars("{$FWLOG["w_tcp_window"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_tcp_window"]) print "checked"; ?>
					name="i_tcp_window"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['tcp_urgp']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_tcp_urgp"
					value="<?php print htmlspecialchars("{$FWLOG["w_tcp_urgp"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_tcp_urgp"]) print "checked"; ?>
					name="i_tcp_urgp"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['icmp_echoid']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_icmp_echoid"
					value="<?php print htmlspecialchars("{$FWLOG["w_icmp_echoid"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_icmp_echoid"]) print "checked"; ?>
					name="i_icmp_echoid"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['icmp_echoseq']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_icmp_echoseq"
					value="<?php print htmlspecialchars("{$FWLOG["w_icmp_echoseq"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_icmp_echoseq"]) print "checked"; ?>
					name="i_icmp_echoseq"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['icmp_gateway']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_icmp_gateway"
					value="<?php print htmlspecialchars("{$FWLOG["w_icmp_gateway"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_icmp_gateway"]) print "checked"; ?>
					name="i_icmp_gateway"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['icmp_fragmtu']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_icmp_fragmtu"
					value="<?php print htmlspecialchars("{$FWLOG["w_icmp_fragmtu"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_icmp_fragmtu"]) print "checked"; ?>
					name="i_icmp_fragmtu"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['udp_len']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_udp_len"
					value="<?php print htmlspecialchars("{$FWLOG["w_udp_len"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_udp_len"]) print "checked"; ?>
					name="i_udp_len"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['raw_mac']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_raw_mac"
					value="<?php print htmlspecialchars("{$FWLOG["w_raw_mac"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_raw_mac"]) print "checked"; ?>
					name="i_raw_mac"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
		<tr>
			<td><?php print "{$longnames['ahesp_spi']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_ahesp_spi"
					value="<?php print htmlspecialchars("{$FWLOG["w_ahesp_spi"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_ahesp_spi"]) print "checked"; ?>
					name="i_ahesp_spi"
					value="on"
					tabindex=30
				>
			</td>
			<td></td>
			<td><?php print "{$longnames['oob_time_usec']}"?>:</td>
			<td>
				<input
					style="height: auto;"
					type="text"
					size=14
					name="w_oob_time_usec"
					value="<?php print htmlspecialchars("{$FWLOG["w_oob_time_usec"]}", ENT_QUOTES); ?>"
					tabindex=31
				>
			</td>
			<td>
				<input
					type="checkbox"
					<?php if ($FWLOG["i_oob_time_usec"]) print "checked"; ?>
					name="i_oob_time_usec"
					value="on"
					tabindex=31
				>
			</td>
		</tr>
<?php if ($config["allow_raw_sql"]) { ?>
		<tr>
			<td colspan="1">Add to SQL WHERE clause:</td>
			<td colspan="6">
				<input
					style="height: auto;"
					type="text"
					size=50
					name="w_extra"
					value="<?php print htmlspecialchars("{$FWLOG["w_extra"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
		</tr>
		<tr>
			<td colspan="1">Add SQL HAVING clause:</td>
			<td colspan="6">
				<input
					style="height: auto;"
					type="text"
					size=50
					name="h_extra"
					value="<?php print htmlspecialchars("{$FWLOG["h_extra"]}", ENT_QUOTES); ?>"
					tabindex=30
				>
			</td>
		</tr>
<?php if ($config["allow_raw_sql"]) ;} ?>
	</tbody>
	</table>
	</td>
	</tr>
	<tr>
		<td>
		<input type="submit" name="action" value="Refresh">&nbsp;
		<input type="reset" value="Reset">
		<input type="submit" name="action" value="Accept">&nbsp;
		</td>
	</tr>
</table>
</form>
</td>
</tr>
<?php
	$doc_page = "criteria";
	include "include/edit_doc.php";
?>
</table>

</body>
</html>
