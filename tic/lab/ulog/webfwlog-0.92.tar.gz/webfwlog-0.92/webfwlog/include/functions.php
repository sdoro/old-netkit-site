<?php
/*
$Id: functions.php,v 1.32 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

functions for webfwlog

This code is distributed under the terms of GNU GPL
*/
?>
<?php

// This function does all database access, and is intended to be 
// data source transparent to the calling statement.  The caller
// neither knows nor cares whether we are using a mysql server,
// a postgresql server, syslog files, etc.

function db ($action, $target)
{
	// Called with (action, target [, source]);
	// if optional third argument is "syslog", use syslog functions,
	// otherwise use db functions.  i.e., calling with only two
	// arguments forces use of db.
	
	global $FWLOG, $config;
	
	if (func_num_args() > 2)
		$source = func_get_arg(2);
	
	if ($source == "syslog") {
		return db_syslog($action, $target);
	} else {
		switch ("{$config["db"]}") {
			case "mysql":
				return db_mysql($action, $target);
				break;
			case "pgsql":
				return db_pgsql($action, $target);
				break;
			default:
				return false;
				break;
		}
	}
}

function db_syslog ($action, $target)
{
	global $config, $colnum, $rownum, $ulog, $database, $fields;
	switch ("$action") {
		case "init":
			$config["iptype"] = "text";
			return;
			break;
		case "open":
			return false;
			break;
		case "close":
			return false;
			break;
		case "escape":
			return addslashes("$target");
			break;
		case "statement":
			return false;
			break;
		case "nextrow":
			$line = $target[$rownum];
			$rownum = $rownum + 1;
			$flds = count($fields);
			if ($flds < 1) {
				if ($line == "") {
					$ret = false;
				} else {
					$ret = $line;
				}
			} else {
				if ($line == "") {
					$ret = false;
				} else {
					$ret = array();
					$thisline = explode("\t", $line);
					$j = 0;
					$k = 0;
					while ($j < $flds) {
						$ret["{$fields[$j]}"] = "{$thisline[$j]}";
						$j = $j + 1;
					}
				}
			}
			return $ret;
			break;
		case "nextfield":
			$line = explode("\t", $target[$rownum]);
			if ($colnum > count($line)) {
				$ret = false;
			} else {
				$ret = $line[$colnum];
			}
			$colnum = $colnum + 1;
			return $ret;
			break;
		case "totalrows":
			return false;
			break;
		case "exists": // Doesn't quit if statement produces SQL error
			return false;
			break;
		case "listtables":
			return false;
			break;
	}
}

function db_mysql ($action, $target)
{
	global $config, $colnum, $ulog, $database, $version_php;
	if ($version_php[0] > 4 or ($version_php[0] = 4 and $version_php[1] >= 3)) {
		$mysql_escape_string = "mysql_real_escape_string";
	} else {
		$mysql_escape_string = "mysql_escape_string";
	}

	switch ("$action") {
		case "init":
			$link = db("open", "");
			$result = db("exists", "SELECT ip_saddr FROM $ulog LIMIT 1;");
			if ($result) $type = mysql_field_type($result, 0);
			if (ereg("int", "$type")) {
				$config["iptype"] = "int";
			} else {
				$config["iptype"] = "text";
			}
			db("close", $link);
			return;
			break;
		case "open":
			$link = mysql_connect("{$config["mysql_server"]}",
								  "{$config["mysql_user"]}",
								  "{$config["mysql_pass"]}")
				or die(mysql_error() . "<br>Cannot Connect to Server!");
			return $link;
			break;
		case "close":
			mysql_close($target)
				or die(mysql_error() . "<br>Cannot close link!");
			return;
			break;
		case "escape":
			$escaped = mysql_escape_string("$target");
			return "$escaped";
			break;
		case "statement":
			if ($config["debug"] >=2) print "<pre>".htmlspecialchars("$target", ENT_QUOTES)."</pre>\n";
			$result = mysql_query($target);
			if (!$result) {
				if ($config["debug"] >= 1) include "include/debug.php";
				if ($config["allow_be_verbose"]) print "<pre>".htmlspecialchars("$target", ENT_QUOTES)."</pre><br>\n";
				die ("<p STYLE=\"color: red\"><strong>Query failed!<br>"
				 . mysql_error() . "</strong></p>");
			}
			return $result;
			break;
		case "nextrow":
			$row = mysql_fetch_array($target,MYSQL_ASSOC);
			return $row;
			break;
		case "nextfield":
			if ($colnum >= mysql_num_fields($target)) return false;
			$field = mysql_field_name($target, $colnum);
			$colnum = $colnum + 1;
			return "$field";
			break;
		case "totalrows":
			return mysql_num_rows($target);
			break;
		case "exists": // Doesn't quit if statement produces SQL error
			if ($config["debug"] >=2) print "<pre>".htmlspecialchars("$target", ENT_QUOTES)."</pre>\n";
			return mysql_query($target);
			break;
		case "listtables":
			$result = mysql_list_tables("$target");
			$out = array();
			while ($row = mysql_fetch_row($result)) {
				$is_ulog_table = true;

				# the columns we want to have in the tables we are going to list
				$wantedcolumns = array(
					"ip_saddr","ip_daddr","ip_protocol","tcp_sport","tcp_dport",
					"udp_sport","udp_dport","icmp_type","icmp_code");

				# build a list of column names
				$fields = mysql_list_fields($target, $row[0]);
				$columns = mysql_num_fields($fields);
				$columnnames = array();
				for ($i = 0; $i < $columns; $i++) {
					array_push($columnnames,mysql_field_name($fields, $i));
				}

				# check each wanted column name against the ones we have
				$colnames = array_flip($columnnames);
				foreach($wantedcolumns as $i) {
					if(!isset($colnames["$i"])) {
						$is_ulog_table = false;
					}
				}

				# if this table contains all our wanted columns, add it to the list
				if($is_ulog_table) {
					array_push($out,$row[0]);
				}
			}
			return $out;
			break;
	}
}

function db_pgsql ($action, $target)
{
	global $config, $colnum, $rownum, $ulog, $database, $version_php, $pg_version, $regexp;
	if ($version_php[0] > 4 or ($version_php[0] = 4 and $version_php[1] >= 2)) {
		$pg_connect = "pg_connect";
		$pg_query = "pg_query";
		$pg_last_error = "pg_last_error";
		$pg_fetch_array = "pg_fetch_array";
		$pg_fetch_row = "pg_fetch_row";
		$pg_close = "pg_close";
		$pg_field_type = "pg_field_type";
		$pg_num_rows = "pg_num_rows";
		$pg_num_fields = "pg_num_fields";
		$pg_field_name = "pg_field_name";
		if ($pg_version[0] < 7 or ($pg_version[0] == 7 and $pg_version[1] < 2)) {
			$pg_escape_string = "addslashes";
		} else {
			$pg_escape_string = "pg_escape_string";
		}
	} else {
		$pg_connect = "pg_connect";
		$pg_query = "pg_exec";
		$pg_last_error = "pg_errormessage";
		$pg_fetch_array = "pg_fetch_array";
		$pg_fetch_row = "pg_fetch_row";
		$pg_close = "pg_close";
		$pg_field_type = "pg_fieldtype";
		$pg_num_rows = "pg_numrows";
		$pg_num_fields = "pg_numfields";
		$pg_field_name = "pg_fieldname";
		$pg_escape_string = "addslashes";
	}
	switch ("$action") {
		case "init":
			$link = db("open", "$database");
			$result = db("exists", "SELECT ip_saddr FROM $ulog LIMIT 1");
			if ($result) $type = $pg_field_type($result, 0);
			if (ereg("int", "$type")) {
				$config["iptype"] = "int";
			} elseif (ereg("inet|cidr", "$type")) {
				$config["iptype"] = "inet";
			} else {
				$config["iptype"] = "text";
			}
			db("close", $link);
			return;
			break;
		case "open":
			if (isset($config["pgsql_server"]))
				$host = "host={$config["pgsql_server"]}";
			$link = $pg_connect("$host
								   user={$config["pgsql_user"]}
								   password={$config["pgsql_pass"]}
								   dbname=$target")
				or die($pg_last_error() . "<br>Cannot Connect to Server!");
			return $link;
			break;
		case "close":
			$pg_close($target)
				or die($pg_last_error() . "<br>Cannot close link!");
			return;
			break;
		case "escape":
			$escaped = $pg_escape_string("$target");
			return "$escaped";
			break;
		case "statement":
			if ($config["debug"] >=2) print "<pre>".htmlspecialchars("$target", ENT_QUOTES)."</pre>\n";
			$result = @$pg_query($target);
			if (!$result) {
				if ($config["debug"] >= 1) include "include/debug.php";
				if ($config["allow_be_verbose"]) print "<pre>".htmlspecialchars("$target", ENT_QUOTES)."</pre><br>\n";
				die ("<p STYLE=\"color: red\"><strong>Query failed!<br>"
				 . $pg_last_error() . "</strong></p>");
			}
			return $result;
			break;
		case "nextrow":
			if ($rownum >=$pg_num_rows($target)) return false;
			$row = $pg_fetch_array($target, $rownum, PGSQL_ASSOC);
			$rownum = $rownum + 1;
			return $row;
			break;
		case "nextfield":
			if ($colnum >=$pg_num_fields($target)) return false;
			$field = $pg_field_name($target, $colnum);
			$colnum = $colnum + 1;
			return "$field";
			break;
		case "totalrows":
			return $pg_num_rows($target);
			break;
		case "exists": // Doesn't quit if statement produces SQL error
			if ($config["debug"] >=2) print "<pre>".htmlspecialchars("$target", ENT_QUOTES)."</pre>\n";
			return @$pg_query("$target");
			break;
		case "listtables":
			if ($have_namespace) {
				$pg_statement = 
				"SELECT c.relname FROM pg_catalog.pg_class c
					LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
					WHERE c.relkind='r' AND n.nspname $regexp '^$target$'";
			} else {
				$pg_statement = 
				"SELECT relname FROM pg_class WHERE relkind='r'";
			}

			$result = db("statement", "$pg_statement");

			$out = array();
			while ($row = $pg_fetch_row($result)) {
				$is_ulog_table = true;

				# the columns we want to have in the tables we are going to list
				$wantedcolumns = array(
					"ip_saddr","ip_daddr","ip_protocol","tcp_sport","tcp_dport",
					"udp_sport","udp_dport","icmp_type","icmp_code");

				# build a list of column names
				if ($have_namespace) {
					$pg_statement = 
					"SELECT a.attname FROM pg_catalog.pg_attribute a
						LEFT JOIN pg_catalog.pg_class c ON c.oid = a.attrelid
						LEFT JOIN pg_catalog.pg_namespace n ON n.oid=c.relnamespace
						WHERE n.nspname $regexp '^$target$'
							AND c.relname $regexp '^$row[0]$'
							AND a.attnum >0
							AND NOT a.attisdropped;";
				} else {
					$pg_statement = 
					"SELECT a.attname
						FROM pg_class c, pg_attribute a
						WHERE c.relname $regexp '^$row[0]$'
						  AND a.attnum > 0 AND a.attrelid = c.oid
					ORDER BY a.attnum;";
				}

				$fieldlist = db("statement", "$pg_statement");
				$columnnames = array();
				while ($fields = $pg_fetch_row($fieldlist)) {
					$columnnames[] = "$fields[0]";
				}

				# check each wanted column name against the ones we have
				$colnames = array_flip($columnnames);
				foreach($wantedcolumns as $i) {
					if(!isset($colnames["$i"])) {
						$is_ulog_table = false;
					}
				}

				# if this table contains all our wanted columns, add it to the list
				if($is_ulog_table) {
					array_push($out,$row[0]);
				}
			}
			return $out;
			break;
	}
}

// Returns decimal representation of $value

function get_number ($value) {
	$a = trim("$value");
	if ($a[0] == 0) {
		if ($a[1] == "x") {
			$ret = intval("$a", 16);
		} else {
			$ret = intval("$a", 8);
		}
	} else {
		$ret = intval("$a", 10);
	}
	return $ret;
}

// This function creates numeric where clause for $field, splitting for
// possible range and multiple values, and validating numeric values.

function where_num ($field) {
	global $FWLOG, $ulog; 
	if ($FWLOG["i_$field"]) {$inv=" NOT";} else {$inv="";}
	$values = explode(",", "{$FWLOG["w_$field"]}");
	$ret = "\tAND ($ulog.$field IS NULL OR$inv (";
	foreach($values as $k => $value) {
		if ($k > 0)
			 $ret = $ret . " OR ";
		$range = explode(":", "$value");
		if (count($range) > 1) {
			if (!is_numeric(trim($range[0])) or !is_numeric(trim($range[1]))) return "";
			$ret = $ret . "$ulog.$field BETWEEN ".get_number($range[0])." AND ".get_number($range[1]);
		} else {
			if (!is_numeric(trim($value))) return "";
			$ret = $ret . "$ulog.$field=".get_number($value);
		}
	}
	return "$ret" . "))\n";
}

// This function is used to generate the uri used in  
// links on html reports

function makewhere ($field, $value) {
	global $config, $FWLOG, $ulog, $count, $source;

	switch ("$field") {
		case "oob_time_sec":
		case "oob_time_usec":	 // These never get
		case "dst_host":	 // links.  Need
		case "src_host":	 // parameter check
		case "dst_service":	 // but this serves
		case "src_service":	 // as fail-safe
		case "local_time":
		case "oob_earliest":
		case "oob_latest":
		case "earliest":
		case "latest":
			return;
			break;
		
		case "tcp_options":
			if ($value[0] =="s" or ereg("SYN", "$value")) {$flag = "on";} else {$flag = "";} $uri = $uri . "&w_tcp_syn=$flag";
			if ($value[1] =="a") {$flag = "on";} else {$flag = "";}; $uri = $uri . "&w_tcp_ack=$flag";
			if ($value[2] =="f") {$flag = "on";} else {$flag = "";}; $uri = $uri . "&w_tcp_fin=$flag";
			if ($value[3] =="r") {$flag = "on";} else {$flag = "";}; $uri = $uri . "&w_tcp_rst=$flag";
			if ($value[4] =="p") {$flag = "on";} else {$flag = "";}; $uri = $uri . "&w_tcp_psh=$flag";
			if ($value[5] =="u") {$flag = "on";} else {$flag = "";}; $uri = $uri . "&w_tcp_urg=$flag";
			$ret = $uri . "&w_tcp_options=on";
			break;
		case "id":
			if ($source == "syslog") {
				$exp = explode(" ", $value);
				$ret = "&w_id=".urlencode("$exp[1]")."&syslog_file=".urlencode("$exp[0]");
			} else {
				$ret = "&w_id=".urlencode("$value");
			}
			return "$ret&reporttype=packet";
			break;
		case "count":
			global $line, $temp;
			$count = "yes";
			foreach ($line as $col => $v) {
				if ($source == "syslog") {
					$field = "$col";
				} else {
					$field = "{$temp["$col"]}";
				}
				if (!("$field" == "id" or "$field" == "count")) {
					$uri = "{$uri}" . makewhere("$field", "$v"); // . " ";
				}
			}
			return "$uri&c_count=&summarize=&c_earliest=&c_latest=&c_oob_earliest=&c_oob_latest=&c_id=0&l_id=on";
			break;

		case "dport":
			if ($count) {
				$ret = "&w_tcp_dport=".urlencode("$value")."&w_udp_dport=".urlencode("$value").""
				."&i_tcp_dport=&i_udp_dport=";
			} else {
				$ret = "&w_ip_protocol=1&i_ip_protocol=on&w_tcp_dport=".urlencode("$value")."&w_udp_dport=".urlencode("$value").""
				."&i_tcp_dport=&i_udp_dport=";
			}
			break;
		case "sport":
			if ($count) {
				$ret = "&w_tcp_sport=".urlencode("$value")."&w_udp_sport=".urlencode("$value").""
				."&i_tcp_sport=&i_udp_sport=";
			} else {
				$ret = "&w_ip_protocol=1&i_ip_protocol=on&w_tcp_sport=".urlencode("$value")."&w_udp_sport=".urlencode("$value").""
				."&i_tcp_sport=&i_udp_sport=";
			}
			break;
		case "ip_protocol":
			$ip_proto = $value;
			if (!is_numeric($ip_proto)) $ip_proto = getprotobyname($ip_proto);
			$ret = "&i_ip_protocol=&w_ip_protocol=".urlencode("{$ip_proto}");
			break;
		case "extra":
				if (!is_numeric($value)) $value = "'".urlencode($value)."'";
				$ret = "&h_extra_value=$value";
			break;
		case "oob_prefix":
		case "local_hostname":
		case "oob_in":
		case "oob_out":
		case "raw_mac":
			// escape regex special characters
			$ret = "&w_{$field}=^".urlencode(addcslashes($value, '^.[$()|*+?\{'))."$";
			$ret = "$ret"."&i_{$field}=";
			break;

		default: 			// If not listed above print link
			if ($value == '') {
				$ret = "";
			} 
			$ret = "&w_{$field}=".urlencode("$value")."&i_{$field}=";
			break;
	}
	return "$ret";
}

// This function sets failsafe defaults, and is 
// only called when nothing else is available
function set_defaults ($FWLOG) {
	global $config;
	unset($FWLOG);
	$FWLOG["summarize"] = "on";
	$FWLOG["page_length"] = "20";
	$FWLOG["refresh"] = "300";
	$FWLOG["description"] = "Summarized activity since yesterday";
	$FWLOG["data_source"] = "{$config["default_data_source"]}";
	$FWLOG["s_ip_protocol"] = "1";
	$FWLOG["o_ip_protocol"] = "on";
	$FWLOG["s_dport"] = "2";
	$FWLOG["s_ip_saddr"] = "3";
	$FWLOG["l_count"] = "on";
	$FWLOG["c_count"] = "1";
	$FWLOG["l_oob_prefix"] = "on";
	$FWLOG["c_oob_prefix"] = "2";
	$FWLOG["l_ip_protocol"] = "on";
	$FWLOG["c_ip_protocol"] = "3";
	$FWLOG["l_ip_saddr"] = "on";
	$FWLOG["c_ip_saddr"] = "4";
	$FWLOG["l_ip_daddr"] = "on";
	$FWLOG["c_ip_daddr"] = "5";
	$FWLOG["l_dport"] = "on";
	$FWLOG["c_dport"] = "6";
	$FWLOG["l_tcp_options"] = "on";
	$FWLOG["c_tcp_options"] = "7";
	$FWLOG["w_min_date"] = "yesterday";
	$FWLOG["w_max_date"] = "Today";
	$FWLOG["w_tcp_syn"] = "on";
	$FWLOG["w_tcp_fin"] = "on";
	$FWLOG["w_tcp_rst"] = "on";
	$FWLOG["w_tcp_ack"] = "on";
	$FWLOG["w_tcp_urg"] = "on";
	$FWLOG["w_tcp_psh"] = "on";
	return $FWLOG;
}

// Returns a comparison expression for selecting by IP/netmask
function where_ip($ip)
{
	
	global $config, $FWLOG;
	$nethost = explode('/', $ip);

	$ipaddr = ip2long($nethost[0]);

	if (count($nethost) > 1) {
		$mask = explode('.', $nethost[1]);
		if (count($mask) == 1 and is_numeric($mask[0])) {
			$netmask = (pow(2,(32 - $mask[0]))) ;
			if ($netmask < pow(2,32) ) $netmask = ~($netmask -1);
		} elseif (count($mask) <= 4) {
			$netmask = ($mask[0] << 24) + ($mask[1] << 16) + ($mask[2] << 8) + $mask[3];
		} else {
			die ("Error in netmask $nethost[1]");
		}
	} else {
		$netmask = pow(2,32) - 1;
	}

	if ($ipaddr < 0 ) $ipaddr += pow(2,32);
	
	$ret = "& $netmask = $ipaddr & $netmask";

	return "$ret";
}

// Returns SQL casting expression based on database in use
// MySQL 3.23 does not support CAST, and does automatic type conversion
function cast_int ($value) {
	global $config;
	if ($config["db"] == "pgsql") {
		return "CAST($value AS INTEGER)";
	} else {
		return "$value";
	}
}

function sortit ($target) {
// Update order of Sorting options
// $sortorder is set to presentation list of all possible columns

global $dsortorder, $sortorder; 

foreach ($sortorder as $k => $v) {
	unset ($sortorder["$k"]);
}

$tempset = array();

foreach ($dsortorder as $a) {
	if (isset($target["$a"])) {
		$tempset["$a"] = $target["$a"];
	}
}

asort($tempset);
$sortorder = array_keys($tempset);

foreach ($dsortorder as $a) {
	if (!isset($tempset["$a"])) {
		$sortorder[] = "$a";
	} 
}

foreach ($sortorder as $a => $b) {
	if (isset($target["$b"])) $target["$b"] = "$a" + 1;
}

unset ($tempset);

return $target;

}

function print_scrollbar($prefix,$currentstart,$total,$pagesize,$barsize)
{
	$currentpage = floor((($currentstart + $pagesize)/ $pagesize) - 1);

	# put the current listed page somewhere in the middle of the bar, so the start = bar / 2
	$startpage = $currentpage - floor($barsize/2);
	# if the start falls of the front, set it to 0
	if($startpage < 0)
	{
		$startpage = 0;
	}
	# bar should be $barsize long, or less
	$endpage = $startpage + ($barsize-1);
	# if there's not enough results, shorten the bar
	if(($endpage+1) * $pagesize > $total)
	{
		$endpage = floor((($total+$pagesize-1) / $pagesize) - 1);
	}
	# if there is only 1page of results...
	if($endpage < 0)
	{
		$endpage = 0;
	}

	print "\t<a href='$prefix"."0'>&lt;&lt;</a>\n";
	
	if($currentpage != 0)
	{
		$s = ($currentpage - 1) * $pagesize;
		print "\t<a href='$prefix$s'>&lt;</a>\n";
	}

	for($i = $startpage; $i <= $endpage; $i++)
	{
		$s = $i * $pagesize;
		print "\t<a href='$prefix$s'>";
		
		if($i == $currentpage)
		{
			print "<strong>[".($i+1)."]</strong>";
		}
		else
		{
			print ($i+1);
		}
		
		print "</a>\n";
	}

	if($currentstart + $pagesize < $total)
	{
		$s = ($currentpage + 1) * $pagesize;
		print "\t<a href='$prefix$s'>&gt;</a>\n";
	}

	$s = (floor(($total + $pagesize - 1) / $pagesize) - 1) * $pagesize;
	print "\t<a href='$prefix$s'>&gt;&gt;</a>\n";
}

// Removes escapes on a single variable or recursively on an array
function stripslashes_deep($value) {
	$value = is_array($value) ?
		array_map('stripslashes_deep', $value) :
		stripslashes($value);

	return $value;
}

?>
