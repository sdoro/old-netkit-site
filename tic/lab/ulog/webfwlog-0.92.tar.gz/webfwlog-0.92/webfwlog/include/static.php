<?php
/*
$Id: static.php,v 1.11 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

static data for webfwlog

This code is distributed under the terms of GNU GPL
*/
?>
<?php

// This file contains static data

// Long Names are used as descriptions on the report specification form
// Short Names are used as column headings on reports
// Edit at your own risk!

// Long Names for variables
$longnames = array(
	'id'				=> 'Record Num',
	'local_time'		=> 'Local Time',
	'local_hostname'	=> 'Local Host',
	'count'				=> 'Count',
	'oob_time_sec'		=> 'OOB Time Sec',
	'oob_time_usec'		=> 'OOB Time &micro;sec',
	'oob_in'			=> 'Input Interface',
	'oob_out'			=> 'Output Interface',
	'earliest'			=> 'Earliest local time',
	'latest'			=> 'Latest local time',
	'oob_earliest'		=> 'Earliest oob time',
	'oob_latest'		=> 'Latest oob time',
	'oob_prefix'		=> 'Log Label',
	'oob_mark'			=> 'Firewall Mark',
	'ip_protocol'		=> 'IP Protocol',
	'ip_saddr'			=> 'Source IP',
	'src_host'			=> 'Source Host',
	'ip_daddr'			=> 'Destination IP',
	'dst_host'			=> 'Destination Host',
	'ip_tos'			=> 'IP TOS',
	'ip_ttl'			=> 'IP Time-to-Live',
	'ip_totlen'			=> 'IP Total Length',
	'ip_ihl'			=> 'IP Header Length',
	'ip_csum'			=> 'IP Checksum',
	'ip_id'				=> 'IP ID',
	'ip_fragoff'		=> "Fragmentation Offset",
	'sport'				=> 'Source Port',
	'src_service'		=> 'Source Service',
	'dport'				=> 'Destination Port',
	'dst_service'		=> 'Destination Service',
	'tcp_sport'			=> 'TCP Source Port',
	'tcp_dport'			=> 'TCP Destination Port',
	'tcp_seq'			=> 'TCP Sequence Number',
	'tcp_ackseq'		=> 'TCP ACK Sequence Number',
	'tcp_window'		=> 'TCP Window',
	'tcp_options'		=> 'TCP Options',
	'tcp_urg'			=> 'tcp_urg',
	'tcp_urgp'			=> 'TCP Urgent Pointer',
	'tcp_ack'			=> 'tcp_ack',
	'tcp_psh'			=> 'tcp_psh',
	'tcp_rst'			=> 'tcp_rst',
	'tcp_syn'			=> 'tcp_syn',
	'tcp_fin'			=> 'tcp_fin',
	'udp_sport'			=> 'UDP Source Port',
	'udp_dport'			=> 'UDP Destination Port',
	'udp_len'			=> 'UDP Length',
	'icmp_type'			=> 'ICMP Type',
	'icmp_code'			=> 'ICMP Code',
	'icmp_echoid'		=> 'ICMP Echo ID',
	'icmp_echoseq'		=> 'ICMP Echo Sequence Number',
	'icmp_gateway'		=> 'ICMP Redirect Gateway',
	'icmp_fragmtu'		=> 'ICMP Next Hop MTU',
	'raw_mac'			=> 'MAC Address',
	'pwsniff_user'		=> 'pwsniff user',
	'pwsniff_pass'		=> 'pwsniff pass',
	'ahesp_spi'			=> 'AH/ESP protocol SPI',
	'extra'				=> 'Add to SQL WHERE Clause'
);

// Short Names for variables
// Should be unique
$shortnames = array(
	'local_hostname'	=> 'Local Host',
	'oob_in'			=> 'In If',
	'oob_out'			=> 'Out If',
	'count'				=> 'Count',
	'id'				=> 'Packet',
	'raw_mac'			=> 'MAC Address',
	'local_time'		=> 'Local Time',
	'oob_time_sec'		=> 'Time Secs',
	'oob_time_usec'		=> 'Time &micro;sec',
	'earliest'			=> 'Earliest',
	'latest'			=> 'Latest',
	'oob_earliest'		=> 'Earliest OOB',
	'oob_latest'		=> 'Latest OOB',
	'oob_prefix'		=> 'Label',
	'oob_mark'			=> 'Mark',
	'ip_protocol'		=> 'Proto',
	'ip_saddr'			=> 'Source IP',
	'src_host'			=> 'Source Host',
	'ip_daddr'			=> 'Destination IP',
	'dst_host'			=> 'Destination Host',
	'ip_tos'			=> 'TOS',
	'ip_ttl'			=> 'TTL',
	'ip_totlen'			=> 'Pkt Len',
	'ip_ihl'			=> 'Head Len',
	'ip_csum'			=> 'Checksum',
	'ip_id'				=> 'IP ID',
	'ip_fragoff'		=> "Fragoff",
	'sport'				=> 'Src Port',
	'src_service'		=> 'Src Service',
	'dport'				=> 'Dest Port',
	'dst_service'		=> 'Dest Service',
	'tcp_seq'			=> 'TCP Seq',
	'tcp_ackseq'		=> 'Ack Seq',
	'tcp_window'		=> 'Window',
	'tcp_options'		=> 'Options',
	'tcp_urg'			=> 'tcp_urg',
	'tcp_urgp'			=> 'Urgent Pointer',
	'tcp_ack'			=> 'tcp_ack',
	'tcp_psh'			=> 'tcp_psh',
	'tcp_rst'			=> 'tcp_rst',
	'tcp_syn'			=> 'tcp_syn',
	'tcp_fin'			=> 'tcp_fin',
	'udp_len'			=> 'UDP Len',
	'icmp_type'			=> 'Ty',
	'icmp_code'			=> 'Co',
	'icmp_echoid'		=> 'Echo ID',
	'icmp_echoseq'		=> 'Echo Seq',
	'icmp_gateway'		=> 'Gateway',
	'icmp_fragmtu'		=> 'MTU',
	'pwsniff_user'		=> 'pwsniff user',
	'pwsniff_pass'		=> 'pwsniff pass',
	'ahesp_spi'			=> 'AH/ESP SPI',
);

// The default column and sort orders are the order in which unselected 
// items will appear on the report specification form
//
// Edit at your own risk!

// default Column order
$dcolumnorder = array(
	'c_count',
	'c_local_hostname',
	'c_local_time',
	'c_oob_time_sec',
	'c_oob_time_usec',
	'c_earliest',
	'c_latest',
	'c_oob_earliest',
	'c_oob_latest',
	'c_oob_prefix',
	'c_oob_mark',
	'c_oob_in',
	'c_oob_out',
	'c_ip_saddr',
	'c_src_host',
	'c_ip_daddr',
	'c_dst_host',
	'c_ip_protocol',
	'c_ip_tos',
	'c_ip_ttl',
	'c_ip_totlen',
	'c_ip_ihl',
	'c_ip_csum',
	'c_ip_id',
	'c_ip_fragoff',
	'c_dport',
	'c_dst_service',
	'c_sport',
	'c_src_service',
	'c_tcp_seq',
	'c_tcp_ackseq',
	'c_tcp_window',
	'c_tcp_options',
	'c_tcp_urgp',
	'c_udp_len',
	'c_icmp_type',
	'c_icmp_code',
	'c_icmp_echoid',
	'c_icmp_echoseq',
	'c_icmp_gateway',
	'c_icmp_fragmtu',
	'c_id',
	'c_raw_mac',
	'c_pwsniff_user',
	'c_pwsniff_pass',
	'c_ahesp_spi'
);

// default sort order
$dsortorder = array(
	's_count',
	's_ip_protocol',
	's_dport',
	's_ip_saddr',
	's_ip_daddr',
	's_sport',
	's_local_hostname',
	's_oob_prefix',
	's_tcp_options',
	's_oob_in',
	's_oob_out',
	's_earliest',
	's_latest',
	's_oob_earliest',
	's_oob_latest',
	's_local_time',
	's_oob_time_sec',
	's_oob_time_usec',
	's_oob_mark',
	's_ip_tos',
	's_ip_ttl',
	's_ip_totlen',
	's_ip_ihl',
	's_ip_csum',
	's_ip_id',
	's_ip_fragoff',
	's_tcp_seq',
	's_tcp_ackseq',
	's_tcp_window',
	's_tcp_urgp',
	's_udp_len',
	's_icmp_type',
	's_icmp_code',
	's_icmp_echoid',
	's_icmp_echoseq',
	's_icmp_gateway',
	's_icmp_fragmtu',
	's_id',
	's_raw_mac',
	's_pwsniff_user',
	's_pwsniff_pass',
	's_ahesp_spi'
);

if ($config["allow_raw_sql"]) { ;
	$dcolumnorder[] = "c_extra";
	$dsortorder[] = "s_extra";
}

?>
