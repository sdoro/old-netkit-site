<?php
/*
$Id: index.php,v 1.3 2006/03/03 17:27:38 bhockney Exp $
(C) 2003-2006 by Bob Hockney <zeus@ix.netcom.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
    
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
?>
<?php
	$time = time();

	$version_php = explode(".", phpversion());
	$self = "{$_SERVER["PHP_SELF"]}";

	header("Cache-control: private");

	require "include/config.php";
	require "include/static.php";
	require "include/functions.php";
	require "include/state.php";

	unset($source);
	if (!(strtolower($FWLOG["action"]) == "update cache")
		and (strtolower($FWLOG["data_source"]) == "syslog"
			or (!isset($FWLOG["data_source"])
				and strtolower($config["default_data_source"]) == "syslog")))
		$source = "syslog";

	db("init", "", "$source");

	if ($config["iptype"] == "int") {
		$ip_saddr = "$ulog.ip_saddr";
		$ip_daddr = "$ulog.ip_daddr";
	} else {
		$ip_saddr = "$inet_aton($ulog.ip_saddr)";
		$ip_daddr = "$inet_aton($ulog.ip_daddr)";
	}

	if (isset($FWLOG["selection"])) {
		$temp = $_SESSION["fwlog"];
		unset($temp["selection"]);
		$_SESSION["fwlog"] = $temp;
		include 'include/selection.php';
		return;
	}
	if (isset($FWLOG["sorting"])) {
		$temp = $_SESSION["fwlog"];
		unset($temp["sorting"]);
		$_SESSION["fwlog"] = $temp;
		include 'include/sorting.php';
		return;
	}
	if (isset($FWLOG["criteria"])) {
		$temp = $_SESSION["fwlog"];
		unset($temp["criteria"]);
		$_SESSION["fwlog"] = $temp;
		include 'include/criteria.php';
		return;
	}

	if (strtolower($FWLOG["export"]) == "cancel" or 
		strtolower($FWLOG["import"]) == "cancel" or 
		strtolower($FWLOG["delete"]) == "cancel" or 
		strtolower($FWLOG["save"]) == "cancel") {
			$temp = $_SESSION["fwlog"];
			unset ($temp["save"]);
			unset ($temp["export"]);
			unset ($temp["import"]);
			unset ($temp["delete"]);
			$_SESSION["fwlog"] = $temp;
			include 'include/edit_report.php';
			return;
	}

	switch (strtolower($FWLOG["action"])) {
		case "resolve hosts":
			$FWLOG["c_src_host"]=0;
			$FWLOG["c_dst_host"]=0;
			$FWLOG["c_src_service"]=0;
			$FWLOG["c_dst_service"]=0;
			$FWLOG["upd_hosts"] = 1;
			unset($FWLOG["reporttype"]);
			if (!isset($FWLOG["data_source"]))
				$FWLOG["data_source"] = $config["default_data_source"];
			include "include/packet.php";
			break;
		case "run report":
			if (!isset($FWLOG["data_source"]))
				$FWLOG["data_source"] = $config["default_data_source"];
			if ($FWLOG["reporttype"] == "packet") {
				include "include/packet.php";
			} else {
				unset ($FWLOG["w_id"]);
				unset($FWLOG["action"]);
				$link = db("open", "$database");
				if (db("exists", "SELECT last_accessed FROM $reports") and
					isset($FWLOG["report"])) {
					db("statement", "UPDATE $reports SET last_accessed = $time"
						." WHERE code = '".db("escape", "{$FWLOG["report"]}")."'");
				}
				db("close", $link);
				if (strtolower($FWLOG["data_source"]) == "ulogd") {
					require "include/sql.php";
					require "include/html_out.php";
				} elseif (strtolower($FWLOG["data_source"]) == "syslog") {
					require "include/syslog.php";
					require "include/html_out.php";
				} else {  // fail-safe default to ulogd as data source
					$FWLOG["data_source"] == "ulogd";
					require "include/sql.php";
					require "include/html_out.php";
				}
			}
			break;
		case "refresh":
			switch (strtolower($FWLOG["page"])) {
				case "spec": require "include/edit_report.php"; break;
				case "selection": require "include/selection.php"; break;
				case "sorting": require "include/sorting.php"; break;
				case "criteria": require "include/criteria.php"; break;
				case "save": require "include/save_report.php"; break;
				default: require "include/edit_report.php"; break;
			}
			break;
		case "export":
			if (isset($FWLOG["report"]) and $FWLOG["report"] <> "<NEW>") {
				$cur_rpt = "{$FWLOG["report"]}";
			} else {
				$cur_rpt = "";
			}
			header("Content-Type: text/plain;");
			header("Content-Disposition: attachment; filename=\"$cur_rpt\"");
			unset ($FWLOG["action"]); // don't save these
			unset ($FWLOG["page"]);
			unset ($FWLOG["orig_report"]);
			unset ($FWLOG["select_report"]);
			unset ($FWLOG["export_report"]);
			unset ($FWLOG["report_order"]);
			unset ($FWLOG["update_all"]);
			unset ($FWLOG["show_sql"]); // deprecated, use be_verbose
			foreach ($FWLOG as $k => $v) {
				if ($k == "report") continue;
				print "$k=\"$v\"\n";
			}
			break;
		case "import":
			include "include/import.php";
			break;
		case "update cache":
			include "include/update_cache.php";
			break;
		case "done":
		case "cancel":
			switch (strtolower($FWLOG["page"])) {
				case "spec": require "include/edit_report.php"; break;
				case "home": require "include/home.php"; break;
				default: require "include/edit_report.php"; break;
			}
			break;
		case "save":
			$FWLOG["orig_report"] = $FWLOG["report"];
			include "include/save_report.php";
			break;
		case "commit":
			include "include/save_report.php";
			break;
		case "delete":
			$FWLOG["orig_report"] = $FWLOG["report"];
			include "include/delete_report.php";
			break;
		case "accept":
		case "create new":
		case "save as default":
		case "use report":
		case "report editor":
			require "include/edit_report.php";
			break;
		case "select data source":
			$source_state = array();
			if (isset($FWLOG["data_source"]))
				$source_state["data_source"] = "{$FWLOG["data_source"]}";
			if (isset($FWLOG["ulog_table"]))
				$source_state["ulog_table"] = "{$FWLOG["ulog_table"]}";
			if (isset($FWLOG["syslog_file"]))
				$source_state["syslog_file"] = "{$FWLOG["syslog_file"]}";
			$_SESSION["fwlog_source"] = $source_state; 
			require "include/home.php";
			break;
		case "return to main menu":
			unset ($FWLOG["data_source"]);
			unset ($FWLOG["ulog_table"]);
			unset ($FWLOG["syslog_file"]);

			if ($_SESSION["fwlog_source"])
				$FWLOG = $_SESSION["fwlog_source"] + $FWLOG;
			require "include/home.php";
			break;
		default:
			require "include/home.php";
			break;
	}
?>
