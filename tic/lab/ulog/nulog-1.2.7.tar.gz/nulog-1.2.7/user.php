<?php
#
# Copyright(C) 2003-2006 INL
# Written by Eric Leblond <regit@inl.fr>
#            Vincent Deffontaines <gryzor@inl.fr>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 2 of the License.
#
#  This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#

$getquery=$_GET['query'];
if(!isset($getquery)){
  $show_state_menu="no";
}
$state=-1;
$state=$_GET['state'];
/* if ($state==4 || $state==2 || $state==1){
	$restrict_menu="yes";
}
*/
require("include/header.inc");

$restrict_menu="no";

$userid=$_GET['userid'];
$username=$_GET['username'];

	if ($nufw_enabled == "yes"){
		if (!(($state>=-1) and ($state<=4)))
			$state=-1;
		if (!preg_match('/^[0-9-]+$/',$state))
			$state=-1;
	}

$and_state_query="";
	if (($nufw_enabled=="yes") and ($state!=-1)) {
		if ($state==4)
			$and_state_query="AND (state=1 OR state=2)";
		else
			$and_state_query="AND state=$state ";
	}

#convert
if (isset($username)){
	if (!preg_match('/^[a-zA-Z\\\\0-9]+$/',$username)){
		echo "Bad username INPUT detected. Sorry";
		exit;
	}
	$username_query=1;
}else if (isset($userid)){
	if (!preg_match('/^[0-9]+$/',$userid)){
		echo "Bad userid INPUT detected. Sorry";
		exit;
	}
	$username_query=0;
	$username = resolve_user($userid);
	if ($username == "")
	{
		$username = "-";
	}
}

$start=$_GET['start'];
$start=check_start($start);
if (! isset($start)) {
	$start=0;
}
?>
<div id="leftmenu">
<?php include("include/leftmenu.inc"); ?>
</div> <!-- leftmenu -->


		<div id="datas">
			<div id="textbody">

<?php


if (! isset($getquery)) {
	echo "<div ><h2><a href='user.php'>$users_sessions_main_message</a></h2>\n";
	print_usersession($start,$number_page);
} else {

#$query_order=$_GET['query_order'];
#if (isset($query_order)){
#	if ( $query_order == "s" )
#		$resp_order="d";
#	elseif ($query_order == "d")
#		$resp_order="d";
#	else {
#	$query_order="s";
#	$resp_order="d";
#	}
#
#} else {
#	$query_order="s";
#	$resp_order="d";
#}
#
	if ($username_query == 0){
		if ($conntrack_enabled == "yes") {
			$query="(select $packet_query_info from $table_ulog where user_id=$userid $and_state_query) UNION (select $packet_query_info from $table_conntrack where user_id=$userid $and_state_query) order by oob_time_sec DESC,oob_time_usec DESC limit $start,$number_page";
		} else {
			$query="select $packet_query_info from $table_ulog where user_id=$userid $and_state_query  order by oob_time_sec DESC,oob_time_usec DESC limit $start,$number_page";
		}
    } else {
        if ($conntrack_enabled == "yes") {
            $query="(select $packet_query_info from $table_ulog where username  like \"%".addslashes($username)."%\" $and_state_query) UNION (select $packet_query_info from $table_conntrack where username like  \"%".addslashes($username)."%\" $and_state_query) order by oob_time_sec DESC,oob_time_usec DESC limit $start,$number_page";
        } else {
            $query="select $packet_query_info from $table_ulog where username like \"%".addslashes($username)."%\" $and_state_query  order by oob_time_sec DESC,oob_time_usec DESC  limit $start,$number_page";
        }
	}

    if ($username_query == 0){
        echo "<div class=mainarray><h2>$stats_for_user_message ".clean_username($username)." - $userid_message : ".$userid."</h2>";
        echo "<h3>(".print_user_state($userid).")</h3>";
    } else {
        echo "<div class=mainarray><h2>$search_user_result_message $username:</h2>";
    }
	$header="<tr><td colspan=9 class=header>";
	$header.="<table width=100% cellpadding=0 cellspacing=0>";
    if ($username == "-"){
	$header.="<thead><tr><td><h3>$packets_from_user_message ".clean_username($username).":</h3></td><td align=right> ( $start, ".($start+$number_page-1)." )</td></tr></thead>";
    } else {
	$header.="<thead><tr><td><h3>$selected_packet_message</h3></td><td align=right> ( $start, ".($start+$number_page-1)." )</td></tr></thead>";
    }
	$header.="</table></td></tr>";

	if (isset($userid)){
		packet_query($header,$query,"user.php?start=".max($start-$number_page,0)."&userid=$userid&state=$state&query=direct","user.php?start=".($start+$number_page)."&userid=$userid&state=$state&query=direct",$state);
	} else {
		packet_query($header,$query,"user.php?start=".max($start-$number_page,0)."&username=$username&state=$state&query=direct","user.php?start=".($start+$number_page)."&username=$username&state=$state&query=direct",$state);

	}
}
?>


			</div> <!-- textbody -->
		</div> <!-- datas -->
	<div class="footer">
<?php
require("include/footer.inc");
?>
</div>
<?php
if ($footer_file){
	require($footer_file);
	}
	?>
</body>
</html>
