<?php
#
# Copyright(C) 2003-2007 INL
# Written by Eric Leblond <regit@inl.fr>
#            Vincent Deffontaines <gryzor@inl.fr>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 2 of the License.
#
#  This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
$state=-1;
$state=$_GET['state'];
if ($state==4 || $state==1 || $state==2)
  $restrict_menu="yes";

require("include/header.inc");
$restrict_menu="no";

$host=$_GET['host'];

if (!preg_match('/^[a-zA-Z0-9.]+$/',$host))
  $host='';

if ($nufw_enabled == "yes"){
  if (!(($state>=-1) and ($state<=4)))
    $state=-1;
  if (!preg_match('/^[0-9-]+$/',$state))
    $state=-1;
}
?>
<div id="leftmenu">
<?php include("include/leftmenu.inc"); ?>
</div> <!-- leftmenu -->

		<div id="datas">
			<div id="textbody">
<?php
$and_state_query=build_and_state_query($state);

if (isset($query)){
	#convert
	if ( ! preg_match("/\d+\.\d+\.\d+\.\d+/",$host) ) {
		$iphost=gethostbyname($host);

	if($iphost == $host){
		print "<div class=mainarray><h2>Unknown host</H2></div>";
		exit;
	} else {
		$host = $iphost;
	}
	}
	$host=ip2long(preg_replace("/\s+/","",$host));
	if ($host<0)
	$host=$host+4294967296;
}

$query_order=$_GET['query_order'];
if (isset($query_order)){
	if ( $query_order == "s" )
		$resp_order="d";
	elseif ($query_order == "d")
		$resp_order="d";
	else {
	$query_order="s";
	$resp_order="d";
	}

} else {
	$query_order="s";
	$resp_order="d";
}

$start=$_GET['start'];
$start=check_start($start);
if (! isset($start)) {
         $start=0;
	 }

if ($conntrack_enabled == "yes") {
  $query="(select $packet_query_info from $table_ulog where ip_".$query_order."addr=$host $and_state_query) UNION (select $packet_query_info from $table_conntrack where ip_".$query_order."addr=$host $and_state_query) order by oob_time_sec DESC,oob_time_usec DESC limit $start,$number_page";
} else {
   $query="select $packet_query_info from $table_ulog where ip_".$query_order."addr=$host $and_state_query order by oob_time_sec DESC,oob_time_usec DESC limit $start,$number_page";
}

if ($query_order == "s"){
	echo "<div class=mainarray><h2><img src=\"images/host32.gif\" alt=\"host\" border=0> $stats_from_host_message ".gethostbyaddr(long2ip($host))."</h2>";
} else {
	echo "<div class=mainarray><h2><img src=\"images/host32.gif\" alt=\"host\" border=0> $stats_to_host_message ".gethostbyaddr(long2ip($host))."</h2>";
}

$header="<tr><td colspan=9 class=header>";
$header.="<table class=div_header  width=100% cellpadding=0 cellspacing=0>";
$header.="<thead><tr><td ><h3>$host_message ".long2ip($host)." :</h3></td><td align=right> ( $start, ".($start+$number_page-1)." )</td></tr></thead>\n";
$header.="</table></td></tr>";

packet_query($header,$query,"host.php?start=".max($start-$number_page,0)."&host=$host&state=$state","host.php?query_order=$query_order&start=".($start+$number_page)."&host=$host&state=$state",$state);
?>
			</div> <!-- textbody -->
		</div> <!-- datas -->
		<div class="footer">
<?php
require("include/footer.inc");
echo "</div>";
if ($footer_file){
	require($footer_file);
	}
?>
</body>
</html>
