<?php
# Generate cache.  Script to be run regularly and automatically, so that
# the home page does not take too long to load if it has not been loaded
# for long.
require("include/header.inc");
?>
