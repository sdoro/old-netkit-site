<?php
#
# Copyright(C) 2003-2006 INL
# Written by Eric Leblond <regit@inl.fr>
#            Vincent Deffontaines <gryzor@inl.fr>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 2 of the License.
#
#  This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#

$show_state_menu="no";
$display_clear_cache=1;
require("include/header.inc");
require("include/messages.php");

/* set state to 0 to display only DROP */
$state=0;

# 0 is TCP
# 1 is UDP
# 2 is bad host
# 3 is users
$start=split(',',$_GET['start']);
$start[0]=check_start($start[0]);
$start[1]=check_start($start[1]);
$start[2]=check_start($start[2]);
$start[3]=check_start($start[3]);
if( count($start)<4 ) {
$start[0]=0;$start[1]=0;$start[2]=0; $start[3]=0;
}


$order=split(',',$_GET['order']);
if( count($order)<4 ) {
$order[0]="last_time";$order[1]="last_time";$order[2]="last_time";
$order[3]="last_time";
}
$order[0]=check_order($order[0]);
$order[1]=check_order($order[1]);
$order[2]=check_order($order[2]);
$order[3]=check_order($order[3]);

?>
<script language="JavaScript" type="text/javascript">
function reload(index,start,order) {
var form=document.main;

if(order!=null) {
	aorder=form.order.value.split(",");
	aorder[index]=order;
	form.order.value=aorder.join(",");

	start=0;
}

astart=form.start.value.split(",");
astart[index]=start;
form.start.value=astart.join(",");

form.submit();
}

</script>
<div id="leftmenu">
<?php include("include/leftmenu.inc"); ?>
</div> <!-- leftmenu -->



<form name="main" action="index.php">

<input type=hidden name=start value=<?php echo join(',',$start)?>>
<input type=hidden name=order value=<?php echo join(',',$order)?>>
<input type=hidden name=state value=<?php echo $state?>>

</form>

<!--
<center>

<table border=0 width=1000 cellspacing=0 cellpadding=0 bgcolor=#FFFFFF>
<tr>
<td colspan=2>
-->

<h2 id="head">
<img src="images/global32.gif" alt="global" border=0> <?php echo $global_stats_message.$machine;?>
</h2>
		<div id="datas">
			<div id="rightmenu">
				<div class="tcpports">


<?php
// table bad tcp ports

$header=getHeader(1,$bad_tcp_packets_message.":",$tcp_port_message,$port_number);

$query="select tcp_dport,count,first_time,last_time from tcp_ports${machine_suffix} order by $order[1] desc limit $start[1],$port_number;";

put_table($query,$header,"print_row_tcp","javascript:reload(1,".max($start[1]-$port_number,0).",null);","javascript:reload(1,".($start[1]+$port_number).",null);",$state);

?>
				</div> <!-- tcpports -->

				<div class="udpports">
<?php
// table bad udp ports

$header=getHeader(2,$bad_udp_packets_message.":",$udp_port_message,$port_number);

$query="select udp_dport,count,first_time,last_time from udp_ports${machine_suffix} order by $order[2] desc limit $start[2],$port_number;";

put_table($query,$header,"print_row_udp","javascript:reload(2,".max($start[2]-$port_number,0).",null);","javascript:reload(2,".($start[2]+$port_number).",null);",$state);

?>
				</div> <!-- udpports -->
			</div> <!-- rightmenu -->
			<div id="textbody">
					<div class="badhosts">
<?php

if ($nufw_enabled=="yes") {
	print_users_table("index.php",$start[3],$number,$order[3],3);
}

//table bad hosts



$header=getHeader(0,"<img src=\"images/host.gif\" border=0 alt=\"host\"> ".$bad_hosts_packets_message.":",$host_message,$number);

$query="select ip_addr,count,first_time,last_time from offenders${machine_suffix} order by $order[0] DESC limit $start[0],$number;";

put_table($query,$header,"print_row_host","javascript:reload(0,".max($start[0]-$number,0).",null);","javascript:reload(0,".($start[0]+$number).",null);",$state);

?>
					</div> <!-- badhosts -->
			</div> <!-- textbody -->
		</div> <!-- datas -->


			<div class="footer">
<?php
require("include/footer.inc");
?>
			</div> <!-- footer -->

<?php
if ($footer_file){
	require($footer_file);
}
?>
</body>
</html>
