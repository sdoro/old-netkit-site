<?php
#
# Copyright(C) 2003-2005 INL
# Written by Eric Leblond <regit@inl.fr>
#            Vincent Deffontaines <gryzor@inl.fr>
#	     Thomas Sabono <thomas@inl.fr>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 2 of the License.
#
#  This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#

$restrict_menu="yes";
require("include/header.inc");
$restrict_menu="no";

$state=-1;
if ($nufw_enabled == "yes") {
	$state=$_GET['state'];
	if (!(($state>=-1) and ($state<=3)))
        	$state=-1;
	if (!preg_match('/^[0-9-]+$/',$state))
	      $state=-1;
}

$query_order=$_GET['query_order'];
if (isset($query_order)){
	if ( $query_order == "s" )
		$resp_order="d";
	elseif ($query_order == "d")
		$resp_order="d";
	else {
		$query_order="s";
		$resp_order="d";
	}
} else {
	$query_order="s";
	$resp_order="d";
}

$start=$_GET['start'];
$start=check_start($start);
if (! isset($start)) {
	$start=0;
}

#
## Query building.
#

if ($conntrack_enabled!="yes"){
    $table_conntrack=$table_ulog;
}
if ($state == -1)
	$query="select $packet_query_info from $table_conntrack where (state=1 or state=2) order by oob_time_sec DESC,oob_time_usec DESC limit $start,$number_page";
else
	$query="select $packet_query_info from $table_conntrack where state=$state order by oob_time_sec DESC,oob_time_usec DESC limit $start,$number_page";
?>
<div id="leftmenu">
<?php include("include/leftmenu.inc"); ?>
</div> <!-- leftmenu -->

		<div id="datas">
			<div id="textbody">
<?php
echo "<div class=mainarray><h2><img src=\"images/host32.gif\" alt=\"host\" border=0>$authenticated_connection_tracking_message</h2>";

#
## Header building.
#
$header="<tr><td colspan=10 class=header>";
$header.="<table class=div_header width=100% cellpadding=0 cellspacing=0>";
$header.="<thead><tr><td ><h3>$connection_tracking_message</h3></td><td align=right> ( $start, ".($start+$number_page-1)." )</td></tr></thead>";
$header.="</table></td></tr>";

#
## Put table.
#
$link_prev="conntrack.php?start=" .($start-$number_page > 0 ? $start-$number_page : 0);
$link_next="conntrack.php?start=" .($number_page+$start);

global $destport;

$destport="yes";
packet_query($header,$query, $link_prev, $link_next, $state);
$destport="no";
?>
			</div> <!-- textbody -->
		</div> <!-- datas -->
		<div class="footer">
<?php
require("include/footer.inc");
echo "</div>";
if ($footer_file){
	require($footer_file);
}
?>
</body>
</html>
