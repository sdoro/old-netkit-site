<?php
#
# Copyright(C) 2003-2006 INL
# Written by Eric Leblond <regit@inl.fr>
#            Vincent Deffontaines <gryzor@inl.fr>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 2 of the License.
#
#  This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
$state=-1;
$state=$_GET['state'];

if ($state== 4 || $state==2 || $state==1)
  $restrict_menu="yes";

require("include/header.inc");
$restrict_menu="no";

$port=$_GET['port'];
$port=check_start($port);

$and_state_query=build_and_state_query($state);

if (isset($port)){
	$port=(int) preg_replace("/\s+/","",$port);
	if (0>$port or  $port>65556){
		$port=0;
		echo "You joker, port is null now";
	}
} else {
	$port=0;
}

$start=$_GET['start'];
$start=check_start($start);
if (! isset($start)) {
         $start=0;
}

$protocol='';

$query="select $packet_query_info from $table_ulog where ";
if ($conntrack_enabled == "yes") {
	$query="(".$query;
}
$proto=$_GET['proto'];
if (isset($proto)) {
  if(($proto == "tcp") or ($proto == "udp")){
	$query.=" ${proto}_dport=$port";
	$protocol .=" ${proto}_dport=$port";
  } else {
        $proto="";
	$query.=" (tcp_dport=$port or udp_dport=$port) ";
	$protocol .=" (tcp_dport=$port or udp_dport=$port) ";
  }
} else {
	$query.=" (tcp_dport=$port or udp_dport=$port) ";
	$protocol .=" (tcp_dport=$port or udp_dport=$port) ";
}
if ($conntrack_enabled == "yes") {
  $query.=" $and_state_query ) UNION (select $packet_query_info from $table_conntrack where $protocol $and_state_query ) order by oob_time_sec DESC,oob_time_usec DESC limit $start,$number_page";
} else {
  $query.=" $and_state_query order by oob_time_sec DESC,oob_time_usec DESC  limit $start,$number_page";
}
?>
<div id="leftmenu">
<?php include("include/leftmenu.inc"); ?>
</div> <!-- leftmenu -->

		<div id="datas">
			<div id="textbody">
<?php
$name_port=getservbyport($port,$proto);
if($name_port=='') $name_port="( $port , $proto )";
echo "<div class=mainarray>";
echo "<h2> $stats_for_port_message $name_port ";
echo "<a href=http://www.dshield.org/port.html?port=$port><img src=images/note.gif border=0></a>";
echo "</h2>";

$header="<tr><td colspan=9 class=header>";
$header.="<table width=100% cellpadding=0 cellspacing=0>";
$header.="<thead><tr><td><h3>$port_message $port,$proto :</h3></td><td align=right> ( $start, ".($start+$number_page-1)." )</td></tr></thead>";
$header.="</table></td></tr>";

if ($proto){
  $add_proto="&proto=$proto";
}
packet_query($header,$query,"port.php?start=".max($start-$number_page,0)."&port=$port&state=$state","port.php?start=".($start+$number_page)."&port=$port&state=$state$add_proto",$state);
?>
			</div> <!-- textbody -->
		</div> <!-- datas -->
	<div class="footer">
<?php
require("include/footer.inc");
echo "</div>";
if ($footer_file){
	require($footer_file);
	}
?>
</body>
</html>
