ALTER TABLE ulog ADD KEY user_id (user_id);
