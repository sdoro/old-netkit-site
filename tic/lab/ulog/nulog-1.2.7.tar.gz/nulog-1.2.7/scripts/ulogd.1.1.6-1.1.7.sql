DROP TABLE IF EXISTS users;
--
-- Table structure for table 'usersstats'
--

CREATE TABLE usersstats (
  user_id smallint(5) unsigned default NULL,
  username varchar(30) default NULL,
  bad_conns int(10) unsigned not NULL default '0',
  good_conns int(10) unsigned not NULL default '0',
  first_time int(10) unsigned default NULL,
  last_time int(10) unsigned default NULL,
  PRIMARY KEY  (user_id),
  KEY username (username)
) TYPE=MyISAM;



--
-- Table structure for table 'users'
--

CREATE TABLE users (
  ip_saddr int(10) unsigned NOT NULL,
  socket int(10) unsigned NOT NULL,
  user_id int(10) unsigned default NULL,
  username varchar(30) default NULL,
  start_time DATETIME default NULL,
  end_time DATETIME default NULL,
  os_sysname varchar(40) default NULL,
  os_release varchar(40) default NULL,
  os_version varchar(100) default NULL,
  KEY `socket` (socket),
  KEY `ip_saddr` (ip_saddr),
  KEY `username` (username)
) TYPE=MyISAM;



