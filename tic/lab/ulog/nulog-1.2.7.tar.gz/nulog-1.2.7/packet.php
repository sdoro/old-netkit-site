<?php
#
# Copyright(C) 2003-2006 INL
# Written by Eric Leblond <regit@inl.fr>
#            Vincent Deffontaines <gryzor@inl.fr>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, version 2 of the License.
#
#  This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
$show_state_menu="no";
require("include/header.inc");


$id=$_GET['id'];
$id=check_start($id);
if ( isset($id)) {
?>
<div id="leftmenu">
<?php include("include/leftmenu.inc"); ?>
</div> <!-- leftmenu -->

		<div id="datas">
			<div id="textbody">
<?php

$state=$_GET['state'];
if ($conntrack_enabled =='yes')
  $query="(select * from $table_ulog where id=$id) UNION (select * from $table_conntrack where id=$id)";
else
  $query="select * from $table_ulog where id=$id";
$sql_time=getmicrotime();
$result=mysql_query($query);
$sql_time=getmicrotime()-$sql_time;

 $ligne = mysql_fetch_row($result);
echo "<div class=mainarray><h2>$details_for_packet_message $id</h2>";
 if ($nufw_enabled)
 {
  if (!$ligne[46]=="")
  {
  echo "<h3><img alt=\"user\" src=\"images/user.gif\"> $user_information_message</h3>";
    echo "<table class=packet>
<thead>
    <tr class=t_sheader><td>$username_message</td><td>$userid_message</td></tr>
    </thead>";
    echo "<tr class=t_datas><td>".$ligne[46]."</td><td>".$ligne[47]."</td></tr></table>";
  }
 }
echo "<h3><img alt=\"user\" src=\"images/time.gif\"> $incoming_time_message</h3>";
 echo "<table class=packet >
<thead>
<tr class=t_sheader><td>$time_message (sec)</td><td>�sec</td></tr>
</thead>";
echo "<tr><td>".date("D M j G:i:s",$ligne[2])."</td><td>".$ligne[3] ."
</tr></table></td></tr>";

 echo "<h3><img alt=\"user\" src=\"images/route.gif\"> $routing_information_message</h3>";
 if (strlen($ligne[1]) != 0) {
 echo "<table class=packet>
<thead>
<tr class=t_sheader><td>$raw_dst_mac_message</td><td>$raw_src_mac_message</td><td>$raw_proto_mac_message</td></tr>
</thead>";
 echo "<tr class=t_datas>".display_raw_mac_info($ligne[1])."</table></td></tr>";
 }

echo "<table class=packet>
<thead><tr class=t_sheader><td>$in_interface_message</td><td>$out_interface_message</td><td>$log_prefix_message</td><td>$mark_message</td></tr></thead>
<tr class=t_datas>
<td>".$ligne[6]."</td><td>".$ligne[7]."</td><td>".$ligne[4]."</td><td>".$ligne[5]."</td>
</tr>
</table>";

 echo "<h3><img alt=\"user\" src=\"images/headers.gif\">$ip_headers_message</h3>";
#IP header
echo "<table class=packet>
<thead>
<tr class=t_sheader><td>$src_host_message</td><td>$dest_host_message</td></tr>
</thead>
";
settype($ligne[8],"double");

settype($ligne[9],"double");
 echo "<tr class=t_datas><td><a href=host.php?host=".$ligne[8]."&state=".$state.">".long2ip($ligne[8])."</a></td><td>".long2ip($ligne[9])."</td>
</tr></table></td></tr>";
if (isset($ligne[13])){
echo "<table class=packet>
<thead>
<tr class=t_sheader><td>$tos_message</td><td>$ttl_message</td><td>$total_length_message</td><td>$header_length_message</td><td>$checksum_message</td><td>$packet_id_message</td></tr>
</thead>";
 echo "<tr class=t_datas>";
 for ($fields=11;$fields<=16;$fields++)
   echo "<td>".$ligne[$fields]."</td>";
 echo "</tr></table>";
}
 echo "</td></tr>";

#protocol specific header
 $proto=getprotobynumber($ligne[10]);
 echo "<h3><img alt=\"user\" src=\"images/proto.gif\"> $protocol_message $proto</h3>";
#UDP
 if ($ligne[10]==17){
 echo "<table class=packet>
  <thead>
<tr class=t_sheader><td>$src_port_message</td><td>$dest_port_message</td><td>UDP Len</td></tr>
</thead>";
   echo "<tr class=t_datas><td>".$ligne[30]."</td><td><a href=port.php?port=".$ligne[31]."&state=".$state.">".$ligne[31]."</a></td><td>".$ligne[32]."</td>
</tr></table></td></tr>";
 } elseif ($ligne[10]==6){
#TCP

   echo "<table class=packet>
  <thead>
<tr class=t_sheader><td>$src_port_message</td><td>$dest_port_message</td></tr>
</thead>";
   echo "<tr class=t_datas><td>".$ligne[18]."</td><td><a href=port.php?port=".$ligne[19]."&state=".$state.">".$ligne[19]."</a></td>
</tr></table></td></tr>";
if (isset($ligne[20])) {
  echo "<table class=packet>
  <thead>
<tr class=t_sheader><td>$seq_number_message</td><td>$ack_number_message</td><td>$tcp_window_message</td></tr>
</thead>";
   echo "<tr class=t_datas><td>".$ligne[20]."</td><td>".$ligne[21]."</td><td>".$ligne[22]."
</tr></table></td></tr>";
  echo "<table class=packet>
  <thead>
<tr class=t_sheader><td>URG</td><td>URGP</td><td>ACK</td><td>PSH</td><td>RST</td><td>SYN</td><td>FIN</td></tr>
</thead>";
  echo "<tr class=t_datas>";
  for ($fields=23;$fields<=29;$fields++){
    echo "<td>".$ligne[$fields]."</td>";
  }
  echo "</tr></table>";
  }
  echo "</td></tr>";

 } elseif ($ligne[10]==1){
#ICMP
      echo "<table class=packet>
<thead><tr class=t_sheader><td>$icmp_type_message </td><td>$icmp_code_message</td></tr></thead>";
   echo "<tr class=t_datas><td>".$ligne[33]."</td><td>".$ligne[34]."</td>
</tr></table></td></tr>";

 }

if ($nufw_enabled && $ligne[48])
 {
  echo "<h3><img alt=\"user\" src=\"images/info.gif\"> $other_informations_message</h3>";
  if (!$ligne[48]=="")
  {
	 echo  "<table class=packet>
	 <thead>
	 <tr class=t_sheader><td>$OS_message</td><td>$Application_message</td></tr>
	 </thead>";
    echo "<tr class=t_datas><td>".$ligne[48]."</td><td>".$ligne[49]."</td></tr>";
    echo "</table>";
  }
 }

}

echo "</table >";
echo "</td></tr>";
echo "</table>";
?>

			</div> <!-- textbody -->
		</div> <!-- datas -->
	<div class="footer">
	<?php
require("include/footer.inc");
if ($footer_file){
	require($footer_file);
	}
?>
</body>
</html>
