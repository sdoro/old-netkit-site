# phpMyAdmin MySQL-Dump
# version 2.5.1
# http://www.phpmyadmin.net/ (download page)
#
# --------------------------------------------------------

DROP TABLE IF EXISTS logs 
DROP TABLE IF EXISTS users 
DROP TABLE IF EXISTS search_cache 
DROP TABLE IF EXISTS user_access 
DROP TABLE IF EXISTS actions 
DROP TABLE IF EXISTS cemdb 
