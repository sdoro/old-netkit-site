<?php
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com

require_once 'includes/common_funcs.php';

$time_start = get_microtime();

require_once 'config/config.php';

//------------------------------------------------------------------------
// Determine what page is being requested
//------------------------------------------------------------------------
$pageId = get_input('pageId');
if(!validate_input($pageId, 'pageId') || !$pageId) {
	$pageId = "searchform";
}


//------------------------------------------------------------------------
// Connect to database. If connection fails then set the pageId for the
// help page.
//------------------------------------------------------------------------
$dbProblem = FALSE;
if(!$dbLink = db_connect_syslog(DBUSER, DBUSERPW)) {
	$pageId = "help";
	$dbProblem = TRUE;
}


//------------------------------------------------------------------------
// If authentication is enabled and a non-public page is being requested
// then make sure that the user's session is valid.
//------------------------------------------------------------------------
$sessionVerified = FALSE;
if(defined('REQUIRE_AUTH') && REQUIRE_AUTH == TRUE) {
	$username = get_input('username');
	$sessionId = get_input('sessionId');

	// Validate the format of the username and sessionId
	if((!validate_input($username, 'username') && $username)
		|| (!validate_input($sessionId, 'sessionId') && $sessionId)) {
		require_once 'includes/html_header.php';
		echo "The format of your username or sessionId is invalid. Please clear out your cookies and try again!";
		require_once 'includes/html_footer.php';
		exit;
	}

	// Public pages are:
	// login, about and help.
	if(strcasecmp($pageId, "about") != 0 && strcasecmp($pageId, "login") != 0 && strcasecmp($pageId, "help") != 0 || ($username && $sessionId)) {

		if(!$sessionVerified = verify_session($username, $sessionId, $dbLink)) {
			$pageId = "login";
		}
	}
}


//------------------------------------------------------------------------
// Load page
//------------------------------------------------------------------------
if(strcasecmp($pageId, "searchform") == 0) {
	$addTitle = "SEARCH";
	require 'includes/search.php';
}
elseif(strcasecmp($pageId, "login") == 0) {
	$addTitle = "LOGIN";
	require 'includes/login.php';
}
elseif(strcasecmp($pageId, "about") == 0) {
	$addTitle = "ABOUT";
	require 'includes/about.php';
}
elseif(strcasecmp($pageId, "help") == 0) {
	$addTitle = "HELP";
	require 'includes/help.php';
}
elseif(strcasecmp($pageId, "config") == 0) {
	$addTitle = "CONFIG";
	require 'includes/configure.php';
}
elseif(strcasecmp($pageId, "tail") == 0) {
	$addTitle = "TAIL RESULTS";
	require 'includes/tailresult.php';
}
elseif(strcasecmp($pageId, "search") == 0) {
	$addTitle = "REGULAR RESULTS";
	require 'includes/regularresult.php';
}
else {
	$addTitle = "SEARCH";
	require 'includes/search.php';
}


require_once 'includes/html_footer.php';
?>
