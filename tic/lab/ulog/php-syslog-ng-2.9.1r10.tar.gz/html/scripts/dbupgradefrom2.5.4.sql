# Run it like this:
# shell> mysql -uroot -p < dbupgradefrom2.5.4.sql
#

USE syslog;

CREATE TABLE search_cache (
tablename varchar(32) DEFAULT NULL,
type ENUM('HOST','FACILITY'),
value varchar(32) DEFAULT NULL,
updatetime datetime DEFAULT NULL,
INDEX type_name (type, tablename)
) TYPE=MyISAM;

CREATE TABLE user_access (
username varchar(32) DEFAULT NULL,
actionname varchar(32) DEFAULT NULL,
access ENUM('TRUE','FALSE'),
INDEX user_action (username, actionname)
) TYPE=MyISAM;

CREATE TABLE actions (
actionname varchar(32) NOT NULL,
actiondescr varchar(64) DEFAULT NULL,
defaultaccess ENUM('TRUE','FALSE'),
PRIMARY KEY (actionname)
) TYPE=MyISAM;


GRANT ALL ON syslog.search_cache TO sysloguser@localhost;
GRANT SELECT ON syslog.user_access TO sysloguser@localhost;
GRANT ALL ON syslog.user_access TO syslogadmin@localhost;
GRANT SELECT ON syslog.actions TO sysloguser@localhost;
GRANT ALL ON syslog.actions TO syslogadmin@localhost;
COMMIT;
FLUSH PRIVILEGES;

INSERT INTO actions (actionname, actiondescr, defaultaccess) VALUES ('add_user', 'Add users', 'TRUE');
INSERT INTO actions (actionname, actiondescr, defaultaccess) VALUES ('edit_user', 'Edit users (delete and change password)', 'TRUE');
INSERT INTO actions (actionname, actiondescr, defaultaccess) VALUES ('reload_cache', 'Reload search cache', 'TRUE');
INSERT INTO actions (actionname, actiondescr, defaultaccess) VALUES ('edit_acl', 'Edit access control settings', 'TRUE');
