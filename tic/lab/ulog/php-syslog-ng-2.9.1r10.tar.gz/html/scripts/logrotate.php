#!/usr/bin/php
<?php
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com
echo "\nStarting logrotate\n";
echo date("Y-m-d H:i:s");
$APP_ROOT = '/var/www/phpsyslogng';

include_once "$APP_ROOT/includes/common_funcs.php";
include_once "$APP_ROOT/config/config.php";

$dbLink = db_connect_syslog(DBADMIN, DBADMINPW);

// Drop temp table if it exists
$query = "DROP TABLE IF EXISTS temp".DEFAULTLOGTABLE;
perform_query($query, $dbLink);

// Create new table
$query = "SHOW CREATE TABLE ".DEFAULTLOGTABLE;

$result = perform_query($query, $dbLink);
$row = mysql_fetch_array($result);
$createQuery = $row[1];
$search = "CREATE TABLE `".DEFAULTLOGTABLE."`";
$replace = "CREATE TABLE `temp".DEFAULTLOGTABLE."`";
$createQuery = str_replace($search, $replace, $createQuery);
perform_query($createQuery, $dbLink);

$today = date("Ymd");

// Drop the merge table
if(defined('MERGELOGTABLE') && MERGELOGTABLE) {
	$query = "FLUSH TABLES";
	perform_query($query, $dbLink);

	$query = "DROP TABLE IF EXISTS ".MERGELOGTABLE;
	perform_query($query, $dbLink);
}

// Rename the two tables
$query = "RENAME TABLE ".DBNAME.".".DEFAULTLOGTABLE." TO ".DBNAME.".".DEFAULTLOGTABLE.$today.", "
.DBNAME.".temp".DEFAULTLOGTABLE." TO ".DBNAME.".".DEFAULTLOGTABLE;
perform_query($query, $dbLink);

echo "\nLog rotate ended successfully.\n";
echo "Now optimizing the old logs.\n";
$query = "OPTIMIZE TABLE ".DBNAME.".".DEFAULTLOGTABLE.$today;
perform_query($query, $dbLink);

// Re-create the merge table
if(defined('MERGELOGTABLE') || defined('LOGROTATERETENTION')) {
	echo "Getting list of log tables.\n";
	$logTableArray = get_logtables($dbLink);
}

if(defined('LOGROTATERETENTION') && LOGROTATERETENTION) {
	echo "Searching for tables to drop.\n";
	foreach($logTableArray as $value) {
		if(preg_match("([0-9]{8}$)", $value)) {
			// determine is datestamp is old enough
			$tableDate = strrev(substr(strrev($value), 0, 8));

			$cutoffDate = date("Ymd", mktime(0, 0, 0, date("m"), date("d")-LOGROTATERETENTION, date("Y")));

			if($cutoffDate > $tableDate) {
				echo "Dropping ".$value."!\n";
				$query = "DROP TABLE ".$value;
				perform_query($query, $dbLink);
			}
		}
	}
}

if(defined('MERGELOGTABLE') && MERGELOGTABLE) {
	echo "Creating merge table.\n";
	$query = "SHOW CREATE TABLE ".DEFAULTLOGTABLE;

	$result = perform_query($query, $dbLink);
	$row = mysql_fetch_array($result);
	$createQuery = $row[1];

	$oldStr = "CREATE TABLE `".DEFAULTLOGTABLE."`";
	$newStr = "CREATE TABLE `".MERGELOGTABLE."`";
	$createQuery = str_replace($oldStr, $newStr, $createQuery);

	$oldStr = "ENGINE=MyISAM";
	$newStr = "ENGINE=MRG_MyISAM";
	$createQuery = str_replace($oldStr, $newStr, $createQuery);
	$oldStr = "TYPE=MyISAM";
	$newStr = "ENGINE=MRG_MyISAM";
	$createQuery = str_replace($oldStr, $newStr, $createQuery);


	$createQuery = str_replace('PRIMARY KEY', 'INDEX', $createQuery);


	$unionStr = " UNION=(";
	foreach($logTableArray as $value) {
		$unionStr = $unionStr.$value.", ";
	}
	$unionStr = rtrim($unionStr, ", ");
	$unionStr = $unionStr.")";

	$createQuery = $createQuery.$unionStr;

	$query = "FLUSH TABLES";
	perform_query($createQuery, $dbLink);
}
echo "\n".date("Y-m-d H:i:s")."\n";
echo "All done!\n";
?>
