#!/usr/bin/perl -w

use strict;
use XML::Simple qw( :strict );
use DBI;
use Data::Dumper;
use POSIX qw(strftime);

my $ngconfig = "../../config/config.php";
open( CONFIG, $ngconfig ) or die "Can't open $ngconfig : $!"; 
my @config = <CONFIG>; 
close( CONFIG );

my($table,$dbadmin,$dbpw,$dbname,$dbhost,$dbport,$DEBUG);
foreach my $var (@config) {
	next unless $var =~ /^define/; # read only def's
	$table = $1 if ($var =~ /'CISCO_ERROR_TABLE', '(\w+)'/);
	$dbadmin = $1 if ($var =~ /'DBADMIN', '(\w+)'/);
	$dbpw = $1 if ($var =~ /'DBADMINPW', '(\w+)'/);
	$dbname = $1 if ($var =~ /'DBNAME', '(\w+)'/);
	$dbhost = $1 if ($var =~ /'DBHOST', '(\w+)'/);
	$dbport = $1 if ($var =~ /'DBPORT', '(\w+)'/);
	$DEBUG = $1 if ($var =~ /'DEBUG', '(\w+)'/);
}
if ( ! $table ) {
	print "Error: Unable to read config variables from $ngconfig\n";
	exit;
}
if ($DEBUG > 0) { 
	print "Table: $table\n";
	print "Adminuser: $dbadmin\n";
	print "PW: $dbpw\n";
	print "DB: $dbname\n";
	print "DB Host: $dbhost\n";
	print "DB Port: $dbport\n";
#exit;
}

my $xml_file = 'emd.xml';
my $xml_ref = new XML::Simple;
my $data = $xml_ref->XMLin("$xml_file", ForceArray => 1,  KeyAttr => []);
my $datetime = strftime "%Y-%m-%d %H:%M:%S", gmtime;

print Dumper($data) if ($DEBUG); 

my $dbh = DBI->connect('dbi:mysql:'.$dbname,$dbadmin,$dbpw)
       or die("Couldn't connect to mySQL ", $dbname ," : $DBI::errstr");

my $cemdb_query_sql = "SELECT count(*) FROM cemdb WHERE name=?";
my $sth_query = $dbh->prepare($cemdb_query_sql);

my $cemdb_update_sql = "UPDATE cemdb SET message=?, explanation=?, action=?, datetime=? WHERE name=?";
my $sth_update = $dbh->prepare($cemdb_update_sql);

my $cemdb_ins_sql = "INSERT INTO cemdb (name, message, explanation, action, datetime) VALUES (?,?,?,?,?)";
my $sth = $dbh->prepare($cemdb_ins_sql);

foreach ( @{ $data->{error} } ) {
	my($explanation,$action,$message, $name);

		$name = $_->{code};
	if ($name) {
		print "$_->{code}\n" if ($DEBUG);

		$message = $_->{message};
		print "$_->{message}\n" if ($DEBUG);

		if ((ref $_->{explanation}) eq "ARRAY") {
			foreach my $line ( @{ $_->{explanation} } ) {
				$explanation .= $line;
				print "$line\n" if ($DEBUG);
			}
		} else {
			$explanation = $_->{explanation};
			print "$_->{explanation}\n" if ($DEBUG);
		}

		if ((ref $_->{action}) eq "ARRAY") {
			foreach my $line ( @{ $_->{action} } ) {
				$action .= $line;
				print "$line\n" if ($DEBUG);
			}
		} else {
			$action = $_->{action};
			print "$_->{action}\n" if ($DEBUG);
		}

		$sth_query->execute($name) or die("$DBI::errstr");
		my ( $count ) = $sth_query->fetchrow_array(); 
		if( $count > 0 ) {
			print "Updating existing record for $name\n";
			#existing item found, use update
			$sth_update->execute($message, $explanation, $action, $datetime, $name) or die("$DBI::errstr");
		}
		else {
			print "Inserting new record for $name\n";
			#no items found, insert
			$sth->execute($name, $message, $explanation, $action, $datetime) or die("$DBI::errstr");
		}
	} else {
		print "\$name Variable is missing, skipping record\n"
	}

}

