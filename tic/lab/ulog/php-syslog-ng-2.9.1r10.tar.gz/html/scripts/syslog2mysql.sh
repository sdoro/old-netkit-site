#!/bin/bash

if [ ! -e /var/log/mysql.pipe ]
then
	mkfifo /var/log/mysql.pipe
fi
while [ -e /var/log/mysql.pipe ]
do
	mysql -u syslogfeeder --password=PW_HERE syslog < /var/log/mysql.pipe >/dev/null
done
