<?php
// Copyright (C) 2001-2004 by Michael Earls, michael@michaelearls.com
// Copyright (C) 2004-2005 Jason Taylor, j@jtaylor.ca
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com

require_once 'includes/html_header.php';

//========================================================================
// BEGIN: GET THE INPUT VARIABLES
//========================================================================
$host = get_input('host');
$host2 = get_input('host2');
$excludeHost = get_input('excludeHost');
$facility = get_input('facility');
$excludeFacility = get_input('excludeFacility');
$priority = get_input('priority');
$excludePriority = get_input('excludePriority');
$limit = get_input('limit');
$table = get_input('table');

// Set an arbitrary number of msg# and ExcludeMsg# vars
$msgvarnum=1;
$msgvarname="msg".$msgvarnum;
$excmsgvarname="ExcludeMsg".$msgvarnum;

while(get_input($msgvarname)) {
	${$msgvarname} = get_input($msgvarname);
	${$excmsgvarname} = get_input($excmsgvarname);

	$msgvarnum++;
	$msgvarname="msg".$msgvarnum;
	$excmsgvarname="ExcludeMsg".$msgvarnum;
}
//========================================================================
// END: GET THE INPUT VARIABLES
//========================================================================

//========================================================================
// BEGIN: INPUT VALIDATION
//========================================================================
$inputValError = array();

if($excludeHost && !validate_input($excludeHost, 'excludeX')) {
	array_push($inputValError, "excludeHost");
}
if($host && !validate_input($host, 'host')) {
	array_push($inputValError, "host1");
}
if($host2 && !validate_input($host2, 'host')) {
	array_push($inputValError, "host2");
}
if($excludeFacility && !validate_input($excludeFacility, 'excludeX')) {
	array_push($inputValError, "excludeFacility");
}
if($facility && !validate_input($facility, 'facility')) {
	array_push($inputValError, "facility");
}
if($excludePriority && !validate_input($excludePriority, 'excludeX')) {
	array_push($inputValError, "excludePriority");
}
if($priority && !validate_input($priority, 'priority')) {
	array_push($inputValError, "priority");
}
if($limit && !validate_input($limit, 'limit')) {
	array_push($inputValError, "limit");
}
if($table && !validate_input($table, 'table')) {
	array_push($inputValError, "table");
}

if($inputValError) {
	require_once 'includes/html_header.php';
	echo "Input validation error! The following fields had the wrong format:<p>";
	foreach($inputValError as $value) {
		echo $value."<br>";
	}
	require_once 'includes/html_footer.php';
	exit;
}
//========================================================================
// END: INPUT VALIDATION
//========================================================================

//========================================================================
// BEGIN: BUILD AND EXECUTE SQL STATEMENT
// AND BUILD PARAMETER LIST TO SAVE RESULT
//========================================================================
//------------------------------------------------------------------------
// Create WHERE statement and GET parameter list
//------------------------------------------------------------------------
$where = "";
$ParamsGET="&";

if($limit) {
	$ParamsGET=$ParamsGET."limit=".$limit."&";
}

if($pageId) {
	$ParamsGET=$ParamsGET."pageId=".$pageId."&";
}

if($host2) {
	if ($where!="") {
		$where=$where." and ";
	}
	if($excludeHost==1) {
		$where = $where." host not like '%".$host2."%' ";
	}
	else {
		$where = $where." host like '%".$host2."%' ";
	}
	$ParamsGET=$ParamsGET."host2=".$host2."&excludeHost=".$excludeHost."&";
}

if($host) {
	$hostGET=implode("&host[]=",$host);
	$hostSQL=implode("','",$host);
	if($where!="") {
		$where = $where." and ";
	}
	if($excludeHost==1) {
		$where = $where." host not in ('".$hostSQL."') ";
	}
	else {
		$where = $where." host in ('".$hostSQL."') ";
	}
	$ParamsGET=$ParamsGET."host[]=".$hostGET."&excludeHost=".$excludeHost."&";
}

if($facility) {
	$facilityGET=implode("&facility[]=",$facility);
	$facilitySQL=implode("','",$facility);
	if($where!="") {
		$where = $where." and ";
	}
	if($excludeFacility==1) {
		$where = $where." facility not in ('".$facilitySQL."') ";
	}
	else {
		$where = $where." facility in ('".$facilitySQL."') ";
	}
	$ParamsGET=$ParamsGET."facility[]=".$facilityGET."&excludeFacility=".$excludeFacility."&";
}

if($priority) {
	$priorityGET=implode("&priority[]=",$priority);
	$prioritySQL=implode("','",$priority);
	if($where!="") {
		$where = $where." and ";
	}
	if($excludePriority==1) {
		$where = $where." priority not in ('".$prioritySQL."') ";
	}
	else {
		$where = $where." priority in ('".$prioritySQL."') ";
	}
	$ParamsGET=$ParamsGET."priority[]=".$priorityGET."&excludePriority=".$excludePriority."&";
} 

$msgvarnum=1;
$msgvarname="msg".$msgvarnum;
$excmsgvarname="ExcludeMsg".$msgvarnum;

while(${$msgvarname}) {
	if($where !="") {
		$where = $where." and ";
	}
	if(${$excmsgvarname} == "on") {
		$where = $where." msg not like '%".${$msgvarname}."%' ";
		$ParamsGET=$ParamsGET.$excmsgvarname."=".${$excmsgvarname}."&";
	}
	else {
		$where = $where." msg like '%".${$msgvarname}."%' ";
	}
	$ParamsGET=$ParamsGET.$msgvarname."=".${$msgvarname}."&";
	$msgvarnum++;
	$msgvarname="msg".$msgvarnum;
	$excmsgvarname="ExcludeMsg".$msgvarnum;
}

//------------------------------------------------------------------------
// Create the GET string without host variables
//------------------------------------------------------------------------
$pieces = explode("&", $ParamsGET);
$hostParamsGET = "";
foreach($pieces as $value) {
	if(!strstr($value, "host[]") && !strstr($value, 'excludeHost') && !strstr($value, 'offset') && $value) {
		$hostParamsGET = $hostParamsGET.$value."&";
	}
}

//------------------------------------------------------------------------
// Create the complete SQL statement
//------------------------------------------------------------------------
if($table) {
	$srcTable = $table;
}
else {
	$srcTable = DEFAULTLOGTABLE;
}

$query = "SELECT * FROM ".$srcTable." ";

if($where !="") {
	$query = $query."WHERE ".$where." ORDER BY seq DESC LIMIT ".$limit;
}
else {
	$query = $query."ORDER BY seq DESC LIMIT ".$limit;
}

//------------------------------------------------------------------------
// Execute the query
//------------------------------------------------------------------------
$results = perform_query($query, $dbLink);

//========================================================================
// END: BUILD AND EXECUTE SQL STATEMENT
// AND BUILD PARAMETER LIST TO SAVE RESULT
//========================================================================


//========================================================================
// BEGIN: BUILDING THE HTML PAGE
//========================================================================
// Print result sub-header
require_once 'includes/html_result_subheader.php';

//------------------------------------------------------------------------
// Refresh time = 3 times exe time to this point + 15 seconds
//------------------------------------------------------------------------
$curExeTime = get_microtime() - $time_start;
$refreshTime = round(3*$curExeTime) + 15;
echo "<META HTTP-EQUIV=REFRESH CONTENT=".$refreshTime.">";

?>
<table>
<tr>
<td class="resultsheader">HOST</td>
<td class="resultsheader">FACILITY</td>
<td class="resultsheader">TIME</td>
<td class="resultsheader">MESSAGE</td>
</tr>
<?php
//------------------------------------------------------------------------
// Output the table with the results
// Use an alternating background and color code the priority column
//------------------------------------------------------------------------
$color = "lighter";

while($row = fetch_array($results)) {
	if($color == "darker") {
		$color = "lighter";
	}
	else {
		$color = "darker";
	}
	echo "<tr class=\"$color\">";
	echo "<td><a href=\"".$_SERVER["PHP_SELF"]."?host[]=".$row['host']."&".$hostParamsGET."\">";
	echo $row['host']."</a></td>";

	if($row['priority'] == "debug") {
		echo "<td class=\"sev0\">".$row['facility']."</td>";
	}
	elseif($row['priority'] == "info") {
		echo "<td class=\"sev1\">".$row['facility']."</td>";
	}
	elseif($row['priority'] == "notice") {
		echo "<td class=\"sev2\">".$row['facility']."</td>";
	}
	elseif($row['priority'] == "warning") {
		echo "<td class=\"sev3\">".$row['facility']."</td>";
	}
	elseif ($row['priority'] == "err") {
		echo "<td class=\"sev4\">".$row['facility']."</td>";
	}
	elseif ($row['priority'] == "crit") {
		echo "<td class=\"sev5\">".$row['facility']."</td>";
	}
	elseif ($row['priority'] == "alert") {
		echo "<td class=\"sev6\">".$row['facility']."</td>";
	}
	elseif ($row['priority'] == "emerg") {
		echo "<td class=\"sev7\">".$row['facility']."</td>";
	}

	// Extract just the time from the timestamp
	$pieces = explode(" ", $row['datetime']);
	echo "<td>$pieces[1]</td>";
	/* Begin CEMDB Mod */
	if ( CEMDB == "ON" ) {
		// Parse $row for "%error:"
		$name = printbetween("%",":",$row['msg']);
		$name = $name[0][0];
		$name = str_replace(":", "", $name);
		if (strstr($name, "%")) {
			$data = cemdb($name);
			// echo "Name: $name<br>";
			// die (print_r($data));
			// die ("Debug CEMDB Function: " . $data[1]);
			$info ="<b>Name:</b>" .$name ;
#       $info .= "<br><b>Message:</b> " . $data[0];
			$info .= "<br><b>Explanation:</b> " . $data[1];
			$info .= "<br><b>Action:</b> " . $data[2];
			$info .= "<br><b>Record last updated on:</b> " . $data[3];
			$info = str_replace("\n","",$info);
		} else {
			$info = "No Data available for this message.";
		}
		//  die("Debug info: \n<br>" . $info);
		echo "</td><td>";
		?>
			<th  align="left"><A href="#" onmouseover="overlib('<TABLE border=1 cellspacing=0 cellpadding=0 width=100%><TR><TD class=tooltip><?=$info?></TD></TR></TABLE>');" onmouseout=nd(); name ="spacer" ><? echo htmlspecialchars($row['msg']);?></A></th>
			<?
	} else {
		echo    "<td>".htmlspecialchars($row['msg'])."</td>";
	}
	/* END CEMDB Mod */
	echo    "</tr>\n";
}
echo "</table>\n";

//========================================================================
// END: BUILDING THE HTML PAGE
//========================================================================
?>
