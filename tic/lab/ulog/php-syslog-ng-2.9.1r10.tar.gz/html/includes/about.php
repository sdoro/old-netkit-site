<?php
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com
require_once 'includes/html_header.php';
?>
<table class="pagecontent">
<tr><td><span class="longtext">
<h3 class="title">Overview</h3>
php-syslog-ng is a front-end for viewing syslog-ng messages logged to MySQL in real-time. It lets you quickly and easily manage logs from many hosts. It features customized searches based on host, facility, priority, datetime and the content of the log messages. It also has a tail mode, also with customized filters, that enables you to monitor your systmes in near real-time. The latest version of php-syslog-ng requires MySQL 4.0 or later for full functionality. Older versions of MySQL are still supported but the functionality will be somewhat limited. Any recent version of syslog-ng, Apache and php should work.<hr>

<h3 class="title">License</h3>
php-syslog-ng is licensed under the terms of the <a href="http://www.gnu.org/copyleft/gpl.html">GNU Public License (GPL)</a> Version 2 as published by the Free Software Foundation. This gives you legal permission to copy, distribute and/or modify php-syslog-ng under certain conditions. Read the 'LICENSE' file in the php-syslog-ng distribution or read the online version of the license for more details.<br />
php-syslog-ng is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE WARRANTY OF DESIGN, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE.<hr>

<h3 class="title">History</h3>
2002-07-31 - Michael Earls releases version 0.1 of php-syslog-ng. More information can be found at <a href="http://www.vermeer.org/projects/php-syslog-ng">http://www.vermeer.org/projects/php-syslog-ng</a> and <a href="http://sourceforge.net/projects/php-syslog-ng/">http://sourceforge.net/projects/php-syslog-ng/</a>.

<p>
Michael Earls steadily improved on php-syslog-ng until his last release (2.5.1) in the summer of 2004.

<p>
After that I think the main contributor has been Jason Taylor (<a href="http://deathstar.com/PhpSyslogNG">http://deathstar.com/PhpSyslogNG</a>). The development since Michael Earls' last release can be followed on the mailing list on sourceforge (<a href="http://sourceforge.net/mailarchive/forum.php?forum=php-syslog-ng-support">http://sourceforge.net/mailarchive/forum.php?forum=php-syslog-ng-support</a>).

<p>
php-syslog-ng May 2005 (2.5.3)<br />
I had been looking at this project and others like it for a while and I finally needed to implement something like this at work. That gave me the excuse to finally take a good look at the code for php-syslog-ng to see if it matched my requirements. I downloaded Jason Taylor's 20050422 release and started to dig in. It quickly became apparent that the code could use some clean-up work before I would start to add any new features. The clean-up was a little more work than I had first hoped but after a couple of days I had some code that I thought was work-able. I then started adding/fixing some of the things I immediately wanted done. The most significant change is that MySQL 4.0 is now required if you want full functionality (earlier versions are still supported with limited functionality). I don't know how well my approach to calculating the total number of results works in a very busy environment but I believe that it will be OK. This is something I will keep an eye on as I implement this system where I work.<br>

<p>
php-syslog-ng May 2005 (2.5.4)<br />
User authentication, support for multiple tables with log data and improved log rotation capabilities ... those are the main changes in this version. I also fixed a couple of bugs, added input validation for must user supplied values and further cleaned up and commented the code.<br />
Enjoy!

<p>
php-syslog-ng June 2005 (2.6)<br />
Three new features/changes:<br />
1) Most of the work has been done towards supporting other databases. The base functionality can be ported to any database by just editing a few database related functions in common_funcs.php.<br />
2) A cache function has been implemented to remove/minimize the delay when loading the search page.<br />
3) Basic access controls have been implemented. They currently only affect the configure page but I plan on expanding it to also allow for restrictions on what searches a user can make (what hosts, timeframe etc).<br />
In addition to the new stuff I also fixed a few minor bugs.

<p>
php-syslog-ng June 2005 (2.7)<br />
This release only has bug fixes. See the changelog for the list of changes.<br />
If you are using the merge table then you need to use MySQL 4.0.18 or later.

<p>
php-syslog-ng July 2005 (2.8)<br />
A quick bug fix to remedy a problem in logrotate.php.

<p>
This latest version of php-syslog-ng is available at <a href="http://www.phpwizardry.com/php-syslog-ng.php">http://www.phpwizardry.com/php-syslog-ng.php</a>.<hr>

<h3 class="title">Changes in this release (2.8)</h3>
<ul>
<li>Fixed a bug in logrotate.php (<a href="http://sourceforge.net/mailarchive/forum.php?thread_id=7674217&forum_id=34099">http://sourceforge.net/mailarchive/forum.php?thread_id=7674217&forum_id=34099</a>).</li>
</ul>
<hr>

<h3 class="title">TODO list</h3>
<ul>
<li>Option to compress tables with old log data.</li>
<li>Create an install script (large parts a copy of the install instructions at <a href="http://gentoo-wiki.com/HOWTO_setup_PHP-Syslog-NG">http://gentoo-wiki.com/HOWTO_setup_PHP-Syslog-NG</a> ... just all rolled into a neat little bundle).</li>
<li>Saved queries.</li>
<li>Expand the use of access controls to allow for limiting the log entries users can view.</li>
<li>Implement a query builder to improve search based on the message column (and/or and an arbitrary number of strings).</li>
<li>Support for postgres.</li>
<li>Notification.</li>
</ul>
</span></td></tr></table>
