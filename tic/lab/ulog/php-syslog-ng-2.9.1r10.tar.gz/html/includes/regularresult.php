<?php
// Copyright (C) 2001-2004 by Michael Earls, michael@michaelearls.com
// Copyright (C) 2004-2005 Jason Taylor, j@jtaylor.ca
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com
// Copyright (C) 2006 Clayton Dukes, cdukes@cdukes.com

require_once 'includes/html_header.php';

//========================================================================
// BEGIN: GET THE INPUT VARIABLES
//========================================================================
$host = get_input('host');
$host2 = get_input('host2');
$excludeHost = get_input('excludeHost');
$facility = get_input('facility');
$excludeFacility = get_input('excludeFacility');
$priority = get_input('priority');
$excludePriority = get_input('excludePriority');
$date = get_input('datePickerField');
$date2 = get_input('datePickerFieldR');
$time = get_input('time');
$time2 = get_input('time2');
$limit = get_input('limit');
$orderby = get_input('orderby');
$order = get_input('order');
$offset = get_input('offset');
if(!$offset) {
	$offset = 0;
}
$collapse = get_input('collapse');
$table = get_input('table');

// Set an arbitrary number of msg# and ExcludeMsg# vars
$msgvarnum=1;
$msgvarname="msg".$msgvarnum;
$excmsgvarname="ExcludeMsg".$msgvarnum;

while(get_input($msgvarname)) {
	${$msgvarname} = get_input($msgvarname);
	${$excmsgvarname} = get_input($excmsgvarname);

	$msgvarnum++;
	$msgvarname="msg".$msgvarnum;
	$excmsgvarname="ExcludeMsg".$msgvarnum;
}
//========================================================================
// END: GET THE INPUT VARIABLES
//========================================================================


//========================================================================
// BEGIN: INPUT VALIDATION
//========================================================================
$inputValError = array();

if($excludeHost && !validate_input($excludeHost, 'excludeX')) {
	array_push($inputValError, "excludeHost");
}
if($host && !validate_input($host, 'host')) {
	array_push($inputValError, "host1");
}
if($host2 && !validate_input($host2, 'host')) {
	array_push($inputValError, "host2");
}
if($excludeFacility && !validate_input($excludeFacility, 'excludeX')) {
	array_push($inputValError, "excludeFacility");
}
if($facility && !validate_input($facility, 'facility')) {
	array_push($inputValError, "facility");
}
if($excludePriority && !validate_input($excludePriority, 'excludeX')) {
	array_push($inputValError, "excludePriority");
}
if($priority && !validate_input($priority, 'priority')) {
	array_push($inputValError, "priority");
}
if($date && !validate_input($date, 'date')) {
	array_push($inputValError, "date1");
}
if($date2 && !validate_input($date2, 'date')) {
	array_push($inputValError, "date2");
}
if($time && !validate_input($time, 'time')) {
	array_push($inputValError, "time1");
}
if($time2 && !validate_input($time2, 'time')) {
	array_push($inputValError, "time2");
}
if($limit && !validate_input($limit, 'limit')) {
	array_push($inputValError, "limit");
}
if($orderby && !validate_input($orderby, 'orderby')) {
	array_push($inputValError, "orderby");
}
if($order && !validate_input($order, 'order')) {
	array_push($inputValError, "order");
}
if(!validate_input($offset, 'offset')) {
	array_push($inputValError, "offset");
}
if($collapse && !validate_input($collapse, 'collapse')) {
	array_push($inputValError, "collapse");
}
if($table && !validate_input($table, 'table')) {
	array_push($inputValError, "table");
}

if($inputValError) {
	require_once 'includes/html_header.php';
	echo "Input validation error! The following fields had the wrong format:<p>";
	foreach($inputValError as $value) {
		echo $value."<br>";
	}
	require_once 'includes/html_footer.php';
	exit;
}
//========================================================================
// END: INPUT VALIDATION
//========================================================================


//========================================================================
// BEGIN: BUILD AND EXECUTE SQL STATEMENT
// AND BUILD PARAMETER LIST FOR HTML GETS
//========================================================================
//------------------------------------------------------------------------
// Create WHERE statement and GET parameter list
//------------------------------------------------------------------------
$where = "";
$ParamsGET = "&";

if($table) {
	$ParamsGET=$ParamsGET."table=".$table."&";
}

if($limit) {
	$ParamsGET=$ParamsGET."limit=".$limit."&";
}

if($orderby) {
	$ParamsGET=$ParamsGET."orderby=".$orderby."&";
}

if($order) {
	$ParamsGET=$ParamsGET."order=".$order."&";
}

if($collapse) {
	$ParamsGET=$ParamsGET."collapse=".$collapse."&";
}

if($pageId) {
	$ParamsGET=$ParamsGET."pageId=".$pageId."&";
}

if($host2) {
	if ($where!="") {
		$where=$where." and ";
	}
	if($excludeHost==1) {
		$where = $where." host not like '%".$host2."%' ";
	}
	else {
		$where = $where." host like '%".$host2."%' ";
	}
	$ParamsGET=$ParamsGET."host2=".$host2."&excludeHost=".$excludeHost."&";
}	

if($host) {
	$hostGET=implode("&host[]=",$host);
	$hostSQL=implode("','",$host);
	if($where!="") {
		$where = $where." and ";
	}
	if($excludeHost==1) {
		$where = $where." host not in ('".$hostSQL."') ";
	}
	else {
		$where = $where." host in ('".$hostSQL."') ";
	}
	$ParamsGET=$ParamsGET."host[]=".$hostGET."&excludeHost=".$excludeHost."&";	
}

if($facility) {
	$facilityGET=implode("&facility[]=",$facility);
	$facilitySQL=implode("','",$facility);
	if($where!="") {
		$where = $where." and ";
	}
	if($excludeFacility==1) {
		$where = $where." facility not in ('".$facilitySQL."') ";
	}
	else {
		$where = $where." facility in ('".$facilitySQL."') ";
	}
	$ParamsGET=$ParamsGET."facility[]=".$facilityGET."&excludeFacility=".$excludeFacility."&";
}

if($priority) {
	$priorityGET=implode("&priority[]=",$priority);
	$prioritySQL=implode("','",$priority);
	if($where!="") {
		$where = $where." and ";
	}
	if($excludePriority==1) {
		$where = $where." priority not in ('".$prioritySQL."') ";
	}
	else {
		$where = $where." priority in ('".$prioritySQL."') ";
	}
	$ParamsGET=$ParamsGET."priority[]=".$priorityGET."&excludePriority=".$excludePriority."&";
}

$datetime = "";
$datetime2 = "";

if($date) {
	$ParamsGET=$ParamsGET."date=".$date."&time=".$time."&";
	if(strcasecmp($date, 'now') == 0 || strcasecmp($date, 'today') == 0) {
		$date = date("Y-m-d");
	}
	elseif(strcasecmp($date, 'yesterday') == 0) {
		$date = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")));
	}
	if(!$time) {
		$time = "00:00:00";
	}
	elseif(strcasecmp($time, 'now') == 0) {
		$time = date("H:i:s");
	}
	$datetime = $date." ".$time ;
}
if($date2) {
	$ParamsGET=$ParamsGET."date2=".$date2."&time2=".$time2."&";
	if(strcasecmp($date2, 'now') == 0 || strcasecmp($date2, 'today') == 0) {
		$date2 = date("Y-m-d");
	}
	elseif(strcasecmp($date2, 'yesterday') == 0) {
		$date2 = date("Y-m-d", mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")));
	}
	if(!$time2) {
		$time2 = "23:59:59";
	}
	elseif(strcasecmp($time2, 'now') == 0) {
		$time2 = date("H:i:s");
	}
	$datetime2 = $date2." ".$time2 ;
}

if($datetime && $datetime2) {
	if($where != "") {
		$where = $where." and ";
	}
	$where = $where." datetime between '".$datetime."' and '".$datetime2."' ";
}
elseif($datetime) {
	if($where != "") {
		$where = $where." and ";
	}
	$where = $where." datetime > '".$datetime."' ";
}
elseif($datetime2) {
	if($where != "") {
		$where = $where." and ";
	}
	$where = $where." datetime < '".$datetime2."' ";
}

$msgvarnum=1;
$msgvarname="msg".$msgvarnum;
$excmsgvarname="ExcludeMsg".$msgvarnum;

while(${$msgvarname}) {
	if($where !="") {
		$where = $where." and ";
	}
	if(${$excmsgvarname} == "on") {
		$where = $where." msg not like '%".${$msgvarname}."%' ";
		$ParamsGET=$ParamsGET.$excmsgvarname."=".${$excmsgvarname}."&";
	}
	else {
		$where = $where." msg like '%".${$msgvarname}."%' ";
	}
	$ParamsGET=$ParamsGET.$msgvarname."=".${$msgvarname}."&";
	$msgvarnum++;
	$msgvarname="msg".$msgvarnum;
	$excmsgvarname="ExcludeMsg".$msgvarnum;
}

//------------------------------------------------------------------------
// Create the GET string without host variables
//------------------------------------------------------------------------
$pieces = explode("&", $ParamsGET);
$hostParamsGET = "";
foreach($pieces as $value) {
	if(!strstr($value, "host[]=") && !strstr($value, 'excludeHost=') && !strstr($value, 'offset=') && $value) {
		$hostParamsGET = $hostParamsGET.$value."&";
	}
}

//------------------------------------------------------------------------
// Create the complete SQL statement
// SQL_CALC_FOUND_ROWS is a MySQL 4.0 feature that allows you to get the
// total number of results if you had not used a LIMIT statement. Using
// it saves an extra query to get the total number of rows.
//------------------------------------------------------------------------
if($table) {
	$srcTable = $table;
}
else {
	$srcTable = DEFAULTLOGTABLE;
}

if(defined('COUNT_ROWS') && COUNT_ROWS == TRUE) {
	$query = "SELECT SQL_CALC_FOUND_ROWS * FROM ".$srcTable." ";
}
else {
	$query = "SELECT * FROM ".$srcTable." ";
}

if($where) {
	$query = $query."WHERE ".$where." ORDER BY ".$orderby." ".$order." LIMIT ".$offset.", ".$limit;
}
else {
	$query = $query."ORDER BY ".$orderby." ".$order." LIMIT ".$offset.", ".$limit;
}

//------------------------------------------------------------------------
// Execute the query
// The FOUND_ROWS function returns the value from the SQL_CALC_FOUND_ROWS
// count.
//------------------------------------------------------------------------
$results = perform_query($query, $dbLink);
if(defined('COUNT_ROWS') && COUNT_ROWS == TRUE) {
	$num_results_array = perform_query("SELECT FOUND_ROWS()", $dbLink);
	$num_results_array = fetch_array($num_results_array);
	$num_results = $num_results_array[0];
}
//========================================================================
// END: BUILD AND EXECUTE SQL STATEMENT
// AND BUILD PARAMETER LIST FOR HTML GETS
//========================================================================

//========================================================================
// BEGIN: PREPARE RESULT ARRAY
//========================================================================
//------------------------------------------------------------------------
// Collapse consecutive identical messages into one line
//------------------------------------------------------------------------
if($collapse == 1) {
	$n = 0;
	while($row = fetch_array($results)) {
		if($row['msg'] == $result_array[$n-1]['msg'] 
			&& $row['host'] == $result_array[$n-1]['host']) {
			$result_array[$n-1]['count'] = $result_array[$n-1]['count'] + 1;
			$n--;
		}
		else {
			$row['count'] = 1;
			$result_array[$n] = $row;
		}
		$n++;
	}
}
else {
	$n = 0;
	while($row = fetch_array($results)) {
		$row['count'] = 1;
		$result_array[$n] = $row;
		$n++;
	}
}	
//========================================================================
// END: PREPARE RESULT ARRAY
//========================================================================

//========================================================================
// BEGIN: BUILDING THE HTML PAGE
//========================================================================
// Print result sub-header
require_once 'includes/html_result_subheader.php';

// If there is a result list then print it
if (count($result_array)){

	//------------------------------------------------------------------------
	// If the query returned some results then start the table with the
	// results
	//------------------------------------------------------------------------
?>
<table width=100%>
<tr class="resultsheader">
<td>SEQ</td>
<td>HOST</td>
<td>FACILITY</td>
<td>DATE TIME</td>
<td>MESSAGE</td>
</tr>
<?php
	//------------------------------------------------------------------------
	// Output the table with the results
	// Use an alternating background and color code the priority column
	//------------------------------------------------------------------------
	$color = "lighter";
	for($i=0; $i < count($result_array); $i++) {
		$row = $result_array[$i];
		if($color == "darker") {
			$color = "lighter";
		}
		else {
			$color = "darker";
		}
		echo "<tr class=\"$color\">";
		echo "<td>".$row['seq']."</td>";

		echo "<td><a href=\"".$_SERVER["PHP_SELF"]."?host[]=".$row['host']."&".$hostParamsGET."\">";
		echo $row['host']."</a></td>";

		// 3rd column: Spit out the colour-coded FACILITY/PRIORITY fields.
		if($row['priority'] == "debug") {
			echo "<td class=\"sev0\">".$row['facility']."-".$row['priority']."</td>";
		}
		elseif($row['priority'] == "info") {
			echo "<td class=\"sev1\">".$row['facility']."-".$row['priority']."</td>";
		}
		elseif ($row['priority'] == "notice") {
			echo "<td class=\"sev2\">".$row['facility']."-".$row['priority']."</td>";
		}
		elseif ($row['priority'] == "warning") {
			echo "<td class=\"sev3\">".$row['facility']."-".$row['priority']."</td>";
		}
		elseif ($row['priority'] == "err") {
			echo "<td class=\"sev4\">".$row['facility']."-".$row['priority']."</td>";
		}
		elseif ($row['priority'] == "crit") {
			echo "<td class=\"sev5\">".$row['facility']."-".$row['priority']."</td>";
		}
		elseif ($row['priority'] == "alert") {
			echo "<td class=\"sev6\">".$row['facility']."-".$row['priority']."</td>";
		}
		elseif ($row['priority'] == "emerg") {
			echo "<td class=\"sev7\">".$row['facility']."-".$row['priority']."</td>";
		}

		echo "<td>".$row['datetime']."</td>";
		if($row['count'] > 1) {
			echo "<td><b>".$row['count']." *</b> ".htmlentities($row['msg'])."</td>";
		}
		else {
			/* Begin CEMDB Mod */
			if ( CEMDB == "ON" ) {
				// Parse $row for "%error:"
				$name = printbetween("%",":",$row['msg']);
				$name = $name[0][0];
				$name = str_replace(":", "", $name);
				if (strstr($name, "%")) {
					$data = cemdb($name);
					// echo "Name: $name<br>";
					// die (print_r($data));
					// die ("Debug CEMDB Function: " . $data[1]);
					$info ="<b>Name:</b>" .$name ;
#       $info .= "<br><b>Message:</b> " . $data[0];
					$info .= "<br><b>Explanation:</b> " . $data[1];
					$info .= "<br><b>Action:</b> " . $data[2];
					$info .= "<br><b>Record last updated on:</b> " . $data[3];
					$info = str_replace("\n","",$info);
				} else {
					$info = "No Data available for this message.";
				}
				//  die("Debug info: \n<br>" . $info);
				echo "</td><td>";
				?>
					<th  align="left"><A href="#" onmouseover="overlib('<TABLE border=1 cellspacing=0 cellpadding=0 width=100%><TR><TD class=tooltip><?=$info?></TD></TR></TABLE>');" onmouseout=nd(); name ="spacer" ><? echo htmlspecialchars($row['msg']);?></A></th>
					<?
			} else {
				echo    "<td>".htmlspecialchars($row['msg'])."</td>";
			}
			/* END CEMDB Mod */
		}
		echo "</tr>\n";
	}
	echo "</table>\n";

	//------------------------------------------------------------------------
	// Create the list with links to other results.
	// The list will show a maximum of 11 pages + first and last
	//------------------------------------------------------------------------
	echo "Result Page: ";

	if($num_results) {

		// If you are not on the first page then show the FIRST link
		if($offset>0) {
			echo "<a href=\"".$_SERVER["PHP_SELF"]."?offset=0".$ParamsGET."\"><BIG>FIRST</BIG></a> ";
		}

		// If you are not on one of the first two pages then also show the PREV link
		if($offset>$limit+1) {
			$prevoffset=$offset-$limit ;
			echo "<a href=\"".$_SERVER["PHP_SELF"]."?offset=".$prevoffset.$ParamsGET."\"><BIG>PREV</BIG></a>\n";
		}

		// Calculate the total number of pages in the query
		$totalpages=intval($num_results/$limit);
		if($num_results%$limit) {
			$totalpages++;
		}

		// Calculate the current page
		$curpage=floor($offset/$limit);

		// Figure out what the first page on the list should be
		if($curpage<5) {
			$firstpage = 0;
		}
		else {
			$firstpage = $curpage - 5;
		}
		if($curpage>$totalpages - 6) {
			$firstpage = $totalpages - 11;
		}
		if($firstpage<5) {
			$firstpage = 0;
		}
		if($totalpages < 11) {
			$listpages = $totalpages;
		}
		else {
			$listpages = 11;
		}

		// Determine what the last page on the list should be
		$lastpage = $firstpage + $listpages;
	
		// Output the list of numbered links to the 11 closest pages.
		// The current page is high-lighted and the other are created as links
		for($i=$firstpage;$i<$lastpage;$i++) {
			$pageoffset=$i*$limit;
			$pagenum = $i + 1;
			if($curpage==$i) {
				echo "<font size=+1>[$pagenum]</font>\n";
			}
			else {
				echo "<a href=\"".$_SERVER["PHP_SELF"]."?offset=".$pageoffset.$ParamsGET."\">$pagenum</a>\n";
			}
		}

		// If there's a page with a higher offset and that page is not the last
		// on the list then create a NEXT link.
		if((intval($offset/$limit)+2)<$totalpages) {
			$nextoffset=$offset+$limit;
			echo "<a href=\"".$_SERVER["PHP_SELF"]."?offset=".$nextoffset.$ParamsGET."\"><BIG>NEXT</BIG></a> \n";
		}

		// If you are not currently on the last page then create a LAST link.
		if($totalpages>1 && (intval($offset/$limit)+1)!=$totalpages) {
			$lastoffset=($totalpages-1)*$limit;
			echo "<a href=\"".$_SERVER["PHP_SELF"]."?offset=".$lastoffset.$ParamsGET."\"><BIG>LAST</BIG></a>";
		}
	}
	// This for backwards when total row count is not calculated.
	else {
		if($offset>0) {
	                echo "<a href=\"".$_SERVER["PHP_SELF"]."?offset=0".$ParamsGET."\"><BIG>FIRST</BIG></a> ";
	        }

	        // If you are not on one of the first two pages then also show the PREV link
	        if($offset>$limit+1) {
        	        $prevoffset=$offset-$limit ;
	                echo "<a href=\"".$_SERVER["PHP_SELF"]."?offset=".$prevoffset.$ParamsGET."\"><BIG>PREV</BIG></a>\n";
	        }
		$nextoffset=$offset+$limit;
		echo "<a href=\"".$_SERVER["PHP_SELF"]."?offset=".$nextoffset.$ParamsGET."\"><BIG>NEXT</BIG></a> \n";
	}
}

//------------------------------------------------------------------------
// Else just direct the user back to the form
//------------------------------------------------------------------------
else {
	echo "No results found.<br><a href=\"index.php?pageId=searchform\">BACK TO SEARCH</a>";
}

//========================================================================
// END: BUILDING THE HTML PAGE
//========================================================================
?>
