<?php
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com

//========================================================================
// BEGIN: GET THE INPUT VARIABLES
//========================================================================
$password = get_input('password');
$logout = get_input('logout');
//========================================================================
// END: GET THE INPUT VARIABLES
//========================================================================

//========================================================================
// BEGIN: HANDLE LOGOUT REQUEST
//========================================================================
if($logout) {
	// Generate a random sessionId
	$sessionId = md5(mt_rand());

	// Update sessionId and exptime in database
	if($sessionVerified) {
		$query = "UPDATE ".AUTHTABLENAME." SET sessionid='".$sessionId."', 
			exptime='0000-00-00 00:00:00' WHERE username='".$username."'";

		perform_query($query, $dbLink);
	}

	// Delete session cookie on the users machine
	if(defined('RENEW_SESSION_ON_EACH_PAGE') && RENEW_SESSION_ON_EACH_PAGE == TRUE) {
		setcookie('sessionId', FALSE);
	}
	else {
		setcookie('sessionId', FALSE, $expTime);
	}

	// If base URL is defined then redirect to default page
	if(defined('URL')) {
		header('Location: '.URL);
		echo "<META http-equiv=\"refresh\" content=\"0; url=".URL."\">";
	}

	require_once 'includes/html_header.php';
	// CDUKES - Changed click to META redirect
	//echo "<a href=\"index.php\">Success! Click here!</a>";
	g_redirect(SITEURL . "index.php",META);

        return;
}
//========================================================================
// END: HANDLE LOGOUT REQUEST
//========================================================================

//========================================================================
// BEGIN: HANDLE LOGIN REQUEST
//========================================================================
//------------------------------------------------------------------------
// If username and password were submitted and they are correct then
// set the session cookie and redirect the user to the frontpage
//------------------------------------------------------------------------
if($username && $password && verify_login($username, $password, $dbLink)) {
	// Generate random sessionId
	$sessionId = md5(mt_rand());

	// Calculate the expiration time
	$expTime = time()+SESSION_EXP_TIME;
	$expTimeDB = date('Y-m-d H:i:s', $expTime);

	// Update sessionId and exptime in database
	$query = "UPDATE ".AUTHTABLENAME." SET sessionid='".$sessionId."', 
		exptime='".$expTimeDB."' WHERE username='".$username."'";

	perform_query($query, $dbLink);

	// Set cookies
	setcookie('username', $username, time()+3600);
	if(defined('RENEW_SESSION_ON_EACH_PAGE') && RENEW_SESSION_ON_EACH_PAGE == TRUE) {
		setcookie('sessionId', $sessionId);
	}
	else {
		setcookie('sessionId', $sessionId, $expTime);
	}

	// If base URL is defined then redirect to default page
	if(defined('URL')) {
		header('Location: '.URL);
		echo "<META http-equiv=\"refresh\" content=\"0; url=".URL."\">";
	}

	require_once 'includes/html_header.php';
	// CDUKES - Changed click to META redirect
	//echo "<a href=\"index.php\">Success! Click here!</a>";
	g_redirect(SITEURL . "index.php",META);

	exit;
}
//========================================================================
// END: HANDLE LOGIN REQUEST
//========================================================================

require_once 'includes/html_header.php';

//========================================================================
// BEGIN: BUILDING THE HTML LOGIN FORM
//========================================================================
?>
<table class="pagecontent">
<tr><td>
<form action="index.php" method="POST">
<table><tr><td>
<?php
if($username && $password) {
	echo "<center>Username and password combination does not exist!</center><br />";
}
?>
	<table class="searchform">
	<tr class="lighter"><td>
		<b>LOGIN:</b>
		<table align="center" class="formentry">
		<tr><td>
		Username:
		</td><td>
		<input type="text" size=12 maxlength=32 name="username" value="<?php echo $username; ?>" >
		</td></tr><tr><td>
		Password:
		</td><td>
		<input type="password" size=12 maxlength=32 name="password">
		</td></tr></table>
	</td></tr></table>
	<table class="searchform">
	<tr><td class="darker">
	<input type="submit" name="pageId" value="Login">
	<input type="reset" value="Reset">
	</td></tr></table>
</td></tr></table>
</form>
</td></tr></table>
<?php
//========================================================================
// END: BUILDING THE HTML LOGIN FORM
//========================================================================
?>
