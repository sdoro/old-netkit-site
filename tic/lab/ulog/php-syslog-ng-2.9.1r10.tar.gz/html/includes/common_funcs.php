<?php
// Copyright (C) 2001-2004 by Michael Earls, michael@michaelearls.com
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com

//------------------------------------------------------------------------
// This function returns the current microtime.
//------------------------------------------------------------------------
function get_microtime() {
	list($usec, $sec) = explode(" ", microtime());
	return ((float)$usec + (float)$sec);
}


//------------------------------------------------------------------------
// This functions verifies a username/password combination. If the
// combination exists then the function returns TRUE. If not then it
// returns FALSE.
//------------------------------------------------------------------------
function verify_login($username, $password, $link) {
	// If the username or password is blank then return FALSE.
	if(!$username || !$password) {
		return FALSE;
	}

	// Get the md5 hash of the password and query the database.
	$pwHash = md5($password);
	$query = "SELECT * FROM ".AUTHTABLENAME." WHERE username='".$username."' AND pwhash='".$pwHash."'";
	$result = perform_query($query, $link);

	// If the query returns one result row then return TRUE.
	if(num_rows($result) == 1) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}


//------------------------------------------------------------------------
// This function verifies a username/sessionId combination. If the
// combination exists then the function returns TRUE. If not then it
// returns FALSE. If the RENEW_SESSION_ON_EACH_PAGE parameter is set then
// the functions also updates the timestamp for the session after it is
// verified.
//------------------------------------------------------------------------
function verify_session($username, $sessionId, $link) {
	// If the username or sessionId is blank then return FALSE.
	if(!$username || !$sessionId) {
		return FALSE;
	}

	// Query the database.
	$query = "SELECT * FROM ".AUTHTABLENAME." WHERE username='".$username."' 
		AND sessionid='".$sessionId."' AND exptime>now()";
	$result = perform_query($query, $link);

	// If the query returns one result row then the session is verified.
	if(num_rows($result) == 1) {
		//If RENEW_SESSION_ON_EACH_PAGE is set then update the
		// session timestamp in the database.
		if(defined('RENEW_SESSION_ON_EACH_PAGE') && RENEW_SESSION_ON_EACH_PAGE == TRUE) {
			$expTime = time()+SESSION_EXP_TIME;
			$expTimeDB = date('Y-m-d H:i:s', $expTime);
			$query = "UPDATE ".AUTHTABLENAME." SET exptime='".$expTimeDB."'
				WHERE username='".$username."'";
			perform_query($query, $link);
		}
		return TRUE;
	}
	else {
		return FALSE;
	}
}


//------------------------------------------------------------------------
// Function used to retrieve input values and if neccessary add slashes.
//------------------------------------------------------------------------
function get_input($varName) {
	$value="";
	if(isset($_COOKIE[$varName])) {
		$value = $_COOKIE[$varName];
	}
	if(isset($_GET[$varName])) {
		$value = $_GET[$varName];
	}
	if(isset($_POST[$varName])) {
		$value = $_POST[$varName];
	}

	if($value && !get_magic_quotes_gpc()) {
		if(!is_array($value)) {
			$value = addslashes($value);
		}
		else {
			foreach($value as $key => $arrValue) {
				$value[$key] = addslashes($arrValue);
			}
		}
	}

	return $value;
}


//------------------------------------------------------------------------
// Function used to validate user supplied variables.
//------------------------------------------------------------------------
function validate_input($value, $regExpName) {
	global $regExpArray;

	if(!$regExpArray[$regExpName]) {
		return FALSE;
	}

	if(is_array($value)) {
		foreach($value as $arrval) {
			if(!preg_match("$regExpArray[$regExpName]", $arrval)) {
				return FALSE;
			}
		}
		return TRUE;
	}
	elseif(preg_match("$regExpArray[$regExpName]", $value)) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}


//------------------------------------------------------------------------
// This function reloads the cache with data from $table.
//------------------------------------------------------------------------
function reload_cache($table, $link) {
	$cacheHostValues = array();
	$cacheFacilityValues = array();

	// Get new cache values from $table
	$sql = "SELECT DISTINCT host FROM ".$table;
	$result = perform_query($sql, $link);
	while($row = fetch_array($result, 'ASSOC')) {
		array_push($cacheHostValues, $row['host']);
	}

	$sql = "SELECT DISTINCT facility FROM ".$table;
	$result = perform_query($sql, $link);
	while($row = fetch_array($result, 'ASSOC')) {
		array_push($cacheFacilityValues, $row['facility']);
	}

	// Prepare INSERT statements
	$updateTime = date("Y-m-d H:i:s");
	$insertHost = "INSERT INTO ".CACHETABLENAME." (tablename, type, value, updatetime) VALUES ";
	foreach($cacheHostValues as $value) {
		$add = "('".$table."', 'HOST', '".$value."', '".$updateTime."'),";
		$insertHost .= $add;
	}
	$insertHost = rtrim($insertHost, ',');
	if (!$add) {
		die("<center><em>There appear to be no hosts in the Database yet<br>
				You can generate fake ones using scripts/dbgen.pl<br>
				</em></center>
				");
	}

	$insertFacility = "INSERT INTO ".CACHETABLENAME." (tablename, type, value, updatetime) VALUES ";
	foreach($cacheFacilityValues as $value) {
		$add = "('".$table."', 'FACILITY', '".$value."', '".$updateTime."'),";
		$insertFacility .= $add;
	}
	$insertFacility = rtrim($insertFacility, ',');

	// Insert new cache values for $table
	perform_query($insertHost, $link);
	perform_query($insertFacility, $link);

	// Drop old cache values for $table
	$sql = "DELETE FROM ".CACHETABLENAME." WHERE tablename='".$table.
		"' AND updatetime<'".$updateTime."'";
	perform_query($sql, $link);
}


//========================================================================
// BEGIN DATABASE FUNCTIONS
//========================================================================
//------------------------------------------------------------------------
// This function connects to the MySQL server and selects the database
// specified in the DBNAME parameter. If an error occurs then return
// FALSE.
//------------------------------------------------------------------------
function db_connect_syslog($dbUser, $dbPassword, $connType = 'P') {
	$server_string = DBHOST.":".DBPORT;
	$link = "";
	if(function_exists('mysql_pconnect') && $connType == 'P') {
		$link = mysql_pconnect($server_string, $dbUser, $dbPassword);
	}
	elseif(function_exists('mysql_connect')) {
		$link = mysql_connect($server_string, $dbUser, $dbPassword);
	}
	if(!$link) {
		return FALSE;
	}

	$result = mysql_select_db(DBNAME, $link);
	if(!$result) {
		return FALSE;
	}

	return $link;
}


//------------------------------------------------------------------------
// This functions performs the SQL query and returns a result resource. If
// an error occurs then execution is halted an the MySQL error is
// displayed.
//------------------------------------------------------------------------
function perform_query($query, $link) {
	if($link) {
		$result = mysql_query($query, $link) or die('Query failed: ' . mysql_error());
	}
	else {
		die('No DB link');
	}

	return $result;
}


//------------------------------------------------------------------------
// This functions returns a result row as an array.
// The type can be BOTH, ASSOC or NUM.
//------------------------------------------------------------------------
function fetch_array($result, $type = 'BOTH') {
	if($type == 'BOTH') {
		return mysql_fetch_array($result);
	}
	elseif($type == 'ASSOC') {
		return mysql_fetch_assoc($result);
	}
	elseif($type == 'NUM') {
		return mysql_fetch_row($result);
	}
	else {
		die('Wrong type for fetch_array()');
	}
}


//------------------------------------------------------------------------
// This functions sets the row offset for a result resource
//------------------------------------------------------------------------
function result_seek($result, $rowNumber) {
	mysql_data_seek($result, $rowNumber);
}


//------------------------------------------------------------------------
// This functions returns a result row as an array
//------------------------------------------------------------------------
function num_rows($result) {
	return mysql_num_rows($result);
}


//------------------------------------------------------------------------
// This function checks if a particular table exists.
//------------------------------------------------------------------------
function table_exists($tableName, $link) {
	$tables = get_tables($link);
	if(array_search($tableName, $tables) !== FALSE) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}


//------------------------------------------------------------------------
// This function returns an array of the names of all tables in the
// database.
//------------------------------------------------------------------------
function get_tables($link) {
	$tableList = array();
	$query = "SHOW TABLES";
	$result = perform_query($query, $link);
	while($row = fetch_array($result)) {
		array_push($tableList, $row[0]);
	}

	return $tableList;
}


//------------------------------------------------------------------------
// This function returns an array with the names of tables with log data.
//------------------------------------------------------------------------
function get_logtables($link) {
	// Create an array of the column names in the default table
	$query = "DESCRIBE ".DEFAULTLOGTABLE;
	$result = perform_query($query, $link);
	$defaultFieldArray = array();
	while($row = mysql_fetch_array($result)) {
		array_push($defaultFieldArray, $row['Field']);
	}

	// Create an array with the names of all the log tables
	$logTableArray = array();
	$allTablesArray = get_tables($link);
	foreach($allTablesArray as $value) {
		// Create an array of the column names in the current table
		$query = "DESCRIBE ".$value;
		$result = perform_query($query, $link);
		// Get the names of columns in current table
		$fieldArray = array();
		while ($row = mysql_fetch_array($result)) {
			array_push($fieldArray, $row['Field']);
		}

		// If the current array is identical to the one from the
		// DEFAULTLOGTABLE then the name is added to the result
		// array.
		$diffArray = array_diff_assoc($defaultFieldArray, $fieldArray);
		if(!$diffArray) {
			array_push($logTableArray, $value);
		}
	}
	return $logTableArray;
}
//========================================================================
// END DATABASE FUNCTIONS
//========================================================================

//========================================================================
// BEGIN ACCESS CONTROL FUNCTIONS
//========================================================================
//------------------------------------------------------------------------
// This function verifies that the user has access to a particular part
// of php-syslog-ng.
// Inputs are:
// username
// actionName
// dbLink
//
// Outputs TRUE or FALSE
//------------------------------------------------------------------------
function grant_access($userName, $actionName, $link) {
	// If ACL is not used then always return TRUE
	if(!defined('USE_ACL') || !USE_ACL || !defined('REQUIRE_AUTH') || !REQUIRE_AUTH) {
		return TRUE;
	}

	// Get user access
	$sql = "SELECT access FROM ".USER_ACCESS_TABLE." WHERE username='".$userName."' 
			AND actionname='".$actionName."'";
	$result = perform_query($sql, $link);
	$row = fetch_array($result);
	if(num_rows($result) && $row['access'] == 'TRUE') {
		return TRUE;
	}
	// Get default access
	else {
		$sql = "SELECT defaultaccess FROM ".ACTION_TABLE." WHERE actionname='".$actionName."'";
		$result = perform_query($sql, $link);
		$row = fetch_array($result);
		if($row['defaultaccess'] == 'TRUE') {
			return TRUE;
		}
		else {
			return FALSE;
		}
	}
}
//========================================================================
// END ACCESS CONTROL FUNCTIONS
//========================================================================

//========================================================================
// BEGIN REDIRECT FUNCTION
//========================================================================

function g_redirect($url,$mode)
/*  It redirects to a page specified by "$url".
 *  $mode can be:
 *    LOCATION:  Redirect via Header "Location".
 *    REFRESH:  Redirect via Header "Refresh".
 *    META:      Redirect via HTML META tag
 *    JS:        Redirect via JavaScript command
 */
{
  if (strncmp('http:',$url,5) && strncmp('https:',$url,6)) {

     $starturl = ($_SERVER["HTTPS"] == 'on' ? 'https' : 'http') . '://'.
                 (empty($_SERVER['HTTP_HOST'])? $_SERVER['SERVER_NAME'] :
                 $_SERVER['HTTP_HOST']);

     if ($url[0] != '/') $starturl .= dirname($_SERVER['PHP_SELF']).'/';

     $url = "$starturl$url";
  }

  switch($mode) {

     case 'LOCATION': 

       if (headers_sent()) exit("Headers already sent. Can not redirect to $url");

       header("Location: $url");
       exit;

     case 'REFRESH': 

       if (headers_sent()) exit("Headers already sent. Can not redirect to $url");

       header("Refresh: 0; URL=\"$url\""); 
       exit;

     case 'META': 

       ?><meta http-equiv="refresh" content="0;url=<?=$url?>" /><?
       exit;

     default: /* -- Java Script */

       ?><script type="text/javascript">
       window.location.href='<?=$url?>';
       </script><?
  }
  exit;
}

//========================================================================
// END REDIRECT FUNCTION
//========================================================================

//========================================================================
// BEGIN CURL FUNCTIONS
//========================================================================

function postRequest($cookie_file, $post_values, $url)
{
    // this is where we will store HTML output 
    $data = null;

    // initialise cURL resource 
    $cURL_resource = curl_init();

    curl_setopt($cURL_resource, CURLOPT_POSTFIELDS,     $post_values);
    curl_setopt($cURL_resource, CURLOPT_COOKIEFILE,     $cookie_file);
    curl_setopt($cURL_resource, CURLOPT_COOKIEJAR,      $cookie_file);
    curl_setopt($cURL_resource, CURLOPT_URL,            $url);
    curl_setopt($cURL_resource, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($cURL_resource, CURLOPT_RETURNTRANSFER, true);
    // true when debugging 
    curl_setopt($cURL_resource, CURLOPT_HEADER,         false);

    // execute request 
    $data = curl_exec($cURL_resource);

    // close cURL resource 
    curl_close($cURL_resource);

    return $data;
} // END function postRequest($cookie_file, $post_values, $url)

//========================================================================
// END CURL FUNCTIONS
//========================================================================

//========================================================================
// BEGIN Cisco Error Message DB Lookup
//========================================================================
function cemdb($name) {
	global $dbLink;

	// die("Name" . $Name);
	$query = "SELECT message,explanation,action,datetime FROM " . CISCO_ERROR_TABLE . " WHERE name='".$name ."' LIMIT 1";
	//   die("Query: " . $query); 
	$result = perform_query($query, $dbLink) or die(mysql_error());
	$num=0;
	$num=mysql_numrows($result);
	while($row = fetch_array($result)) {
		if ($num < 1) {
			$data = "NULL";
		} else {
			$message = $row['message'];
			$explanation = $row['explanation'];
			$action = $row['action'];
			$pieces = explode(" ", $row['datetime']);
			$date = $pieces[0];
			$time = $pieces[1];
			$data = array($message, $explanation, $action, $date, $time);
		}
	}
	// return $message, $explanation, $action, $date;
	return $data;
}


function printbetween($start,$end,$data) { 
	        // preg_match("/$start(.*)$end/",$data,$match); 
	        preg_match_all("/$start(.*?)$end/i",$data,$match); 
			            return $match; 
} 


//========================================================================
// END Cisco Error Message DB Lookup
//========================================================================
?>
