<?php
// Copyright (C) 2005 Claus Lund, clauslund@gmail.com
// Copyright (C) 2006 Claytn Dukes, cdukes@cdukes.com

require_once 'includes/version.php';

?>
<html>
<head>
<?php echo "<title>".PAGETITLE." ".VERSION.": ".$addTitle."</title>"; ?>
<link rel=stylesheet type=text/css href='css/default.css'>
<META HTTP-EQUIV='Pragma' CONTENT='no-cache'>
 <!-- Begin Calendar -->
 <script type="text/javascript" src="includes/cal/Bs_Misc.lib.js"></script>
 <script type="text/javascript" src="includes/cal/Bs_Button.class.js"></script>
 <script type="text/javascript" src="includes/cal/Bs_DatePicker.class.js"></script>
 <script type="text/javascript" src="includes/cal/Bs_FormFieldSelect.class.js"></script>
 <script type="text/javascript">
 if (moz) {
	 document.writeln("<link rel='stylesheet' href='css/win2k_mz.css'>");
 } else {
	 document.writeln("<link rel='stylesheet' href='css/win2k_ie.css'>");
 }

function fromdate() {
	myDatePicker = new Bs_DatePicker();
	myDatePicker.jsBaseDir = '/';
	myDatePicker.toggleButton.imgPath = '/images/buttons/';
	myDatePicker.fieldName                  = 'datePickerField';
	myDatePicker.openByInit                 = true;
	myDatePicker.dateFormat                 = 'ISO';
	myDatePicker.useSpinEditForYear         = false;

	myDatePicker.dateInputClassName         = 'datePickerDate';
	myDatePicker.monthSelectClassName       = 'datePickerMonth';
	myDatePicker.yearInputClassName         = 'datePickerYear';
	myDatePicker.dayTableClassName          = 'datePickerTable';
	myDatePicker.dayHeaderClassName         = 'datePickerDayHeader';
	myDatePicker.dayClassName               = 'datePickerDay';
	myDatePicker.dayClassNameByWeekday['7'] = 'datePickerDaySunday';
	myDatePicker.dayTableAttributeString    = 'width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="white"';

	myDatePicker.dayHeaderFontColor         = 'yellow';
	myDatePicker.dayHeaderBgColor           = 'green';
	myDatePicker.dayFontColor               = 'brown';
	myDatePicker.dayBgColor                 = 'antiquewhite';
	myDatePicker.dayFontColorActive         = 'red';
	myDatePicker.dayBgColorActive           = 'white';
	myDatePicker.dayTableBgColor            = 'silver';
	myDatePicker.dayBgColorOver             = 'yellow';

	myDatePicker.width                      = 115;
	myDatePicker.daysNumChars               = 1;
	myDatePicker.drawInto('myDatePickerDiv');
}
function todate() {
	myDatePicker = new Bs_DatePicker();
	myDatePicker.jsBaseDir = '/';
	myDatePicker.toggleButton.imgPath = '/images/buttons/';
	myDatePicker.fieldName                  = 'datePickerFieldR';
	myDatePicker.openByInit                 = true;
	myDatePicker.dateFormat                 = 'ISO';
	myDatePicker.useSpinEditForYear         = false;

	myDatePicker.dateInputClassName         = 'datePickerDate';
	myDatePicker.monthSelectClassName       = 'datePickerMonth';
	myDatePicker.yearInputClassName         = 'datePickerYear';
	myDatePicker.dayTableClassName          = 'datePickerTable';
	myDatePicker.dayHeaderClassName         = 'datePickerDayHeader';
	myDatePicker.dayClassName               = 'datePickerDay';
	myDatePicker.dayClassNameByWeekday['7'] = 'datePickerDaySunday';
	myDatePicker.dayTableAttributeString    = 'width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="white"';

	myDatePicker.dayHeaderFontColor         = 'yellow';
	myDatePicker.dayHeaderBgColor           = 'green';
	myDatePicker.dayFontColor               = 'brown';
	myDatePicker.dayBgColor                 = 'antiquewhite';
	myDatePicker.dayFontColorActive         = 'red';
	myDatePicker.dayBgColorActive           = 'white';
	myDatePicker.dayTableBgColor            = 'silver';
	myDatePicker.dayBgColorOver             = 'yellow';

	myDatePicker.width                      = 115;
	myDatePicker.daysNumChars               = 1;
	myDatePicker.drawInto('myDatePickerDivR');
}
</script>
<!-- End Calendar -->
<!-- Begin Overlib -->
<script src="includes/js/overlib.js" language="Javascript" type="text/javascript"></script>
<DIV id=overDiv	style="Z-INDEX: 1000; VISIBILITY: hidden; POSITION: absolute"></DIV>
<!-- End Overlib -->
</head>
<body>
<table class="header">
<tr><td>
	<a href="index.php"><h2 class="logo"><?=$version?></h2></a>
	Network Syslog Monitor
</td><td class="headerright">
	<?php echo date("l F dS, Y - H:i:s"); ?><br>
	Your IP: <?php echo $_SERVER['REMOTE_ADDR']; ?>
</td></tr></table>
<table class="headerbottom"><tr><td>
<?php
if(defined('REQUIRE_AUTH') && REQUIRE_AUTH == TRUE && $sessionVerified) {
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=login&logout=TRUE\">Logout</a>";
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=searchform\">Search</a>";
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=config\">Config</a>";
}
elseif(defined('REQUIRE_AUTH') && REQUIRE_AUTH == TRUE) {
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=login\">Login</a>";
}

if(!defined('REQUIRE_AUTH') || !REQUIRE_AUTH) {
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=searchform\">Search</a>";
}

if(defined('USE_CACHE') && USE_CACHE && !REQUIRE_AUTH) {
	echo "<a class=\"vertmenu\" href=\"index.php?pageId=config\">Config</a>";
}

echo "<a class=\"vertmenu\" href=\"index.php?pageId=help\">Help</a>\n";
echo "<a class=\"vertmenu\" href=\"index.php?pageId=about\">About</a>\n";
echo "&nbsp;</td></tr></table><center>\n";
?>
