/* util.c */
u_int32_t		get_ipaddr (char *);
