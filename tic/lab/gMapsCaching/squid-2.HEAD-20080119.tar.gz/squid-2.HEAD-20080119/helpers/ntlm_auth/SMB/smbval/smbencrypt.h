void SMBencrypt(uchar * passwd, uchar * c8, uchar * p24);
void SMBNTencrypt(uchar * passwd, uchar * c8, uchar * p24);

