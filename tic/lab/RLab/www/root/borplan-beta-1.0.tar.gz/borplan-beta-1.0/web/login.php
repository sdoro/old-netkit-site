<?php 

/*
* $Id: login.php,v 1.1.1.1 2006/02/28 14:35:40 sveronese Exp $
*
* borpLAN ~  login.php
* Pagina di login -
*/

	session_start();

	// Controllo l'indirizzo ip da cui si collega
	// host autorizzati all'amministrazione
	$hosts = explode(",",$authorized_ip);

	// Pulisco gli evenutali errori
	for($i=0 ; $i<=count($hosts) ; $i++)
	{
		$trimmed[$i] = trim($hosts[$i]);
	}

	// Controllo se l'ip �presente nell'array
	echo $_SERVER["REMOTE_ADDR"];
	$ip_test = array_search($_SERVER["REMOTE_ADDR"],$trimmed);
	$auth = is_int($ip_test);

?>

<?php
if (!empty($_GET))
{
	require "../bad.php";
}
else if (!$auth)
{
	require "../bad.php";
}
else if (!$_POST['check'])
{
?>
<html>

<head>
	<title>Please Login!</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="../include/style.css" type="text/css">
</head>

<body>

<form action="<?php echo $PHP_SELF ?>" method="POST">
	<table border="0" cellspacing="0" cellpadding="0" width="100%">
		<tr>
			<td align="center">
				<center>
					<br><img src="../images/login.png" alt="Login Page"><br><br>
					<table border="0" width="350">
						<tr>
							<td bgcolor="#DCDCDC" align="center">
								<b>Welcome, please Login!</b>
							</td>
						</tr>	
						<tr>
							<td bgcolor="#FFFFFF" align="left">
								<table bgcolor="#ffffff" align="center" border="0" width="100%">
									<tr>
										<td align="right" width="30%">
											Username:
										</td>
										<td align="left" width="*">
											<input type="text" name="user" value="" class="formLogin" maxlength="32">
										</td>
									</tr>
									<tr>
										<td align="right" width="30%">
											Password:
										</td>
										<td align="left" width="*">
											<input type="password" name="pass" maxlength="32">
										</td>
									</tr>
									<input type="hidden" name="check" value="1">
								</table>
							</td>
						</tr>							
						<tr>
							<td align="left">
								<center>
									<input type="submit" name="login" value="Login">
								</center>
							</td>
						</tr>
					</table>
				</center>
			</td>
		</tr>
	</table>
</form>
</body>
</html>

<?php
}
else
{
	// Variabili in post
	$user = $_POST['user'];
	$pass = crypt($_POST['pass'],$salt);

	// File delle password
	$pass_file = $doc_root.$lab_name."/.passdb";
	$passdb = fread(fopen($pass_file,'r'),filesize($pass_file));
	$auth = false;
	
	// Esplodo la stringa e ottengo un array dove avr�uid:pwd in ogni cella
	// e l'ultima cella sar�vuota visto che l'ultima stringa conterr�anche lei \n
	$firstexplode = explode("\n",$passdb);
	
	// Rieseguo un secondo explode per ogni cella dell'array e caricher�	// due array $users e $pwds
	$j=0;
	for ($i=0 ; $i<(count($firstexplode)-1) ; $i++)
	{
		$temp = explode("::",$firstexplode[$i]);
		$users[$j] = $temp[0];
		$pwds[$j] = $temp[1];
		$j++;
	}
	
	// Controllo se �presente l'utente dentro all'array $users
	$chiave_uid = array_search($user,$users);
	
	if (is_int($chiave_uid))
	{
		// Controllo l'indirizzo ip da cui si collega
		// host autorizzati all'amministrazione
		$hosts = explode(",",$authorized_ip);
		
		// Pulisco gli evenutali errori
		for($i=0 ; $i<=count($hosts) ; $i++)
		{
			$trimmed[$i] = trim($hosts[$i]);
		}
		
		// Controllo se l'ip �presente nell'array
		echo $_SERVER["REMOTE_ADDR"];
		$ip_test = array_search($_SERVER["REMOTE_ADDR"],$trimmed);
		$auth = is_int($ip_test);
		
		// Controllo se corrisponde la password e il controllo dell'ip ha dato esito positivo
		if (!strcmp($pwds[$chiave_uid],$pass) && $auth) 
		{
			$_SESSION["loggedin"] = 1 ;
			$_SESSION["lab"] = $lab_name;
			$_SESSION["user"] = $post_uid;
		
		?>   
 
		<script language="JavaScript">
			location = "<?php echo $PHP_SELF ?>" ;
		</script>
		
		<?php
		}
		else
		{
			require "../loginerr.php";
		}
	}
	else
	{
		require "../loginerr.php";
	}
}
?>
