<?php

/*
* $Id: loginerr.php,v 1.1.1.1 2006/02/28 14:35:39 sveronese Exp $
*
* borpLAN ~  loginerr.php
* Pagina di errore login fallito. -
*/

?>

<html>
<head>
	<title>login failed!</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="./include/style.css" type="text/css">
</head>
<body>
<br><br>
	<center>
		<img src="../images/loginerr.png" alt="" border="0" hspace="8" vspace="2">
		<h1>LOGIN FAILED!</h1>
	</center>
</body>
</html>