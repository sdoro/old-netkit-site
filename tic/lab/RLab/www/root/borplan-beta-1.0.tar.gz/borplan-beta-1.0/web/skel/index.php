<?php

/*
* $Id: index.php,v 1.1.1.1 2006/02/28 14:35:53 sveronese Exp $
*
* borpLAN ~  .skel/index.php 
* Pagina iniziale di una nuova area -
*/

  session_start();
	
  $salt = "CACCA";
  require "../mainconfig.php.inc";
  
  // Includo le configurazioni per l'area
  require "config.php.inc";
  require "map.php.inc";
  require "services.php.inc";
  
  // Controllo se l'utente �autenticato
  if (isset($_SESSION['loggedin']) && !strcmp($lab_name,$_SESSION['lab']))
  {
	require "../borpLAN.php";
  }
  else
  {
    require "../login.php";
  }

?>
