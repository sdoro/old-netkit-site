<?php

/*
* $Id: borpLAN.php,v 1.2 2007/04/11 16:30:18 sdoro Exp $
*
* borpLAN ~  borpLAN.php
* Motore del programma -
*/

if ((!empty($_GET)) || (!isset($_SESSION['loggedin'])))
{
	require "../bad.php";
}
else if (isset($_POST['logoutButton']))
{
	unset($_SESSION['loggedin']);
	session_unset();
	$_SESSION = Array();
	session_destroy();
?>
	
	<script language="JavaScript">
		location = "<?php echo $PHP_SELF ?>" ;
	</script> 	

<?php
}
else if (isset($_POST['adminButton']))
{
	include("config.php.inc");
	include("services.php.inc");
	require "admin.php";
}
else
{
	include("config.php.inc");
	include("services.php.inc");
	include("map.php.inc");
?>
	<html>
	<head>
		<title><?php echo $lab_name; ?> Internet Manager</title>
		<link rel="StyleSheet" href="../include/style.css" type="text/css">
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	</head>
	<body>

<?php
	
	// check router status
	$out = exec("ping -c 1 $router_ip | grep 64");
	
	if (!strcmp($out,""))
	{
		$status = $uptime = "down";
	}
	else
	{
		$status = "up";
	}

	// get global status of router (uptime, clients status, ..)
	exec("bashservices.sh get ".$router_ip, $output );

	if (!strcmp($status ,"up"))
	{ 
		// get uptime line to parse
		exec("bashservices.sh uptime ".$router_ip, $output);

    	$ar_buf = explode(' ', $output[0]);

    	$sys_ticks = trim($ar_buf[0]);

		$min = $sys_ticks / 60;
		$hours = $min / 60;
		$days = floor($hours / 24);
		$hours = floor($hours - ($days * 24));
		$min = floor($min - ($days * 60 * 24) - ($hours * 60));
		
		if ($days != 0) 
		{
			$uptime = "$days giorni ";
		}
		
		if ($hours != 0) 
		{
			$uptime .= "$hours ore ";
		}
		$uptime .= "$min minuti";
  	}
	
	
	// Crea l'array con lo stato dei client
	for ($i = 0 ; $i < $ROWS ; $i++)
	{
		for ($j = 0 ; $j < $COLS ; $j++)
		{
			// Prima configura tutti i client ad allow
			foreach ($services as $service)
			{
				$pc[$i][$j][$service] = "d";
			}

			// Carica lo stato del client, configuraato sul router
			exec("bashservices.sh show ".$router_ip." ".$net_prefix.$pc[$i][$j]['ip'] , $output );

			// Modifica le varie porte droppate, lette dal router. 
			// Controlla non siano presenti regole non amministrate. Se si, termina il lavoro
			// e avvisa con un errore a video.
			// bashservices.sh spara fuori una lista con dpt:<numeroporta>
			foreach ($output as $line)
            {
            	$tokens = explode(":",$line);
				
				if ($tokens[0] == "dpt")
				{
					// Controllo sia una porta presente in $services
					$test_trash = array_search($tokens[1],$services);
					$trash = is_int($test_trash);
					
					// se la porta non �immondizia esegue la modifica
					if ($trash)
					{
						// Esegue la modifica
						$pc[$i][$j][$tokens[1]] = "a";
            			$tokens[1];
					}
				}	
            }
            $output = Array();
		}
	}		

	// ---> Stampare errore se trovato scoasse

	if (isset($_POST['changeButton']) || isset($_POST['extendButton']))
	{
		if (isset($_POST['extendButton']))
		{
			for($i=0 ; $i<$ROWS ; $i++)
			{
				for($j=0 ; $j<$COLS ; $j++)
				{
					if (isset($pc[$i][$j]['ip']))
					{
						foreach($services as $service)
						{
							$index0 = "0_0_".$service;
							$index = $i."_".$j."_".$service ;
							if (isset($_POST[$index0]))
							{
								$_POST[$index] = 1;
							}
							else
							{
								unset($_POST[$index]);
							}
						}
					}
				}	
      		}
		}	
		unset($_POST['extendButton']);
		
		for ($i = 0 ; $i < $ROWS ; $i++)
		{
			for ($j = 0 ; $j < $COLS ; $j++)
			{
				if (isset($pc[$i][$j]['ip']))
				{
					$prev = explode(":" , $_POST[$pc[$i][$j]['ip']]);
					foreach ($services as $service)
					{	
						$index = $i."_".$j."_".$service ;
						
						$ok = TRUE;
					
						if (isset($_POST[$index]))
						{
							$action = "allow";
						}
						else if (is_int(array_search($service , $prev)))
						{
							$action = "drop";
						}
						else
						{
							$ok= FALSE;
						}
					
						if ($ok) exec("bashservices.sh ". $action . " " . $router_ip . " " . $net_prefix.$pc[$i][$j]['ip'] . " " . $service);
														
						$pc[$i][$j][$service] = isset($_POST[$index]) ? "a" : "d" ;
					}  	  
				}	
			}
		}    
			 
		exec("bashservices.sh set ".$router_ip);
		
		unset($_POST['changeButton']);
		$_POST = Array();
		?>
		
		<script language="JavaScript">
			location = "<?php echo $PHP_SELF ?>" ;
		</script>
		
		<?php
	}
?>
	<div id="container">
		<div id="logo">
			<img src="../images/logo.png" width="128" height="128" alt="" border="0" hspace="8" vspace="2" align="center">
			<?php echo $lab_name; ?> Internet Manager
		</div>
	
		<div id="menu">
			<table class="menu" width="100%">
   				<tr>
   					<td>
   						<table class="box">
   							<tr class="boxheader">
   								<td class="boxheader">Router Info</td>
 	  						</tr>
						    <tr class="boxbody">
						    	<td>
						    		<table width="100%">
						    			<tr>
				    						<td>Router Status</td>
				    						<td><?php echo $status ?></td>
				    					</tr>
					    				<tr>
					    					<td>Router Uptime</td>
					    					<td><?php echo $uptime ?></td>
					    				</tr>
						    		</table>
						    	</td>
						    </tr>
						</table>
					</td>
				</tr>
			</table>
		</div>
      
		<form action="<?php echo $PHP_SELF ?>" method="post">
	
			<div id="button">	
				<button name="extendButton" type="submit">
					<!--img src="../images/tick.<?php echo $ext ?>" width="12" height="12" alt="" border="0" hspace="8" vspace="2" align="center"-->
					Estendi a tutti
				</button>
				<button name="changeButton" type="submit">
					<!--img src="../images/tick.<?php echo $ext ?>" width="12" height="12" alt="" border="0" hspace="8" vspace="2" align="center"-->
					Cambia stato
				</button>
				
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			
				<button name="adminButton" type="submit">
					<!--img src="../images/logout.<?php echo $ext ?>" width="12" height="12" alt="" border="0" hspace="8" vspace="2" align="center"-->
					Admin
				</button>
				<button name="logoutButton" type="submit">
					<!--img src="../images/logout.<?php echo $ext ?>" width="12" height="12" alt="" border="0" hspace="8" vspace="2" align="center"-->
					Logout
				</button>
			</div>
		
			<div id="mappa">
				<table width="100%">

<?php
	for ($i=0 ; $i<$ROWS ; $i++)
	{
?>
				<tr>

<?php
		for ($j=0 ; $j<$COLS ; $j++)
		{
			if (!isset($pc[$i][$j]['ip']))
			{
?>					<td class="separator"></td>
<?php
			}
			else
			{
				$prec_stat = "";
				$class = 0;
				// genera il colore della postazione
				foreach ($services as $service)
				{
					if ($pc[$i][$j][$service] == "d") $class++;
				}
				
				// -----------> Commentato colore postazione
				/* foreach ($pc[$i][$j] as $tip)
				{
					if (!strcmp($tip,"d")) $class++;
				} */
			
				// Se l'indice �al primo ciclo, coloro il primo pc come manager
				if (($i == 0) AND ($j == 0))
					$class = "manager";
				else if ($class == count($services)) 
					$class = "hard";
				else if ($class == 0)
					$class = "easy";
				else
					$class = "medium";
?>  	
						<td>
							<table class="postazione">
								<tr>
									<td class="<?php echo $class ?>"><img src="../images/pc.gif" width="45" height="45" alt="" border="0" hspace="8" vspace="2" align="center">
										<?php echo $net_prefix.$pc[$i][$j]['ip']; ?>
									</td>
								</tr>
								<tr>
									<td class="<?php echo $class ?>">
										<fieldset>
											<legend>Ports</legend>
											<table class="ports">
<?php
				$counter = 0;
				foreach ($services as $service)
				{
					if ($counter == 0)
					{
?>
												<tr>                            
<?php
					}
?>
													<td>
														<input type="checkbox" 
																name="<?php echo $i.".".$j.".".$service ?>" 
																value="<?php echo $pc[$i][$j][$service] ?>" 
<?php 
					if (!strcmp("a" , $pc[$i][$j][$service]))
					{
						$prec_stat = $prec_stat.$service.":";
						echo "checked";
					}
?>	 
														>
<?php 
					echo $services_name[$service] ;
?>
													</td>
<?php
					if ($counter == 1)
					{
?> 
												</tr>  
<?php
					}
    
					if ($counter == 1)
					{
						$counter = 0;
					}
					else
					{
						$counter++;
					} 
				} 	
?>  			          
												 <input type="hidden" name="<?php echo $pc[$i][$j]['ip'] ?>" value="<?php echo $prec_stat ?>">
											</table>
										</fieldset>
									</td>
								</tr>
							</table>
						</td>
<?php
			}
		}
?>  
					</tr>
<?php
	}
?>
				</table>
			</div>
		</form>
	</div>
</body>
</html>

<?php
}
?>
	

