<?php

/*
* $Id: admin.php,v 1.1.1.1 2006/02/28 14:35:39 sveronese Exp $
*
* borpLAN ~  admin.php
* Pagina di amministrazione generica -
*/

if ((!empty($_GET)) || (!isset($_SESSION['loggedin'])))
{
	require "bad.php";
}
else if (isset($_POST['return_to_map']))
{
	unset($_POST['return_to_map']);
	?>
	
		<script language="JavaScript">
			location = "<?php echo /* $base_location*/$PHP_SELF ?>" ;
		</script>
	
	<?php
}
else if (isset($_POST['logoutButton']))
{
	unset($_SESSION['loggedin']);
	session_unset();
	$_SESSION = Array();
	session_destroy();

	?>

		<script language="JavaScript">
                	location = "<?php echo $PHP_SELF ?>" ;
	        </script>
	
	<?php
}	
else
{	
	
	include "../functions.php";
	
?>
	<html>
	
	<head>
		<title>New Admin Page for <?php echo $lab_name ?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<link rel="stylesheet" href="../include/style.css" type="text/css">
	</head>

	<body>
	
<?php
	
	if (isset($_POST['submit']))
	{
		if (!empty($_POST['old_pwd']))
		{		
			// recupero dati in post
			$old_pwd = crypt($_POST["old_pwd"],$salt);
			$new_pwd = $_POST['new_pwd'];
			$confirm_pwd = $_POST['confirm_pwd'];
			$user = $_SESSION["user"];			

			// Se la password fornita �vuota, errore
                        if (empty($new_pwd))
                        {
                                $error = "<font color=\"red\"><b>Non �ammessa
                                        password vuota</b><br></font>";
                        }
                        // altrimenti controllo la password fornita coincida co
                        else if (!strcmp($new_pwd,$confirm_pwd))
                        {
                                // Se si carico il file di pwd su di una stringa
                                $pass_file = ".passdb";
				$passdb = fread(fopen($pass_file,'r'),filesize($pass_file));
				
				// Esplodo la stringa e ottengo un array dove avr�uid:pwd in ogni cella
                                // e l'ultima cella sar�vuota visto che l'ultima stringa conterr�anche lei \n
                                $uid_pwd = explode("\n",$passdb);				

				// Pulisco gli evenutali errori
                		for($i=0 ; $i<=count($uid_pwd) ; $i++)
                		{	
                        		$trimmed[$i] = trim($uid_pwd[$i]);
				}
				
				// Genero la stringa utente:$_POST["old_pwd"] per il controllo
				$str_uid_pwd = $_SESSION["user"]."::".$old_pwd;
			
				// Cerco nell'array, se �giusta la old_pwd inviata
				$temp = array_search($str_uid_pwd,$trimmed);
				$trovato = is_int($temp);

				if ($trovato)
				{
					// Modifico il file
					$new_pwd = $_POST['new_pwd'];
					$new_str = $_SESSION["user"]."::".crypt($new_pwd,$salt);
					$new_str = trim($new_str);
					// replace nella stringa passdb
					$passdb = str_replace($str_uid_pwd,$new_str,$passdb);
					$fp = fopen(".passdb" , "w");
				        fputs($fp, $passdb, strlen($passdb));
			                fclose($fp);
				}
				else
				{
					$error = "<font color=\"red\"><b>La password vecchia non coincide</b><br></font>";
				}
			}
			else
			{
				$error = "<font color=\"red\"><b>Le password immesse non coincidono</b><br></font>";
			}
		}//if password
					
		if (!isset($error))
		{	
			// Rigenera il file di configurazione
			$new_config = "<?php\n";
			$new_config .= "\n";
			$new_config .= "/* File di configurazione */\n";
			$new_config .= "\$lab_name = '".$lab_name."';\n";
			$new_config .= "\$authorized_ip = '".$_POST['authorized_ip']."';\n";
			$new_config .= "\$net_prefix = '".$_POST['net_prefix']."';\n";
			$new_config .= "\$router_ip = '".$_POST['router_ip']."';\n";
			$new_config .= "//END\n";
			$new_config .= "?>";

			$fp = fopen("config.php.inc" , "w");
			fputs($fp, $new_config, strlen($new_config));
			fclose($fp);
		
			unset($_POST['submit']);
			$_POST = Array();
		
			?>
				
				<script language="JavaScript">
					location = "<?php echo $PHP_SELF ?>" ;
				</script>
			
			<?php
		}
	}
?>
	
<div id="container">

	<div id="logo"> <!-- logo -->
		<img src="../images/admin.png" width="128" height="128" alt="" border="0" hspace="8" vspace="2" align="center">
		<?php echo $lab_name; ?>'s Admin page
	</div>
	
	 <form action="<?php echo $PHP_SELF; ?>" method="post">	

	<div id="button">	
		<button name="return_to_map" type="submit">
			<!--img src="../images/tick.<?php echo $ext ?>" width="12" height="12" alt="" border="0" hspace="8" vspace="2" align="center"-->
			Mappa
		</button>
		<button name="submit" type="submit" value="Invia">
			<!--img src="../images/tick.<?php echo $ext ?>" width="12" height="12" alt="" border="0" hspace="8" vspace="2" align="center"-->
			Submit
		</button>
		<input  type="hidden" name="adminButton" value="1">
			
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
		<button name="logoutButton" type="submit">
			<!--img src="../images/logout.<?php echo $ext ?>" width="12" height="12" alt="" border="0" hspace="8" vspace="2" align="center"-->
			Logout
		</button>
	</div>
	
	<div id="mappa">
		<?php if ($error) echo $error; ?>
		<table class="boxbody" align="left" border="0" cellpadding="3" cellspacing="1" width="80%">
			<tr>
				<th colspan="1" align="left" height="28" class="nav" nowrap="nowrap">Pagina di amministrazione per <?php echo $lab_name; ?></th>
			</tr>
			
			<tr>
				<td colspan="2">I campi contrassegnati con * sono obbligatori</td>
			</tr>
			
			<tr>
				<td colspan="2"><b>Informazioni login</b></td>
			</tr>
					
			<tr>
				<td>Vecchia Password:</td>
				<td><input type="password" name="old_pwd" size="25" maxlength="100"></td>
			</tr>
			
			<tr>
				<td>Nuova Password: *</td>
				<td><input type="password" name="new_pwd" size="25" maxlength="100"></td>
			</tr>
			
			<tr>
				<td>Conferma nuova password: *</td>
				<td><input type="password" name="confirm_pwd" size="25" maxlength="100"></td>
			</tr>
			
			<tr>
				<td colspan="2"><br><b>Parametri generali</b></td>
			</tr>
					
			<tr>
				<td>Nome Laboratorio: </td>
				<td><!--<input type="text" name="lab_name" size="25" maxlength="100" value="--><?php echo $lab_name; ?><input type="hidden" name="lab_name" value="<?php echo $lab_name; ?>"><!-- " >--></td>
			</tr>
			
			<tr>
				<td>Prefisso di rete: </td>
				<td><input type="text" name="net_prefix" size="25" maxlength="100" value="<?php echo $net_prefix; ?>" ></td>
			</tr>
			
			<tr>
				<td>Ip autorizzato: </td>
				<td><input type="text" name="authorized_ip" size="25" maxlength="100" value="<?php echo $authorized_ip; ?>" ></td>
			</tr>
			
			<tr>
				<td>Router ip:</td>
				<td><input type="text" name="router_ip" size="25" maxlength="100" value="<?php echo $router_ip; ?>" ></td>
			</tr>
		
			</form>
		</table>
	</div>
</div> <!-- /container -->
</body>
</html>

<?php
}
?>
