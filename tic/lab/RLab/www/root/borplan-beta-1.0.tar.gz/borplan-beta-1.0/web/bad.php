<?php

/*
* $Id: bad.php,v 1.1.1.1 2006/02/28 14:35:39 sveronese Exp $
*
* borpLAN ~  bad.php
* Pagina di errore -
*/

?>
<html>
<head>
	<title>bad idea!</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<link rel="stylesheet" href="./include/style.css" type="text/css">
</head>
<body>
<br><br>
	<center>
		<img src="./images/bad.gif" alt="" border="0" hspace="8" vspace="2">	
		<h1>BAD IDEA!</h1>
	</center>
</body>
</html>