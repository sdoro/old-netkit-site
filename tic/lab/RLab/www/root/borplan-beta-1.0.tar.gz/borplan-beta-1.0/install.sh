#!/bin/sh
#
# $Id: install.sh,v 1.1.1.1 2006/02/28 14:35:39 sveronese Exp $
#
# borpLAN ~  install.sh 
# Script d'installazione -
#-----------------------------------------------------------------------------#

#--------------------Valori di default-----------------------------------#
DEF_DOCROOT="/var/www/borpLAN/"
DEF_WEBUSER="www-data"
DEF_WEBGROUP="www-data"
#-----------------------------------------------------------------------------#

#-------------------------Parte interattiva-----------------------------#
echo "Installazione di borpLAN: richiesta parametri fondamentali"
echo "(CTRL+C per terminare...)"
echo
echo "Directory d' installazione"
echo -n "[$DEF_DOCROOT] Specificare / finale: "
read DOCROOT
echo
echo "Utente che esegue il demone del webserver"
echo -n "[$DEF_WEBUSER]: "
read WEBUSER
echo
echo "Gruppo che esegue il demone del webserver"
echo -n "[$DEF_WEBGROUP]: "
read WEBGROUP
echo
echo "esecuzione controlli sul sistema..."
#-----------------------------------------------------------------------------#

#--------------------Parte non interattiva----------------------------#
if test -z "$DOCROOT"
then
	DOCROOT=$DEF_DOCROOT
fi

if test -z "$WEBUSER"
then
	WEBUSER=$DEF_WEBUSER
fi

if test -z "$WEBGROUP"
then
	WEBGROUP=$DEF_WEBGROUP
fi

# Controlla se è già presente la directory
if [ ! -d "$DOCROOT/$NEWLAB_NAME" ]
then
	# Controlla se esiste l'utente specificato
	TESTUSER=`cat /etc/passwd | grep -w $WEBUSER`
	if [ $TESTUSER != "" ]
	then
		# Controllo se esiste il gruppo specificato
		TESTGROUP=`cat /etc/group | grep -w $WEBGROUP`
		if [ $TESTGROUP != "" ]
		then
			echo -n "...installazione albero delle directory..."

			mkdir $DOCROOT
			cp web/* $DOCROOT -R
			cp bash/* /usr/local/bin
			
			# Rende la directory skel nascosta
			cd $DOCROOT/skel
			# Link simbolici alle directory delle immagini e degli stili
			ln -s ../images images
			ln -s ../include include
			mv $DOCROOT/skel $DOCROOT.skel
			
			# Genero il file di configurazione php
			cd $DOCROOT
			echo "<?php" > mainconfig.php.inc
			echo "\$doc_root = \"$DOCROOT\";" >> mainconfig.php.inc
			echo "?>" >> mainconfig.php.inc 
		
			# Genero il file di configurazione bash
			cd /usr/local/bin/
			echo "# borpLAN basic configuration file" > borplan.conf
			echo "DOCROOT=$DOCROOT" >> borplan.conf
			echo "WEBUSER=$WEBUSER" >> borplan.conf
			echo "WEBGROUP=$WEBGROUP" >> borplan.conf
		
			chown ${WEBUSER}:${WEBGROUP} ${DOCROOT}* -R
			chown ${WEBUSER}:${WEBGROUP} ${DOCROOT}
			chmod 600 ${DOCROOT}.skel/.passdb
		
			chown ${WEBUSER}:${WEBGROUP} /usr/local/bin/bashservices.sh
			chown ${WEBUSER}:${WEBGROUP} /usr/local/bin/newlab.sh
			chown ${WEBUSER}:${WEBGROUP} /usr/local/bin/borplan.conf
		
			chmod +x /usr/local/bin/bashservices.sh
			chmod +x /usr/local/bin/newlab.sh
			chmod +x /usr/local/bin/newpass.sh
		
			echo
			echo "Installazione completata."
			echo "E' ora possibile creare il proprio laboratorio eseguendo il comando newlab.sh e fornendo i parametri richiesti"
		else
			echo "Gruppo $WEBGROUP non presente sul sistema"	
		fi
	else
		echo "Utente $WEBUSER non presente sul sistema"
	fi
else
	echo "Directory $DOCROOT gi� presente."
fi

echo "terminata."
#-----------------------------------------------------------------------------#


