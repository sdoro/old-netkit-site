#!/bin/sh
#
# $Id: bashservices.sh,v 1.2 2007/04/11 16:30:18 sdoro Exp $
#
# borpLAN ~ bashservices.sh
# Interfaccia con iptables - 
#-----------------------------------------------------------------------------#

#--------------------Configurazione------------------------------------#
USER="root"			# utente che si collega a SSH
SSH_PORT="22"			# porta SSH del router
DEST="0.0.0.0/0"		# destinazione del traffico
CHAIN="dynamic"		# chain iptables per borpLAN
#------------------------------------------------------------------------------#

#----------------------------Funzioni---------------------------------------#

# Abilita il traffico tra il client $2 e il proxy $3
allow_port ()
{
	ACTION=A # Delete rule in chain
        grep "ACCEPT" /tmp/show-$1.tmp | grep "$2 " | grep "dpt:$3 " > /tmp/already-$1
        if [ ! -s /tmp/already-$1 ]; then
          mod_port $1 $2 $3 $ACTION
        fi
}

# Blocca il traffico tra il client $2 e il proxy $3
drop_port ()
{
	ACTION=D # Append rule in chain
	mod_port $1 $2 $3 $ACTION
}	

# Genera lo script di modifica delle porte
mod_port()
{
	if [ $1 ]; then
		if [ $2 ];  then
			if [ $3 ]; then
				echo  -n "iptables -$4 $CHAIN -s $2 -p tcp -d $DEST --destination-port $3 -j ACCEPT ; " >> /tmp/set-$1.tmp
				# echo -e "\r" >> /tmp/set-$1.tmp
			else
				echo "Destination port missing!"
			fi
		else
			echo "Client IP missing!"
		fi
	else
		echo "Router IP missing!"
	fi
}

# Ritorna la stringa dell'uptime dal router $3 non parsata
router_uptime ()
{
	if [ $1 ];  then
		cat /tmp/uptime-$1.tmp
	else
		echo "Router IP missing!"
	fi
}

# Ritorna lo stato del router $3 (up/down)
router_status ()
{
	if [ $1 ];  then
		$TEST = `/bin/ping -c 1 $1 | grep 64`
		if [$TEST]; then
			echo "up"
		else 
			echo "down"
		fi
	else
		echo "Router IP missing!"
	fi
}

# Ritorna lo stato globale del router (configurazioni client, uptime,ecc)
get_status ()
{
	if [ "$1" != "" ];  then
			
			rm -rf /tmp/show-$1.tmp
			rm -rf /tmp/uptime-$1.tmp
			
			if [ "$1" != "127.0.0.1" ]; then
				ssh -p 22 root@$1 iptables -L $CHAIN -n > /tmp/show-$1.tmp
				ssh -p 22 root@$1 cat /proc/uptime > /tmp/uptime-$1.tmp
			else
				iptables -L $CHAIN -n > /tmp/show-$1.tmp
				cat /proc/uptime > /tmp/uptime-$1.tmp
			fi
	else
		echo "Router IP missing!"
	fi
}

# Configura il router con le modifiche eseguite
set_status ()
{
	if [ "$1" != "" ];  then
			
			# Controllo se devo eseguire in locale o in remoto
			if [ "$1" != "127.0.0.1" ]; then
				#echo "" >> /tmp/set-$1.tmp
				echo "rm -rf /tmp/set-$1.tmp" >> /tmp/set-$1.tmp
				scp /tmp/set-$1.tmp root@$1:/tmp/
				ssh -p 22 root@$1 chmod +x /tmp/set-$1.tmp
				ssh -p 22 root@$1 /tmp/set-$1.tmp	
				#ssh -p 22 root@$1 `cat /tmp/set-$1.tmp`
				# rm -rf /tmp/set-$1.tmp
			else
				chmod +x /tmp/set-$1.tmp
				/tmp/set-$1.tmp
			fi
			rm -rf /tmp/set-$1.tmp
	else
		echo "Router IP missing!"
	fi
}
# Ritorna la lista delle porte bloccate per il client $2 nel formato di iptables (dpt:<port>)
# Se tutte le porte sono abilitate ritorna una stringa vuota.
client_status ()
{
	if [ "$1" != "" ];  then
			cat /tmp/show-$1.tmp | grep -w $2 | awk '{print$7}'
	else
			echo "Router IP missing!"
	fi
}

# Ritorna una lista dei comandi disponibili
usage ()
{
	echo "Usage: bashservices.sh 1 2 [3] [4]"
	echo "1: action (allow|drop|uptime|updown|show|get|set)"
	echo "2: router IP addr"
	echo "3: client IP addr"
	echo "4: destination port"
}

#------------------------------------------------------------------------------#

#--------------------------------Main---------------------------------------#

case "$1" in
	'allow')
		allow_port $2 $3 $4
		;;
	'drop')
		drop_port $2 $3 $4
		;;
	'uptime')
		router_uptime $2
		;;
	'updown')
		router_status $2
		;;
	'show')
		client_status $2 $3
		;;
	'get')
		get_status $2
		;;
	'set')
		set_status $2
		;;
	*)
		usage
esac

#------------------------------------------------------------------------------#
