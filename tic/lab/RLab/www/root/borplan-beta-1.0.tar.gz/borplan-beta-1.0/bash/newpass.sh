#!/bin/sh
#
# $Id: newpass.sh,v 1.1.1.1 2006/02/28 14:35:39 sveronese Exp $
#
# borpLAN ~  newpass.sh 
# Script per il cambio password di un' area -
#-----------------------------------------------------------------------------#

# Includo il file di configurazione
source /usr/local/bin/borplan.conf

#--------------------Valori di default-----------------------------------#
DEF_LAB_NAME="new_lab"
DEF_USER="admin"
#-----------------------------------------------------------------------------#

#-------------------------Parte interattiva------------------------------#
echo "Cambio password per laboratorio:"
echo
echo "Nome laboratorio per cambio password"
echo -n "[$DEF_LAB_NAME]: "
read LAB_NAME
echo
echo "Utente Amministratore: "
echo -n "[$DEF_USER]"
read USER
echo
echo "Digitare Password: "
echo -n ""
read -s NEW_PWD
echo
echo "Ridigitare Password: "
echo -n ""
read -s CHECK_NEW_PWD
#-----------------------------------------------------------------------------#

#--------------------Parte non interattiva----------------------------#
if test -z "$LAB_NAME"
then
	LAB_NAME=$DEF_NEWLAB_NAME
fi

if test -z "$USER"
then
	USER=$DEF_USER
fi
#-----------------------------------------------------------------------------#

# Controlla se e' presente il laboratorio
if [ -d "$DOCROOT$LAB_NAME" ]
then
	if [ $NEW_PWD == $CHECK_NEW_PWD ]
	then
		cd /usr/local/bin/
		PASS=`php pass.php $NEW_PWD`
		#echo "$USER::$PASS"
		#echo $DOCROOT/$LAB_NAME/.passdb
		echo "$USER::$PASS" > $DOCROOT/$LAB_NAME/.passdb
		chown ${WEBUSER}:${WEBGROUP} ${DOCROOT}/$LAB_NAME/.passdb
		chmod 600 ${DOCROOT}/$LAB_NAME/.passdb
		
		echo "Modifica della password per $LAB_NAME  eseguita con successo"
	else
		echo "Le password non corrispondono"
	fi
else
	echo "Laboratorio $LAB_NAME non esistente"
fi
#-----------------------------------------------------------------------------#