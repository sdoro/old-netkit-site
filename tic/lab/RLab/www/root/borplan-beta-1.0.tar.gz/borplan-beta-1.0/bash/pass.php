#!/usr/bin/php
<?php
	
	#-----------------------------------------------------------------------------#
	# $Id: pass.php,v 1.1.1.1 2006/02/28 14:35:39 sveronese Exp $
	#
	# borpLAN ~  pass.php
	# Script php per il cambio password -
	#-----------------------------------------------------------------------------#

	if ($argc != 2 || in_array($argv[1], array('--help', '-help', '-h', '-?')))
	{
?>
	Ritorna la parola, passata come parametro, criptata
	Utilizzo:
	<?php echo $argv[0]; ?> <word>
<?php
	}
	else
	{
		$word = crypt($argv[1],"CACCA");
		echo $word;
		echo "\n";
	}
	
	#-----------------------------------------------------------------------------#
?>
