#!/bin/sh
#
# $Id: newlab.sh,v 1.1.1.1 2006/02/28 14:35:39 sveronese Exp $
#
# borpLAN ~  newlab.sh 
# Script d'installazione di una nuova area -
#-----------------------------------------------------------------------------#

# Includo il file di configurazione
source /usr/local/bin/borplan.conf

#--------------------Valori di default-----------------------------------#
DEF_NEWLAB_NAME="new_lab"
DEF_NEWLAB_AUTH="192.168.66.1"
DEF_NEWLAB_NETPREFIX="192.168.66."
DEF_NEWLAB_ROUTERIP="192.168.66.254"
DEF_NEWLAB_UID="admin"
#-----------------------------------------------------------------------------#

#-------------------------Parte interattiva------------------------------#
echo "Creazione nuova area per borpLAN: richiesta parametri fondamentali"
echo "(CTRL+C per terminare...)"
echo
echo "Nome del nuovo laboratorio"
echo -n "[$DEF_NEWLAB_NAME]: "
read NEWLAB_NAME
echo
echo "Specificare l'indirizzo abilitato ad accedere a borpLAN"
echo "Per specificare una lista di indirizzi, separarli con una virgola (192.168.66.1,192.168.66.2,ecc)"
echo -n "[$DEF_NEWLAB_AUTH]: "
read NEWLAB_AUTH
echo
echo "Prefisso di rete del laboratorio (specificare il . finale)"
echo -n "[$DEF_NEWLAB_NETPREFIX]: "
read NEWLAB_NETPREFIX
echo
echo "Indirizzo ip interfaccia del router sul backbone"
echo -n "[$DEF_NEWLAB_ROUTERIP]: "
read NEWLAB_ROUTERIP
echo
echo "Nome utente abilitato all'accesso al sistema:"
echo -n "[$DEF_NEWLAB_UID]: "
read NEWLAB_UID
echo
echo "Password: "
echo -n ""
read -s NEWLAB_PWD
echo
echo "Ripetere password: "
echo -n ""
read -s NEWLAB_PWD_CHECK
echo -n "...installazione albero delle directory..."
#-----------------------------------------------------------------------------#

#--------------------Parte non interattiva----------------------------#
if test -z "$NEWLAB_NAME"
then
	NEWLAB_NAME=$DEF_NEWLAB_NAME
fi

if test -z "$NEWLAB_AUTH"
then
	NEWLAB_AUTH=$DEF_NEWLAB_AUTH
fi

if test -z "$NEWLAB_NETPREFIX"
then
	NEWLAB_NETPREFIX=$DEF_NEWLAB_NETPREFIX
fi

if test -z "$NEWLAB_ROUTERIP"
then
	NEWLAB_ROUTERIP=$DEF_NEWLAB_ROUTERIP
fi

if test -z "$NEWLAB_UID"
then
	NEWLAB_UID=$DEF_NEWLAB_UID
fi

# Controlla se è già presente il laboratorio
if [ $NEW_PWD == $CHECK_NEW_PWD ]
then
	if [ ! -d "$DOCROOT/$NEWLAB_NAME" ]
	then
		mkdir $DOCROOT/$NEWLAB_NAME
		cp $DOCROOT/.skel/index.php $DOCROOT/$NEWLAB_NAME
		cp $DOCROOT/.skel/map.php.inc $DOCROOT/$NEWLAB_NAME
		cp $DOCROOT/.skel/services.php.inc $DOCROOT/$NEWLAB_NAME

		cd $DOCROOT/$NEWLAB_NAME
		touch config.php.inc 
	
		# Inizio stampa del file
		echo "<?php" > config.php.inc
	
		echo "/* DO NOT COMMENT THIS FILE !!! */" >> config.php.inc
		echo "/* DO NOT COMMENT THIS FILE !!! */" >> config.php.inc
		echo "\$lab_name = \"$NEWLAB_NAME\";" >> config.php.inc
		echo "\$authorized_ip = \"$NEWLAB_AUTH\";" >> config.php.inc
		echo "\$net_prefix = \"$NEWLAB_NETPREFIX\";" >> config.php.inc
		echo "\$router_ip = \"$NEWLAB_ROUTERIP\";" >> config.php.inc
		
		# Stampa l'array di porte e servizi di default
		# echo "\$services = array( '8080' , '21' , '22' , '23');" >> config.php.inc
		# echo "\$services_name = array( '8080' => 'proxy' , '21' => 'ftp' , '22' => 'ssh' , '23' => 'telnet');" >> config.php.inc
		
		# Fine stampa del file
		echo "?>" >> config.php.inc
		
		# Creazione del file di password
		touch .passdb
		CRYPT_PWD=`php /usr/local/bin/pass.php $NEWLAB_PWD`
		echo "$NEWLAB_UID::$CRYPT_PWD" > .passdb
		
		# Modifiche dei permessi
		chown ${WEBUSER}:${WEBGROUP} ${DOCROOT}/$NEWLAB_NAME -R
		chmod 600 ${DOCROOT}/$NEWLAB_NAME/.passdb
			
		echo
		echo "Creazione del nuovo laboratorio terminata."
		echo "E' gia' possibile accedere al proprio laboratorio con utente $NEWLAB_UID e la password configurata"
		# echo "Per aggiungere un utente eseguire il comando newuser.sh."
	else
		echo
		echo "Laboratorio gia' presente"
	fi
else
	echo
	echo "Le password non corrispondono"
fi
echo "terminata."
#-----------------------------------------------------------------------------#
