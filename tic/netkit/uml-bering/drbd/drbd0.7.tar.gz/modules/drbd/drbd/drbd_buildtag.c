/* automatically generated. DO NOT EDIT. */
const char * drbd_buildtag(void)
{
	return "SVN Revision: 1743"
		" build by phil@mescal, 2005-01-31 12:22:07";
}
