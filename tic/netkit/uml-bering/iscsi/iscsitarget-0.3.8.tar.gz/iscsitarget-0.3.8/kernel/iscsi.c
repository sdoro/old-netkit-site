/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <linux/module.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/file.h>
#include <linux/slab.h>
#include <linux/pagemap.h>
#include <linux/init.h>
#include <linux/compiler.h>
#include <asm/uaccess.h>

#include <net/sock.h>
#include <net/tcp.h>
#include <scsi/scsi.h>

#include "iscsi.h"
#include "iscsi_dbg.h"
#include "target.h"

#define STATUS_SHIFT		1

#ifndef REPORT_LUNS
#define REPORT_LUNS		0xa0
#endif

unsigned long debug_enable_flags;

static inline int iscsi_session_check_cmd_sn(struct iscsi_cmnd *cmnd);

static kmem_cache_t *iscsi_cmnd_cache;
static char dummy_data[1024];

struct iscsi_param default_iscsi_param = {
	.flags = (SESSION_FLG_INITIAL_RTT | SESSION_FLG_IMMEDIATEDATA
		  | SESSION_FLG_DATAPDUINORDER | SESSION_FLG_DATASEQUENCEINORDER),
	.max_connections = 1,
	.max_data_pdu_length = 8192,
	.max_burst_length = 262144,
	.first_burst_length = 65536,
	.default_wait_time = 2,
	.default_retain_time = 20,
	.max_outstanding_r2t = 1,
	.error_recovery_level = 0,
};

static int ctr_major;
static char ctr_name[] = "ietctl";
extern struct file_operations ctr_fops;

/*****************************************************************************/
/*                                   COMMAND                                 */
/*****************************************************************************/

/**
 * create a new command.
 *
 * iscsi_cmnd_create - 
 * @conn: ptr to connection (for i/o)
 *
 * @return    ptr to command or NULL
 */

struct iscsi_cmnd *iscsi_cmnd_create(struct iscsi_conn *conn)
{
	struct iscsi_cmnd *cmnd;

	do {
		cmnd = kmem_cache_alloc(iscsi_cmnd_cache, GFP_KERNEL);
		if (!cmnd)
			yield();
	} while (!cmnd);

	assert(cmnd);

	memset(cmnd, 0, sizeof(*cmnd));
	INIT_LIST_HEAD(&cmnd->pdu_list);
	INIT_LIST_HEAD(&cmnd->list);
	cmnd->conn = conn;
	cmnd->state = ISCSI_STATE_NEW;
	cmnd->func = NULL;
	spin_lock(&conn->list_lock);
	atomic_inc(&conn->nr_cmnds);
	list_add_tail(&cmnd->conn_list, &conn->pdu_list);
	spin_unlock(&conn->list_lock);

	dprintk(D_GENERIC, "%p:%p\n", conn, cmnd);

	return cmnd;
}

/**
 * create a new command used as response.
 *
 * iscsi_cmnd_create_rsp_cmnd - 
 * @cmnd: ptr to request command
 *
 * @return    ptr to response command or NULL
 */

struct iscsi_cmnd *iscsi_cmnd_create_rsp_cmnd(struct iscsi_cmnd *cmnd)
{
	struct iscsi_cmnd *rsp_cmnd = iscsi_cmnd_create(cmnd->conn);
	if (rsp_cmnd)
		list_add_tail(&rsp_cmnd->pdu_list, &cmnd->pdu_list);
	rsp_cmnd->req = cmnd;
	return rsp_cmnd;
}

/**
 * get ptr to request command, which belongs to this response.
 * NOTE: no error checking.
 *
 * iscsi_cmnd_get_req_cmnd - 
 * @rsp_cmnd: ptr to response command
 *
 * @return    ptr to request command
 */

inline struct iscsi_cmnd *iscsi_cmnd_get_req_cmnd(struct iscsi_cmnd *rsp_cmnd)
{
	struct iscsi_cmnd *req = rsp_cmnd->req;
/* 	return list_entry(rsp_cmnd->pdu_list.next, struct iscsi_cmnd, pdu_list); */
	assert(req);
	return req;
}

/**
 * get ptr to response command, which belongs to this request.
 * NOTE: no error checking.
 *
 * iscsi_cmnd_get_rsp_cmnd - 
 * @req_cmnd: ptr to request command
 *
 * @return    ptr to response comman
 */

inline struct iscsi_cmnd *iscsi_cmnd_get_rsp_cmnd(struct iscsi_cmnd *req_cmnd)
{
	return list_entry(req_cmnd->pdu_list.prev, struct iscsi_cmnd, pdu_list);
}

/**
 * Free a command.
 * Also frees the additional header.
 *
 * iscsi_cmnd_remove - 
 * @cmnd: ptr to command
 */

void iscsi_cmnd_remove(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn;

	if (!cmnd)
		return;
	dprintk(D_GENERIC, "%p\n", cmnd);
	conn = cmnd->conn;
	if (cmnd->pdu.ahs)
		kfree(cmnd->pdu.ahs);
	if (!list_empty(&cmnd->list)) {
		struct iscsi_scsi_cmd_hdr *req = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;

		eprintk("cmnd %p still on some list?, %x, %x, %x, %x, %x, %x, %x %x %lx\n",
			cmnd, req->opcode, req->scb[0], req->flags, req->itt,
			be32_to_cpu(req->data_length),
			req->cmd_sn, be32_to_cpu(cmnd->pdu.datasize), cmnd->state, conn->state);

		if (cmnd->req) {
			struct iscsi_scsi_cmd_hdr *req =
				(struct iscsi_scsi_cmd_hdr *)&cmnd->req->pdu.bhs;
			eprintk("%p %x %u\n", req, req->opcode, req->scb[0]);
		}
		dump_stack();
		BUG();
	}
	list_del(&cmnd->list);
	spin_lock(&conn->list_lock);
	atomic_dec(&conn->nr_cmnds);
	list_del(&cmnd->conn_list);
	spin_unlock(&conn->list_lock);

	kmem_cache_free(iscsi_cmnd_cache, cmnd);
}

/**
 * Stores the size of the additional header and data in the PDU.
 *
 * iscsi_cmnd_set_length
 * @pdu: ptr to pdu
 */

static inline void iscsi_cmnd_set_length(struct iscsi_pdu *pdu)
{
#if defined(__BIG_ENDIAN)
	pdu->bhs.length.ahslength = pdu->ahssize / 4;
	pdu->bhs.length.datalength = pdu->datasize;
#elif defined(__LITTLE_ENDIAN)
	pdu->bhs.length = cpu_to_be32(pdu->datasize) | (pdu->ahssize / 4);
#else
#error
#endif
}

static inline void iscsi_get_offset_and_length(struct iet_volume *lu, u8 *cmd,
					       loff_t *off, u32 *len)
{
	assert(lu);

	switch (cmd[0]) {
	case READ_6:
	case WRITE_6:
	{
		*off = ((cmd[1] & 0x1f) << 16) + (cmd[2] << 8) + cmd[3];
		*len = cmd[4];
		if (!*len)
			*len = 256;
		break;
	}
	case READ_10:
	case WRITE_10:
	{
		*off = be32_to_cpu(*(u32 *)&cmd[2]);
		*len = (cmd[7] << 8) + cmd[8];
		break;
	}
	default:
		BUG();
	}

	*off <<= lu->blk_shift;
	*len <<= lu->blk_shift;
}

u32 translate_lun(u16 * data)
{
	u8 *lun = (u8 *) data;
	u32 res;

	switch (*lun >> 6) {
	case 0:
		res = lun[1];
		break;
	case 1:
		res = (0x3f & lun[0]) << 8 | lun[1];
		break;
	case 2:
	case 3:
	default:
		eprintk("%u %u %u %u\n", data[0], data[1], data[2], data[3]);
		res = ~0UL;
		break;
	}

	return res;
}

/**
 * iscsi_cmnd_start_read - Start processing an iscsi command.
 * @cmnd: ptr to command
 *
 * Called from the read thread after pdu and the additional header has been read.
 * If more data needs to be read, conn->read_size must be set.
 */

void iscsi_cmnd_start_read(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;

	dprintk(D_GENERIC, "%p:%x\n", cmnd, cmnd_opcode(cmnd));
	iscsi_dump_pdu(&cmnd->pdu);

	if (cmnd->pdu.ahssize + cmnd->pdu.datasize + sizeof(struct iscsi_hdr) > conn->session->param.max_data_pdu_length) {
		// drop connection...
		/*
		 * An UNH initiator sends a PDU whose size is
		 * conn->session->param.max_data_pdu_length + iscsi
		 * header. Is it a bug?
		 */
	}

	switch (cmnd->pdu.bhs.opcode & ISCSI_OPCODE_MASK) {
	case ISCSI_OP_NOOP_OUT:
	{
		u32 size, tmp;
		int i;

		if (cmnd->pdu.bhs.ttt != cpu_to_be32(ISCSI_RESERVED_TAG)) {
			/*
			 * We don't request a NOP-Out by sending a NOP-In.
			 * See 10.18.2 in the draft 20.
			 */
			printk("%s (%d): initiator bug!\n", __FUNCTION__, __LINE__);
		}
		if (cmnd->pdu.bhs.itt == cpu_to_be32(ISCSI_RESERVED_TAG)) {
			if (!(cmnd->pdu.bhs.opcode & ISCSI_OP_IMMEDIATE))
				printk("%s (%d): initiator bug!\n", __FUNCTION__, __LINE__);
			iscsi_conn_update_stat_sn(cmnd);
			iscsi_session_check_cmd_sn(cmnd);
			break;
		} else if (!iscsi_session_insert_cmnd(cmnd)) {
			printk("%s (%d) ignore this request\n", __FUNCTION__, __LINE__);
			break;
		}
		if ((size = cmnd->pdu.datasize)) {
			size = (size + 3) & -4;
			conn->read_msg.msg_iov = conn->read_iov;
			if (cmnd->pdu.bhs.itt != cpu_to_be32(ISCSI_RESERVED_TAG)) {
				struct target_cmnd *tcmnd;
				int pg_cnt;

				pg_cnt = min_t(int, (size + PAGE_SIZE - 1) >> PAGE_SHIFT,
					       ISCSI_CONN_IOV_MAX);

				tcmnd = target_cmnd_alloc();
				target_alloc_pages(tcmnd, pg_cnt);
				tcmnd->size =
					min_t(u32, size, ISCSI_CONN_IOV_MAX << PAGE_SHIFT);

				for (i = 0; i < pg_cnt; i++) {
					conn->read_iov[i].iov_base
						= page_address(tcmnd->pvec[i]);
					tmp = min_t(u32, size, PAGE_SIZE);
					conn->read_iov[i].iov_len = tmp;
					conn->read_size += tmp;
					size -= tmp;
				}
				cmnd->data = tcmnd;
			} else {
				for (i = 0; i < ISCSI_CONN_IOV_MAX; i++) {
					conn->read_iov[i].iov_base = dummy_data;
					tmp = min_t(u32, size, sizeof(dummy_data));
					conn->read_iov[i].iov_len = tmp;
					conn->read_size += tmp;
					size -= tmp;
				}
			}
			conn->read_overflow = size;
			conn->read_msg.msg_iovlen = i;
		}
		break;
	}
	case ISCSI_OP_SCSI_CMD:
	{
		struct iscsi_scsi_cmd_hdr *req = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;
		struct target_cmnd *tcmnd;

		if (!iscsi_session_insert_cmnd(cmnd))
			break;

		cmnd->lun = iet_volume_lookup(conn->session->target, translate_lun(req->lun));
		cmnd->data = tcmnd = target_cmnd_alloc();

		dprintk(D_GENERIC, "scsi command: %02x\n", req->scb[0]);
		if (cmnd->lun == NULL) {
			switch (req->scb[0]) {
			case INQUIRY:
			case REPORT_LUNS:
				break;
			default:
				iscsi_cmnd_sense_rsp(cmnd, ILLEGAL_REQUEST, 0x25, 0x0);
				iscsi_cmnd_ignore_data(cmnd);
				return;
			}
		}

		switch (req->scb[0]) {
		case INQUIRY:
		case REPORT_LUNS:
		case TEST_UNIT_READY:
		case VERIFY:
		case START_STOP:
		case READ_CAPACITY:
		case MODE_SENSE:
		case REQUEST_SENSE:
		case RESERVE:
		case RELEASE:
		case RESERVE_10:
		case RELEASE_10:
		{
			if (!(req->flags & ISCSI_CMD_FINAL) || cmnd->pdu.datasize) {
				/* unexpected unsolicited data */
				iscsi_cmnd_sense_rsp(cmnd, ABORTED_COMMAND, 0xc, 0xc);
				iscsi_cmnd_ignore_data(cmnd);
			}
			break;
		}
		case READ_6:
		case READ_10:
		{
			loff_t offset;
			u32 length;

			if (!(req->flags & ISCSI_CMD_FINAL) || cmnd->pdu.datasize) {
				/* unexpected unsolicited data */
				iscsi_cmnd_sense_rsp(cmnd, ABORTED_COMMAND, 0xc, 0xc);
				iscsi_cmnd_ignore_data(cmnd);
			}

			iscsi_get_offset_and_length(cmnd->lun, req->scb, &offset, &length);
			target_init_iocmnd(tcmnd, offset, length);
			break;
		}
		case WRITE_6:
		case WRITE_10:
		{
			loff_t offset;
			u32 length;
#if 0
			if (!(conn->session->param.flags & SESSION_FLG_IMMEDIATEDATA) &&
			    cmnd->pdu.datasize) {
			}
			if ((conn->session->param.flags & SESSION_FLG_INITIAL_RTT) &&
			    !(req->flags & ISCSI_CMD_FINAL)) {
			}
#endif
			iscsi_get_offset_and_length(cmnd->lun, req->scb, &offset, &length);
			target_init_iocmnd(tcmnd, offset, length);

			target_alloc_pages(tcmnd, tcmnd->pg_cnt);

			if (cmnd->pdu.datasize) {
				iscsi_cmnd_receive_pdu(conn, tcmnd, 0, cmnd->pdu.datasize);
			}
			break;
		}
		default:
			iscsi_cmnd_sense_rsp(cmnd, ILLEGAL_REQUEST, 0x20, 0x0);
			iscsi_cmnd_ignore_data(cmnd);
			break;
		}
		break;
	}
	case ISCSI_OP_SCSI_TASK_MGT_MSG:
		printk("%s, %d: ISCSI_OP_SCSI_TASK_MGT_MSG\n" ,__FUNCTION__, __LINE__);
		iscsi_session_insert_cmnd(cmnd);
		break;
	case ISCSI_OP_LOGIN_CMD:
		iscsi_cmnd_reject(cmnd, ISCSI_REASON_UNSUPPORTED_COMMAND);
		break;
	case ISCSI_OP_TEXT_CMD:
		eprintk("Not implemented yet %x\n", cmnd->pdu.bhs.itt);
		iscsi_cmnd_reject(cmnd, ISCSI_REASON_UNSUPPORTED_COMMAND);
/* 		iscsi_session_insert_cmnd(cmnd); */
		break;
	case ISCSI_OP_SCSI_DATA_OUT:
	{
		struct iscsi_data_out_hdr *req = (struct iscsi_data_out_hdr *)&cmnd->pdu.bhs;
		struct iscsi_cmnd *scsi_cmnd = NULL;
		u32 offset = be32_to_cpu(req->buffer_offset);

		iscsi_conn_update_stat_sn(cmnd);
		if (req->ttt == cpu_to_be32(ISCSI_RESERVED_TAG)) {
			BUG();
			/* unsolicited burst data */
			scsi_cmnd = iscsi_session_find_cmnd(conn->session, req->itt);
			if (!scsi_cmnd) {
				printk("unable to find scsi task %x\n", req->itt);
				goto skip_data;
			}
			if (scsi_cmnd->pdu.bhs.flags & ISCSI_FLG_FINAL) {
				printk("unexpected data from %x\n", req->itt);
				goto skip_data;
			}
			cmnd->data = scsi_cmnd;
		} else {
			scsi_cmnd = iscsi_session_find_ttt(conn->session, req->ttt);
			if (!scsi_cmnd) {
				printk("unable to find r2t task %x\n", req->ttt);
				goto skip_data;
			}
			cmnd->data = scsi_cmnd;
			scsi_cmnd = scsi_cmnd->data;
		}

		dprintk(D_WRITE, "%u %p %p %p %u %u\n", req->ttt, cmnd, scsi_cmnd,
			scsi_cmnd->data, offset, cmnd->pdu.datasize);

		// CHECKME!
		iscsi_cmnd_receive_pdu(conn, scsi_cmnd->data, offset, cmnd->pdu.datasize);
		break;
	skip_data:
		// reject? FIXME
		cmnd->data = NULL;
		cmnd->pdu.bhs.opcode = ISCSI_OP_DATA_REJECT;
		iscsi_cmnd_skip_pdu(cmnd);
		break;
	}
	case ISCSI_OP_LOGOUT_CMD:
		iscsi_session_insert_cmnd(cmnd);
		break;
	case ISCSI_OP_SNACK_CMD:
		eprintk("Not implemented yet %x\n", cmnd->pdu.bhs.itt);
		iscsi_cmnd_reject(cmnd, ISCSI_REASON_UNSUPPORTED_COMMAND);
/* 		iscsi_conn_update_stat_sn(cmnd); */
		break;
	default:
		iscsi_cmnd_reject(cmnd, ISCSI_REASON_UNSUPPORTED_COMMAND);
		break;
	}
}

void iscsi_handle_iorequest(struct iscsi_cmnd *cmnd)
{
	dprintk(D_WRITE, "%p:%x\n", cmnd, cmnd_opcode(cmnd));

	target_commit_pages(cmnd->lun, cmnd->data);
	cmnd->state = ISCSI_STATE_WAIT_COMMIT;

	target_sync_pages(cmnd->lun, cmnd->data);
	cmnd->state = ISCSI_STATE_SEND_RSP;

	{
		struct iscsi_cmnd *rsp_cmnd;
		list_for_each_entry(rsp_cmnd, &cmnd->pdu_list, pdu_list) {
			if (rsp_cmnd->pdu.bhs.opcode != ISCSI_OP_SCSI_RSP)
				printk("%s, %d: BUG?\n", __FUNCTION__, __LINE__);
		}
	}

	iscsi_cmnd_init_write(iscsi_cmnd_get_rsp_cmnd(cmnd));
}

/**
 * Continue processing an iscsi command.
 * Called from the read thread after data has been read.
 * If more data needs to be read, conn->read_size must be set,
 * otherwise command is usually prepared for execution.
 *
 * iscsi_cmnd_finish_read - 
 * @cmnd: ptr to command
 */

void iscsi_cmnd_finish_read(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;

	dprintk(D_GENERIC, "%p:%x\n", cmnd, cmnd_opcode(cmnd));
	switch (cmnd->pdu.bhs.opcode & ISCSI_OPCODE_MASK) {
	case ISCSI_OP_NOOP_OUT:
	{
		u32 size, tmp;
		int i;

		size = conn->read_overflow;
		if (size) {
			conn->read_msg.msg_iov = conn->read_iov;
			for (i = 0; size && i < ISCSI_CONN_IOV_MAX; i++) {
				conn->read_iov[i].iov_base = dummy_data;
				tmp = min_t(u32, size, sizeof(dummy_data));
				conn->read_iov[i].iov_len = tmp;
				conn->read_size += tmp;
				size -= tmp;
			}
			conn->read_size = (conn->read_size + 3) & -4;
			conn->read_overflow = size;
			conn->read_msg.msg_iovlen = i;
		} else
			iscsi_session_push_cmnd(cmnd);
		break;
	}

	case ISCSI_OP_SCSI_CMD:
		iscsi_session_push_cmnd(cmnd);
		break;
	case ISCSI_OP_SCSI_TASK_MGT_MSG:
		iscsi_session_push_cmnd(cmnd);
		break;
	case ISCSI_OP_TEXT_CMD:
		iscsi_session_push_cmnd(cmnd);
		break;
	case ISCSI_OP_SCSI_DATA_OUT:
	{
		struct iscsi_data_out_hdr *req;
		struct iscsi_cmnd *r2t_cmnd;
		struct iscsi_cmnd *scsi_cmnd;
		struct iscsi_cmnd *rsp_cmnd;
		struct iscsi_scsi_rsp_hdr *rsp;
		u32 size, offset;

		req = (struct iscsi_data_out_hdr *)&cmnd->pdu.bhs;
		if (req->ttt == cpu_to_be32(ISCSI_RESERVED_TAG)) {
			BUG();
			scsi_cmnd = cmnd->data;
			if (conn->read_overflow) {
				offset = be32_to_cpu(req->buffer_offset);
				offset += cmnd->pdu.datasize - conn->read_overflow;
				iscsi_cmnd_receive_pdu(conn, scsi_cmnd->data, offset, conn->read_overflow);
				break;
			}

			if (req->flags & ISCSI_FLG_FINAL) {
				switch (scsi_cmnd->state) {
				case ISCSI_STATE_PUSHED:
					scsi_cmnd->pdu.bhs.flags |= ISCSI_FLG_FINAL;
					break;
				case ISCSI_STATE_QUEUED:
					//lock
					//check
					scsi_cmnd->pdu.bhs.flags |= ISCSI_FLG_FINAL;
					//unlock
					break;
				case ISCSI_STATE_WAIT_RECEIVE:
					//list_del_init(&cmnd->list);
					scsi_cmnd->pdu.bhs.flags |= ISCSI_FLG_FINAL;
					iscsi_device_queue_cmnd(scsi_cmnd);
					break;
				}
			}

			iscsi_cmnd_remove(cmnd);
			break;
		}
		r2t_cmnd = cmnd->data;
		if (!r2t_cmnd)
			break;
		scsi_cmnd = r2t_cmnd->data;
		if (conn->read_overflow) {
			offset = be32_to_cpu(req->buffer_offset);
			offset += cmnd->pdu.datasize - conn->read_overflow;
			iscsi_cmnd_receive_pdu(conn, scsi_cmnd->data, offset, conn->read_overflow);
			break;
		}

		if (!(req->flags & ISCSI_FLG_FINAL)) {
			iscsi_cmnd_remove(cmnd);
			break;
		}
		iscsi_session_remove_ttt(r2t_cmnd);

		if (!list_empty(&scsi_cmnd->pdu_list)) {
			iscsi_cmnd_remove(cmnd);
			break;
		}

		/* It's time to remove the root scsi_cmnd. */

		rsp_cmnd = iscsi_cmnd_scsi_rsp(scsi_cmnd);
		rsp = (struct iscsi_scsi_rsp_hdr *)&rsp_cmnd->pdu.bhs;

		if (!list_empty(&scsi_cmnd->list))
			printk("%s %p BUG?\n", __FUNCTION__, scsi_cmnd);

		list_del_init(&scsi_cmnd->list);
		size = iscsi_cmnd_read_size(cmnd);
		if (size) {
			rsp->flags |= ISCSI_FLG_RESIDUAL_UNDERFLOW;
			rsp->residual_count = cpu_to_be32(size);
		}

		iscsi_cmnd_remove(cmnd);
 		queue_cmnd(scsi_cmnd, iscsi_handle_iorequest);
		break;
	}
	case ISCSI_OP_LOGOUT_CMD:
		iscsi_session_push_cmnd(cmnd);
		break;
	case ISCSI_OP_SNACK_CMD:
		break;
	case ISCSI_OP_SCSI_REJECT:
		target_free_pages(cmnd->data);
		cmnd->data = NULL;
		iscsi_session_push_cmnd(cmnd);
		break;
	case ISCSI_OP_PDU_REJECT: {
		/* rejected cmnd must not be pushed, so exp_cmd_sn doesn't increase */
		struct iscsi_cmnd *rsp_cmnd = iscsi_cmnd_get_rsp_cmnd(cmnd);
		target_free_pages(cmnd->data);
		cmnd->data = NULL;

		iscsi_cmnd_init_write(rsp_cmnd);
		break;
	}
	case ISCSI_OP_DATA_REJECT:
		iscsi_cmnd_release(cmnd);
		break;
	default:
		printk("iscsi_cmnd_finish_read: unexpected cmnd op %x\n", cmnd_opcode(cmnd));
		break;
	}
}

static void handle_management_functions(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;
	struct iscsi_cmnd *rsp_cmnd;
	struct iscsi_task_mgt_hdr *req = (struct iscsi_task_mgt_hdr *)&cmnd->pdu.bhs;
	struct iscsi_task_rsp_hdr *rsp;
	int function;

	eprintk("%p: %x %x %x\n", cmnd, cmnd_opcode(cmnd),
		cmnd->pdu.bhs.sn, req->function & ISCSI_FUNCTION_MASK);
	{
		struct iscsi_cmnd *cmnd;
		dprintk(D_TASK_MGT, "task management command: %x\n", req->function);
		list_for_each_entry(cmnd, &conn->session->pending_list, list) {
			dprintk(D_TASK_MGT, "%p: %u %u\n", cmnd, cmnd_opcode(cmnd),
					cmnd->pdu.bhs.sn);
		}
	}

	rsp_cmnd = iscsi_cmnd_create_rsp_cmnd(cmnd);
	rsp = (struct iscsi_task_rsp_hdr *)&rsp_cmnd->pdu.bhs;

	rsp->opcode = ISCSI_OP_SCSI_TASK_MGT_RSP;
	rsp->flags = ISCSI_FLG_FINAL;
	rsp->itt = req->itt;

	function = req->function & ISCSI_FUNCTION_MASK;

	/* Not implemented properly yet. */
	rsp->response = ISCSI_RESPONSE_FUNCTION_UNSUPPORTED;

#if 0
	switch (function) {
	case ISCSI_FUNCTION_ABORT_TASK:
	case ISCSI_FUNCTION_ABORT_TASK_SET:
	case ISCSI_FUNCTION_CLEAR_ACA:
	case ISCSI_FUNCTION_CLEAR_TASK_SET:
	case ISCSI_FUNCTION_LOGICAL_UNIT_RESET:
		lun = target_lookup_lun(conn->session->target, be16_to_cpu(req->lun[0]));
		if (!lun)
			rsp->response = ISCSI_RESPONSE_UNKNOWN_LUN;
	}

	if (!rsp->response) switch (function) {
	case ISCSI_FUNCTION_ABORT_TASK:
		//rsp->response = ISCSI_RESPONSE_UNKNOWN_TASK;
		rsp->response = ISCSI_RESPONSE_FUNCTION_COMPLETE;
		break;
	case ISCSI_FUNCTION_ABORT_TASK_SET:
		rsp->response = ISCSI_RESPONSE_FUNCTION_REJECTED;
		break;
	case ISCSI_FUNCTION_CLEAR_ACA:
		rsp->response = ISCSI_RESPONSE_FUNCTION_REJECTED;
		break;
	case ISCSI_FUNCTION_CLEAR_TASK_SET:
		rsp->response = ISCSI_RESPONSE_FUNCTION_REJECTED;
		break;
	case ISCSI_FUNCTION_LOGICAL_UNIT_RESET:
		// TODO
		rsp->response = ISCSI_RESPONSE_FUNCTION_COMPLETE;
		//rsp->response = ISCSI_RESPONSE_FUNCTION_REJECTED;
		break;
	case ISCSI_FUNCTION_TARGET_WARM_RESET:
		// TODO
		rsp->response = ISCSI_RESPONSE_FUNCTION_COMPLETE;
		//iscsi_conn_closefd_nolock(conn);
		break;
	case ISCSI_FUNCTION_TARGET_COLD_RESET:
		// TODO
		printk("%s(%d): cold reset \n",__FUNCTION__, __LINE__);
		rsp->response = ISCSI_RESPONSE_FUNCTION_COMPLETE;
		iet_conn_close(conn);
		break;
	case ISCSI_FUNCTION_TASK_REASSIGN:
		rsp->response = ISCSI_RESPONSE_FUNCTION_REJECTED;
		break;
	default:
		rsp->response = ISCSI_RESPONSE_FUNCTION_REJECTED;
		break;
	}
#endif

	iscsi_cmnd_init_write(rsp_cmnd);
}

/**
 * Execute an iscsi command.
 * Called from the read thread and commands are executed here in the right order.
 *
 * iscsi_cmnd_execute - 
 * @cmnd: ptr to command
 */

void iscsi_cmnd_execute(struct iscsi_cmnd *cmnd)
{
	struct iscsi_cmnd *rsp_cmnd;

	dprintk(D_GENERIC, "%p,%x,%u\n", cmnd, cmnd_opcode(cmnd), cmnd->pdu.bhs.sn);

	switch (cmnd->pdu.bhs.opcode & ISCSI_OPCODE_MASK) {
	case ISCSI_OP_NOOP_OUT:
	{
		struct iscsi_nop_in_hdr *rsp;
		if (cmnd->pdu.bhs.itt != cpu_to_be32(ISCSI_RESERVED_TAG)) {
			rsp_cmnd = iscsi_cmnd_create_rsp_cmnd(cmnd);

			rsp = (struct iscsi_nop_in_hdr *)&rsp_cmnd->pdu.bhs;
			rsp->opcode = ISCSI_OP_NOOP_IN;
			rsp->flags = ISCSI_FLG_FINAL;
			rsp->itt = cmnd->pdu.bhs.itt;
			rsp->ttt = cpu_to_be32(ISCSI_RESERVED_TAG);

			rsp_cmnd->data = cmnd->data;
			cmnd->data = NULL;
			rsp_cmnd->pdu.datasize = min_t(u32, cmnd->pdu.datasize,
						       ISCSI_CONN_IOV_MAX << PAGE_SHIFT);
			iscsi_cmnd_init_write(rsp_cmnd);
		} else
			iscsi_cmnd_remove(cmnd);
		break;
	}
	case ISCSI_OP_SCSI_CMD:
	{
		if (cmnd->state != ISCSI_STATE_READ && cmnd->state != ISCSI_STATE_PUSHED)
			eprintk("unexpected state %d of cmnd %p\n", cmnd->state, cmnd);
		if (cmnd->lun)
			iscsi_scsi_queuecmnd(cmnd);
		else {
			/* force queued status */
			iscsi_dump_pdu(&cmnd->pdu);
			cmnd->state = ISCSI_STATE_QUEUED;
			iscsi_scsi_execute(cmnd);
		}
		break;
	}
	case ISCSI_OP_SCSI_TASK_MGT_MSG:
		handle_management_functions(cmnd);
		break;
	case ISCSI_OP_TEXT_CMD:
		break;
	case ISCSI_OP_LOGOUT_CMD:
	{
		struct iscsi_logout_req_hdr *req = (struct iscsi_logout_req_hdr *)&cmnd->pdu.bhs;
		struct iscsi_logout_rsp_hdr *rsp;

		rsp_cmnd = iscsi_cmnd_create_rsp_cmnd(cmnd);
		if (!rsp_cmnd)
			/* close connection */;
		rsp = (struct iscsi_logout_rsp_hdr *)&rsp_cmnd->pdu.bhs;
		rsp->opcode = ISCSI_OP_LOGOUT_RSP;
		rsp->flags = ISCSI_FLG_FINAL;
		rsp->itt = req->itt;
		iscsi_cmnd_init_write(rsp_cmnd);
		break;
	}
	case ISCSI_OP_SNACK_CMD:
		break;
	case ISCSI_OP_SCSI_REJECT:
		rsp_cmnd = iscsi_cmnd_get_rsp_cmnd(cmnd);
		iscsi_cmnd_init_write(rsp_cmnd);
		break;
	default:
		eprintk("unexpected cmnd op %x\n", cmnd_opcode(cmnd));
		break;
	}
}

void iscsi_cmnds_init_write(struct list_head *send)
{
	struct iscsi_cmnd *cmnd = list_entry(send->next, struct iscsi_cmnd, list);
	struct iscsi_conn *conn = cmnd->conn;
	struct list_head *pos, *next;

	spin_lock(&conn->list_lock);

	list_for_each_safe(pos, next, send) {
		cmnd = list_entry(pos, struct iscsi_cmnd, list);

		dprintk(D_GENERIC, "%p:%x\n", cmnd, cmnd_opcode(cmnd));

		list_del_init(&cmnd->list);

		assert(conn == cmnd->conn);

		cmnd->state = ISCSI_STATE_WRITE;
		list_add_tail(&cmnd->list, &conn->write_list);
	}

	spin_unlock(&conn->list_lock);

	wake_up_itargetd(conn->session->target);
}

/**
 * Schedules an iscsi command for writing.
 *
 * iscsi_cmnd_init_write - 
 * @cmnd: ptr to command
 */

void iscsi_cmnd_init_write(struct iscsi_cmnd *cmnd)
{
	LIST_HEAD(head);

	assert(list_empty(&cmnd->list));
	list_add(&cmnd->list, &head);
	iscsi_cmnds_init_write(&head);
}


void cmnd_send_pdu(struct iscsi_conn *conn, struct iscsi_cmnd *cmnd)
{
	u32 size;
	struct target_cmnd *tcmnd;

	if (!cmnd->pdu.datasize)
		return;

	size = (cmnd->pdu.datasize + 3) & -4;
	tcmnd = cmnd->data;
	assert(tcmnd);
	assert(tcmnd->size == size);
	iscsi_cmnd_send_pdu(conn, cmnd->data, 0, size);
}

void set_cork(struct socket *sock, int on)
{
	int opt = on;
	mm_segment_t oldfs;

	oldfs = get_fs();
	set_fs(get_ds());
	sock->ops->setsockopt(sock, SOL_TCP, TCP_CORK, (void *)&opt, sizeof(opt));
	set_fs(oldfs);
}

/**
 * Start writing of an iscsi command.
 * Initializes conn->write_*.
 * Called from the write thread.
 *
 * iscsi_cmnd_start_write - 
 * @cmnd: ptr to command
 */

void iscsi_cmnd_start_write(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;
	struct iovec *iop;

	dprintk(D_GENERIC, "%p:%x\n", cmnd, cmnd_opcode(cmnd));
	assert(cmnd);
	iscsi_cmnd_set_length(&cmnd->pdu);

	set_cork(conn->sock, 1);

	conn->write_iop = iop = conn->write_iov;
	iop->iov_base = &cmnd->pdu.bhs;
	iop->iov_len = sizeof(cmnd->pdu.bhs);
	iop++;
	conn->write_size = sizeof(cmnd->pdu.bhs);

	switch (cmnd->pdu.bhs.opcode) {
	case ISCSI_OP_NOOP_IN: {
		iscsi_cmnd_set_sn(cmnd, 1);
		cmnd_send_pdu(conn, cmnd);
		break;
	}
	case ISCSI_OP_SCSI_RSP:
		iscsi_cmnd_set_sn(cmnd, 1);
		cmnd_send_pdu(conn, cmnd);
		break;
	case ISCSI_OP_SCSI_TASK_MGT_RSP:
		iscsi_cmnd_set_sn(cmnd, 1);
		break;
	case ISCSI_OP_TEXT_RSP:
		iscsi_cmnd_set_sn(cmnd, 1);
		break;
	case ISCSI_OP_SCSI_DATA_IN:
	{
		struct iscsi_data_in_hdr *rsp = (struct iscsi_data_in_hdr *)&cmnd->pdu.bhs;
		u32 offset;

		iscsi_cmnd_set_sn(cmnd, (rsp->flags & ISCSI_FLG_FINAL) ? 1 : 0);
		offset = rsp->buffer_offset;
		rsp->buffer_offset = cpu_to_be32(offset);
		iscsi_cmnd_send_pdu(conn, cmnd->data, offset, cmnd->pdu.datasize);
		break;
	}
	case ISCSI_OP_LOGOUT_RSP:
		iscsi_cmnd_set_sn(cmnd, 1);
		break;
	case ISCSI_OP_R2T:
		iscsi_cmnd_set_sn(cmnd, 0);
		cmnd->pdu.bhs.sn = cpu_to_be32(conn->stat_sn);
		break;
	case ISCSI_OP_ASYNC_MSG:
		iscsi_cmnd_set_sn(cmnd, 1);
		break;
	case ISCSI_OP_REJECT:
		iscsi_cmnd_set_sn(cmnd, 1);
		cmnd_send_pdu(conn, cmnd);
		break;
	default:
		eprintk("unexpected cmnd op %x\n", cmnd_opcode(cmnd));
		break;
	}

	iop->iov_len = 0;
	// move this?
	conn->write_size = (conn->write_size + 3) & -4;
	iscsi_dump_pdu(&cmnd->pdu);
}

/**
 * Finish writing of an iscsi command.
 * If more data needs to be written, set conn->write_size & co.
 *
 * iscsi_cmnd_finish_write - 
 * @cmnd: ptr to command
 */

void iscsi_cmnd_finish_write(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;

	dprintk(D_GENERIC, "%p:%x\n", cmnd, cmnd_opcode(cmnd));
	switch (cmnd->pdu.bhs.opcode) {
	case ISCSI_OP_NOOP_IN:
	case ISCSI_OP_SCSI_RSP:
	case ISCSI_OP_SCSI_TASK_MGT_RSP:
	case ISCSI_OP_TEXT_RSP:
		break;
	case ISCSI_OP_SCSI_DATA_IN:
		break;
	case ISCSI_OP_LOGOUT_RSP:
		dprintk(D_GENERIC, "%u\n", conn->cid);
		iet_conn_close(conn);
		break;
	case ISCSI_OP_R2T:
	case ISCSI_OP_ASYNC_MSG:
	case ISCSI_OP_REJECT:
		break;
	default:
		eprintk("unexpected cmnd op %x\n", cmnd_opcode(cmnd));
		break;
	}
	if (!cmnd->conn->write_size) {
		cmnd->state = ISCSI_STATE_WRITE_DONE;
		list_del_init(&cmnd->list);
		set_cork(conn->sock, 0);
	}
}

void iscsi_cmnd_release(struct iscsi_cmnd *cmnd)
{
	struct iscsi_cmnd *req_cmnd;
	int opcode = cmnd->pdu.bhs.opcode & ISCSI_OPCODE_MASK;

	dprintk(D_GENERIC, "%p:%x\n", cmnd, opcode);
	switch (opcode) {
	case ISCSI_OP_NOOP_IN:
		target_free_pages(cmnd->data);
		req_cmnd = iscsi_cmnd_get_req_cmnd(cmnd);
		iscsi_session_remove_cmnd(req_cmnd);
		break;
	case ISCSI_OP_SCSI_CMD:
	case ISCSI_OP_SCSI_ABORT:
	{
		struct iscsi_scsi_cmd_hdr *req;

		req = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;
		switch (req->scb[0]) {
		case WRITE_6:
		case WRITE_10:
		case READ_6:
		case READ_10:
			target_free_pages(cmnd->data);
			break;
		case INQUIRY:
		case REPORT_LUNS:
		case READ_CAPACITY:
		case MODE_SENSE:
		case REQUEST_SENSE:
			target_free_pages(cmnd->data);
			break;
		case START_STOP:
		case TEST_UNIT_READY:
		case VERIFY:
		case RESERVE:
		case RELEASE:
		case RESERVE_10:
		case RELEASE_10:
			break;
		default: {
			static int cnt = 5;
			if (cnt > 0) {
				cnt--;
				printk("iscsi_cmnd_release: unexpected scsi data cmnd %x:%x!\n",
				       cmnd_opcode(cmnd), req->scb[0]);
			}
		}
			break;
		}
		if (!list_empty(&cmnd->pdu_list))
			printk("iscsi_cmnd_release: pdu list not empty!\n");
		iscsi_scsi_dequeuecmnd(cmnd);
		iscsi_session_remove_cmnd(cmnd);
		break;
	}
	case ISCSI_OP_SCSI_REJECT:
		iscsi_session_remove_cmnd(cmnd);
		break;
	case ISCSI_OP_SCSI_RSP:
		req_cmnd = iscsi_cmnd_get_req_cmnd(cmnd);
		list_del_init(&cmnd->pdu_list);
		target_free_pages(cmnd->data);
		iscsi_cmnd_remove(cmnd);
		iscsi_cmnd_release(req_cmnd);
		break;
	case ISCSI_OP_SCSI_TASK_MGT_RSP:
		req_cmnd = iscsi_cmnd_get_req_cmnd(cmnd);
		if (cmnd_opcode(req_cmnd) != ISCSI_OP_SCSI_TASK_MGT_MSG)
			eprintk("unexpected scsi cmnd %x!\n", cmnd_opcode(req_cmnd));

		iscsi_session_remove_cmnd(req_cmnd);
		break;
	case ISCSI_OP_TEXT_RSP:
		list_del_init(&cmnd->list);
		iscsi_session_remove_cmnd(iscsi_cmnd_get_req_cmnd(cmnd));
		break;
	case ISCSI_OP_SCSI_DATA_IN:
	{
		struct iscsi_data_in_hdr *rsp;

		rsp = (struct iscsi_data_in_hdr *)&cmnd->pdu.bhs;
		req_cmnd = iscsi_cmnd_get_req_cmnd(cmnd);
		list_del_init(&cmnd->pdu_list);
		if (cmnd->pdu.bhs.flags & ISCSI_FLG_FINAL)
			iscsi_cmnd_release(req_cmnd);
		iscsi_cmnd_remove(cmnd);
		break;
	}
	case ISCSI_OP_LOGOUT_RSP:
		iscsi_session_remove_cmnd(iscsi_cmnd_get_req_cmnd(cmnd));
		break;
	case ISCSI_OP_R2T:
		break;
	case ISCSI_OP_ASYNC_MSG:
		iscsi_cmnd_remove(cmnd);
		break;
	case ISCSI_OP_REJECT:
		target_free_pages(cmnd->data);
		iscsi_session_remove_cmnd(iscsi_cmnd_get_req_cmnd(cmnd));
		break;
	case ISCSI_OP_DATA_REJECT:
		target_free_pages(cmnd->data);
		iscsi_cmnd_remove(cmnd);
		break;
	default:
		eprintk("unexpected cmnd op %x\n", opcode);
		break;
	}
}


/**
 * Reject an iscsi command.
 * Reads remaining data and sends a reject response.
 * Called from iscsi_cmnd_start_read.
 *
 * iscsi_cmnd_reject - 
 * @cmnd: ptr to command to reject
 * @reason: reason for reject (see ISCSI_REASON_*)
 */

void iscsi_cmnd_reject(struct iscsi_cmnd *cmnd, int reason)
{
	struct iscsi_cmnd *rej_cmnd;
	struct iscsi_reject_hdr *rsp;
	struct target_cmnd *tcmnd;
	char *addr;

	rej_cmnd = iscsi_cmnd_create_rsp_cmnd(cmnd);
	if (!rej_cmnd)
		/* close connection */;
	rsp = (struct iscsi_reject_hdr *)&rej_cmnd->pdu.bhs;

	rsp->opcode = ISCSI_OP_REJECT;
	rsp->ffffffff = ISCSI_RESERVED_TAG;
	rsp->reason = reason;

	tcmnd = target_cmnd_alloc();

	target_alloc_pages(tcmnd, 1);
	addr = page_address(tcmnd->pvec[0]);
	clear_page(addr);
	memcpy(addr, &cmnd->pdu.bhs, sizeof(struct iscsi_hdr));
	tcmnd->size = rej_cmnd->pdu.datasize = sizeof(struct iscsi_hdr);
	rej_cmnd->data = tcmnd;
	iscsi_cmnd_skip_pdu(cmnd);

	cmnd->pdu.bhs.opcode = ISCSI_OP_PDU_REJECT;
}

/**
 * Create a iscsi response command for a successfull scsi command.
 *
 * iscsi_cmnd_scsi_rsp - 
 * @scsi_cmnd: ptr to scsi command
 *
 * @return    ptr to scsi response or NULL
 */

struct iscsi_cmnd *iscsi_cmnd_scsi_rsp(struct iscsi_cmnd *scsi_cmnd)
{
	struct iscsi_cmnd *cmnd;
	struct iscsi_scsi_cmd_hdr *req;
	struct iscsi_scsi_rsp_hdr *rsp;
	struct target_cmnd *tcmnd;

	cmnd = iscsi_cmnd_create_rsp_cmnd(scsi_cmnd);
	if (!cmnd)
		return NULL;

	req = (struct iscsi_scsi_cmd_hdr *)&scsi_cmnd->pdu.bhs;
	rsp = (struct iscsi_scsi_rsp_hdr *)&cmnd->pdu.bhs;
	rsp->opcode = ISCSI_OP_SCSI_RSP;
	rsp->flags = ISCSI_FLG_FINAL;
	rsp->response = ISCSI_RESPONSE_COMMAND_COMPLETED;
	rsp->cmd_status = GOOD << STATUS_SHIFT;
	rsp->itt = req->itt;

	tcmnd = scsi_cmnd->data;
	if (tcmnd && !tcmnd->pg_cnt) {
		cmnd->data = scsi_cmnd->data;
		scsi_cmnd->data = NULL;
	}

	return cmnd;
}

/**
 * Create a iscsi response command for a scsi command with CHECK_CONDITION status.
 *
 * iscsi_cmnd_sense_rsp
 * @scsi_cmnd: ptr to scsi command
 * @sense_key: sense key
 * @asc:
 * @ascq:
 *
 * @return    ptr to scsi response or NULL
 */

struct iscsi_cmnd *iscsi_cmnd_sense_rsp(struct iscsi_cmnd *scsi_cmnd, u8 sense_key, u8 asc, u8 ascq)
{
	struct iscsi_cmnd *cmnd;
	struct iscsi_scsi_cmd_hdr *req;
	struct iscsi_scsi_rsp_hdr *rsp;
	struct target_cmnd *tcmnd;
	struct iscsi_sense_data *sense;

	cmnd = iscsi_cmnd_create_rsp_cmnd(scsi_cmnd);
	if (!cmnd)
		return NULL;

	req = (struct iscsi_scsi_cmd_hdr *)&scsi_cmnd->pdu.bhs;
	rsp = (struct iscsi_scsi_rsp_hdr *)&cmnd->pdu.bhs;
	rsp->opcode = ISCSI_OP_SCSI_RSP;
	rsp->flags = ISCSI_FLG_FINAL;
	rsp->response = ISCSI_RESPONSE_COMMAND_COMPLETED;
	rsp->cmd_status = CHECK_CONDITION << STATUS_SHIFT;
	rsp->itt = req->itt;

	tcmnd = scsi_cmnd->data;
	if (tcmnd && !tcmnd->pg_cnt) {
		cmnd->data = scsi_cmnd->data;
		scsi_cmnd->data = NULL;
	} else
		tcmnd = cmnd->data = target_cmnd_alloc();

	target_alloc_pages(tcmnd, 1);
	sense = (struct iscsi_sense_data *) page_address(tcmnd->pvec[0]);
	assert(sense);
	clear_page(sense);
	sense->length = cpu_to_be16(14);
	sense->data[0] = 0xf0;
	sense->data[2] = sense_key;
	sense->data[7] = 6;	// Additional sense length
	sense->data[12] = asc;
	sense->data[13] = ascq;

	cmnd->pdu.datasize = sizeof(struct iscsi_sense_data) + 14;
	tcmnd->size = (cmnd->pdu.datasize + 3) & -4;
	tcmnd->offset = 0;

	return cmnd;
}

/**
 * Ignore data for this command.
 * Called from iscsi_cmnd_start_read.
 *
 * iscsi_cmnd_skip_pdu - 
 * @cmnd: ptr to command
 */

void iscsi_cmnd_skip_pdu(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;
	struct target_cmnd *tcmnd = cmnd->data;
	char *addr;
	u32 size;
	int i;

	size = cmnd->pdu.datasize;
	if (size) {
		if (!tcmnd)
			tcmnd = cmnd->data = target_cmnd_alloc();

		target_alloc_pages(tcmnd, 1);
		addr = page_address(tcmnd->pvec[0]);
		assert(addr);
		size = (size + 3) & -4;
		conn->read_size = size;
		for (i = 0; size > PAGE_CACHE_SIZE; i++, size -= PAGE_CACHE_SIZE) {
			/* FIXME */
			assert(i < ISCSI_CONN_IOV_MAX);
			conn->read_iov[i].iov_base = addr;
			conn->read_iov[i].iov_len = PAGE_CACHE_SIZE;
		}
		conn->read_iov[i].iov_base = addr;
		conn->read_iov[i].iov_len = size;
		conn->read_msg.msg_iov = conn->read_iov;
		conn->read_msg.msg_iovlen = ++i;
	}
}

/**
 * Ignore any scsi data and initialize the scsi response.
 * Can only be called after iscsi_cmnd_scsi_rsp or iscsi_cmnd_sense_rsp.
 *
 * iscsi_cmnd_ignore_data
 * @scsi_cmnd: ptr to scsi command
 */

void iscsi_cmnd_ignore_data(struct iscsi_cmnd *scsi_cmnd)
{
	struct iscsi_cmnd *rsp_cmnd;
	struct iscsi_scsi_cmd_hdr *req;
	struct iscsi_scsi_rsp_hdr *rsp;
	u32 size;

	rsp_cmnd = iscsi_cmnd_get_rsp_cmnd(scsi_cmnd);
	rsp = (struct iscsi_scsi_rsp_hdr *)&rsp_cmnd->pdu.bhs;
	req = (struct iscsi_scsi_cmd_hdr *)&scsi_cmnd->pdu.bhs;
	if (cmnd_opcode(rsp_cmnd) != ISCSI_OP_SCSI_RSP) {
		eprintk("unexpected response command %u\n", cmnd_opcode(rsp_cmnd));
		return;
	}

	size = iscsi_cmnd_write_size(scsi_cmnd);
	if (size) {
		rsp->flags |= ISCSI_FLG_RESIDUAL_UNDERFLOW;
		rsp->residual_count = cpu_to_be32(size);
	}
	size = iscsi_cmnd_read_size(scsi_cmnd);
	if (size) {
		if (req->flags & ISCSI_CMD_WRITE) {
			rsp->flags |= ISCSI_FLG_BIRESIDUAL_UNDERFLOW;
			rsp->bi_residual_count = cpu_to_be32(size);
		} else {
			rsp->flags |= ISCSI_FLG_RESIDUAL_UNDERFLOW;
			rsp->residual_count = cpu_to_be32(size);
		}
	}
	scsi_cmnd->pdu.bhs.opcode = (scsi_cmnd->pdu.bhs.opcode & ~ISCSI_OPCODE_MASK) | ISCSI_OP_SCSI_REJECT;

	iscsi_cmnd_skip_pdu(scsi_cmnd);
}

/**
 * Prepare the data of iscsi command to be sent.
 * cmnd->data points to a valid target command and is used to create data responses.
 *
 * iscsi_cmnd_prepare_send
 * @cmnd: ptr to command
 */

void iscsi_cmnd_prepare_send(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;
	struct iscsi_cmnd *data_cmnd;
	struct target_cmnd *tcmnd = cmnd->data;
	struct iscsi_scsi_cmd_hdr *req = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;
	struct iscsi_data_in_hdr *rsp;
	u32 pdusize, expsize, scsisize, size, offset, sn;
	LIST_HEAD(send);

	dprintk(D_GENERIC, "%p\n", cmnd);
	pdusize = conn->session->param.max_data_pdu_length;
	expsize = iscsi_cmnd_read_size(cmnd);
	size = min(expsize, tcmnd->size);
	offset = 0;
	sn = 0;

	while (1) {
		data_cmnd = iscsi_cmnd_create_rsp_cmnd(cmnd);
		data_cmnd->data = tcmnd;
		rsp = (struct iscsi_data_in_hdr *)&data_cmnd->pdu.bhs;

		rsp->opcode = ISCSI_OP_SCSI_DATA_IN;
		rsp->itt = req->itt;
		rsp->ttt = cpu_to_be32(ISCSI_RESERVED_TAG);
		rsp->buffer_offset = offset;
		rsp->data_sn = cpu_to_be32(sn);

		if (size <= pdusize) {
			data_cmnd->pdu.datasize = size;
			rsp->flags = ISCSI_FLG_FINAL | ISCSI_FLG_STATUS;

			scsisize = tcmnd->size;
			if (scsisize < expsize) {
				rsp->flags |= ISCSI_FLG_RESIDUAL_UNDERFLOW;
				size = expsize - scsisize;
			} else if (scsisize > expsize) {
				rsp->flags |= ISCSI_FLG_RESIDUAL_OVERFLOW;
				size = scsisize - expsize;
			} else
				size = 0;
			rsp->residual_count = cpu_to_be32(size);
			list_add_tail(&data_cmnd->list, &send);

			break;
		}

		data_cmnd->pdu.datasize = pdusize;

		size -= pdusize;
		offset += pdusize;
		sn++;

		list_add_tail(&data_cmnd->list, &send);
	}

	iscsi_cmnds_init_write(&send);
}

/**
 * Initialize conn->write_* from a target command to start writing the pdu data.
 * Called from the write thread.
 *
 * iscsi_cmnd_send_pdu - 
 * @conn: ptr to connection
 * @tcmnd: ptr to target command
 * @offset: offset in target data
 * @size: size of pdu
 */

void iscsi_cmnd_send_pdu(struct iscsi_conn *conn, struct target_cmnd *tcmnd, u32 offset, u32 size)
{
	dprintk(D_GENERIC, "%p %u,%u\n", tcmnd, offset, size);
	offset += tcmnd->offset;

	assert(offset < tcmnd->offset + tcmnd->size);
	assert(offset + size <= tcmnd->offset + tcmnd->size);

	conn->write_tcmnd = tcmnd;
	conn->write_offset = offset;
	conn->write_size += size;
}

/**
 * Initialize conn->read_* from a target command to start reading the pdu data.
 * Called from the read thread.
 *
 * iscsi_cmnd_receive_pdu - 
 * @conn: ptr to connection
 * @tcmnd: ptr to target command
 * @offset: offset in target data
 * @size: size of pdu
 */

void iscsi_cmnd_receive_pdu(struct iscsi_conn *conn, struct target_cmnd *tcmnd, u32 offset, u32 size)
{
	int idx, i;
	char *addr;

	dprintk(D_GENERIC, "%p %u,%u\n", tcmnd, offset, size);
	offset += tcmnd->offset;

	assert(offset < tcmnd->offset + tcmnd->size);
	assert(offset + size <= tcmnd->offset + tcmnd->size);

	idx = offset >> PAGE_CACHE_SHIFT;
	offset &= ~PAGE_CACHE_MASK;

	conn->read_msg.msg_iov = conn->read_iov;
	conn->read_size = (size + 3) & -4;
	conn->read_overflow = 0;

	i = 0;
	while (1) {
		assert(tcmnd->pvec[idx]);
		addr = page_address(tcmnd->pvec[idx]);
		assert(addr);
		conn->read_iov[i].iov_base =  addr + offset;
		if (offset + size <= PAGE_CACHE_SIZE) {
			conn->read_iov[i].iov_len = size;
			conn->read_msg.msg_iovlen = ++i;
			break;
		}
		conn->read_iov[i].iov_len = PAGE_CACHE_SIZE - offset;
		size -= conn->read_iov[i].iov_len;
		offset = 0;
		if (++i >= ISCSI_CONN_IOV_MAX) {
			conn->read_msg.msg_iovlen = i;
			conn->read_overflow = size;
			conn->read_size -= size;
			break;
		}

		idx++;
	}
}

/**
 * Set StatSn, ExpSn and MaxSn for outgoing iscsi commands.
 *
 * iscsi_cmnd_set_sn
 * @cmnd: ptr to command
 * @set_stat_sn: != 0, to also set StatSn
 */

void iscsi_cmnd_set_sn(struct iscsi_cmnd *cmnd, int set_stat_sn)
{
	struct iscsi_conn *conn = cmnd->conn;

	if (set_stat_sn)
		cmnd->pdu.bhs.sn = cpu_to_be32(conn->stat_sn++);
	cmnd->pdu.bhs.exp_sn = cpu_to_be32(conn->session->exp_cmd_sn);
	//cmnd->pdu.bhs.max_sn = cpu_to_be32(conn->session->max_cmd_sn);
	cmnd->pdu.bhs.max_sn = cpu_to_be32(conn->session->exp_cmd_sn + MAX_QUEUED_CMD_NR);
}

/**
 * Extract the expected write length of a scsi command.
 *
 * iscsi_cmnd_write_size - 
 * @cmnd: ptr to command
 *
 * @return    write size
 */

u32 iscsi_cmnd_write_size(struct iscsi_cmnd *cmnd)
{
	struct iscsi_scsi_cmd_hdr *hdr = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;

	if (hdr->flags & ISCSI_CMD_WRITE)
		return be32_to_cpu(hdr->data_length);
	return 0;
}

/**
 * Extract the expected read length of a scsi command.
 *
 * iscsi_cmnd_read_size - 
 * @cmnd: ptr to command
 *
 * @return    read size
 */

u32 iscsi_cmnd_read_size(struct iscsi_cmnd *cmnd)
{
	struct iscsi_scsi_cmd_hdr *hdr = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;

	if (hdr->flags & ISCSI_CMD_READ) {
		if (!(hdr->flags & ISCSI_CMD_WRITE))
			return be32_to_cpu(hdr->data_length);
		if (hdr->flags & ISCSI_CMD_READ) {
			struct iscsi_rlength_ahdr *ahdr = (struct iscsi_rlength_ahdr *)cmnd->pdu.ahs;
			if (ahdr && ahdr->ahstype == ISCSI_AHSTYPE_RLENGTH)
				return be32_to_cpu(ahdr->read_length);
		}
	}
	return 0;
}

/*****************************************************************************/
/*                                    QUEUE                                  */
/*****************************************************************************/

/**
 * Queue scsi command for execution.
 *
 * iscsi_scsi_queuecmnd - 
 * @cmnd: ptr to command
 */

void iscsi_scsi_queuecmnd(struct iscsi_cmnd *cmnd)
{
	struct iscsi_queue *queue = &cmnd->lun->queue;

	dprintk(D_GENERIC, "%p\n", cmnd);

	if ((cmnd->pdu.bhs.flags & ISCSI_CMD_ATTR_MASK) != ISCSI_CMD_UNTAGGED &&
	    (cmnd->pdu.bhs.flags & ISCSI_CMD_ATTR_MASK) != ISCSI_CMD_SIMPLE) {
		cmnd->pdu.bhs.flags &= ~ISCSI_CMD_ATTR_MASK;
		cmnd->pdu.bhs.flags |= ISCSI_CMD_UNTAGGED;
	}

	spin_lock(&queue->queue_lock);

	switch (cmnd->pdu.bhs.flags & ISCSI_CMD_ATTR_MASK) {
	case ISCSI_CMD_UNTAGGED:
	case ISCSI_CMD_SIMPLE:
		if (!list_empty(&queue->wait_list) || queue->ordered_cmnd)
			goto pending;
		queue->active_cnt++;
		break;

	default:
		BUG();
	}
	spin_unlock(&queue->queue_lock);

	iscsi_device_queue_cmnd(cmnd);
	return;
 pending:
	assert(list_empty(&cmnd->list));

	list_add_tail(&cmnd->list, &queue->wait_list);
	cmnd->state = ISCSI_STATE_PENDING;
	spin_unlock(&queue->queue_lock);
	return;
}

/**
 * Dequeue a scsi command.
 * If other scsi commands were block by this one, they are now send now to the device.
 *
 * iscsi_scsi_dequeuecmnd - 
 * @cmnd: ptr to command
 */

void iscsi_scsi_dequeuecmnd(struct iscsi_cmnd *cmnd)
{
	struct iscsi_queue *queue;
	struct iscsi_cmnd *cmnd2;
	struct list_head *entry;

	if (!cmnd->lun)
		return;
	queue = &cmnd->lun->queue;
	spin_lock(&queue->queue_lock);
	switch (cmnd->pdu.bhs.flags & ISCSI_CMD_ATTR_MASK) {
	case ISCSI_CMD_UNTAGGED:
	case ISCSI_CMD_SIMPLE:
		--queue->active_cnt;
		break;
	case ISCSI_CMD_ORDERED:
		assert(queue->ordered_cmnd == cmnd);
		queue->ordered_cmnd = NULL;
		break;
	case ISCSI_CMD_HEAD_OF_QUEUE:
	case ISCSI_CMD_ACA:
		assert(!list_empty(&queue->wait_list));

		list_for_each(entry, &queue->wait_list) {
			cmnd2 = list_entry(entry, struct iscsi_cmnd, list);
			if (cmnd == cmnd2->data) {
				list_del_init(&cmnd2->list);
				iscsi_cmnd_remove(cmnd);
				if (queue->ordered_cmnd)
					goto out;
				break;
			}
		}
		break;
	default:
		/* Should the iscsi_scsi_queuecmnd func reject this ? */
		break;
	}

	while (!list_empty(&queue->wait_list)) {
		cmnd = list_entry(queue->wait_list.next, struct iscsi_cmnd, list);
		switch ((cmnd->pdu.bhs.flags & ISCSI_CMD_ATTR_MASK)) {
		case ISCSI_CMD_UNTAGGED:
		case ISCSI_CMD_SIMPLE:
			list_del_init(&cmnd->list);
			queue->active_cnt++;
			iscsi_device_queue_cmnd(cmnd);
			break;
		case ISCSI_CMD_ORDERED:
			if (!queue->active_cnt) {
				list_del_init(&cmnd->list);
				queue->ordered_cmnd = cmnd;
				iscsi_device_queue_cmnd(cmnd);
			}
			goto out;
		case ISCSI_CMD_HEAD_OF_QUEUE:
		case ISCSI_CMD_ACA:
			goto out;
		}
	}
out:
	spin_unlock(&queue->queue_lock);

	return;
}

static int insert_disconnect_pg(u8 *ptr)
{
	unsigned char disconnect_pg[] = {0x2, 0xe, 128, 128, 0, 10, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0};
	memcpy(ptr, disconnect_pg, sizeof(disconnect_pg));
	return sizeof(disconnect_pg);
}

static int insert_caching_pg(u8 *ptr)
{
	unsigned char caching_pg[] = {0x8, 18, 0x14, 0, 0xff, 0xff, 0, 0,
				      0xff, 0xff, 0xff, 0xff, 0x80, 0x14, 0, 0,
				      0, 0, 0, 0};
	memcpy(ptr, caching_pg, sizeof(caching_pg));
	return sizeof(caching_pg);
}

static int insert_ctrl_m_pg(u8 *ptr)
{
	unsigned char ctrl_m_pg[] = {0xa, 10, 2, 0, 0, 0, 0, 0,
				     0, 0, 0x2, 0x4b};

	memcpy(ptr, ctrl_m_pg, sizeof(ctrl_m_pg));
	return sizeof(ctrl_m_pg);
}

static int build_mode_sense_response(struct iscsi_cmnd *cmnd)
{
	struct iscsi_scsi_cmd_hdr *req = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;
	struct target_cmnd *tcmnd = cmnd->data;
	u8 *data, *scb = req->scb;
	int len = 4, res = 0;
	u8 pcode;

	pcode = req->scb[2] & 0x3f;

	target_alloc_pages(tcmnd, 1);
	data = page_address(tcmnd->pvec[0]);
	assert(data);
	clear_page(data);

	if ((scb[1] & 0x8))
		data[3] = 0;
	else {
		data[3] = 8;
		len += 8;
		*(u32 *)(data + 4) = cpu_to_be32(cmnd->lun->blk_cnt);
		*(u32 *)(data + 8) = cpu_to_be32(1 << cmnd->lun->blk_shift);
	}

	switch (pcode) {
	case 0x0:
		break;
	case 0x2:
		len += insert_disconnect_pg(data + len);
		break;
	case 0x8:
		len += insert_caching_pg(data + len);
		break;
	case 0xa:
		len += insert_ctrl_m_pg(data + len);
		break;
	case 0x3f:
		len += insert_disconnect_pg(data + len);
		len += insert_caching_pg(data + len);
		len += insert_ctrl_m_pg(data + len);
		break;
	default:
		res = -1;
	}

	data[0] = len - 1;
	tcmnd->offset = 0;
	tcmnd->size = len;

	return res;
}

static int build_inquiry_response(struct iscsi_cmnd *cmnd)
{
	struct iscsi_scsi_cmd_hdr *req = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;
	struct target_cmnd *tcmnd = cmnd->data;
	u8 *data;
	u8 *scb = req->scb;
	int res = -1;

	if (((req->scb[1] & 0x3) == 0x3) || (!(req->scb[1] & 0x3) && req->scb[2]))
		return res;

	target_alloc_pages(tcmnd, 1);
	data = page_address(tcmnd->pvec[0]);
	assert(data);
	clear_page(data);

	if (!(scb[1] & 0x3)) {
		data[2] = 3;
		data[3] = 0x42;
		data[4] = 57;
		data[7] = 0x02;
		memcpy(data + 8, "LINUX   ", 8);
		memcpy(data + 16, "ISCSI           ", 16);
		memcpy(data + 32, "0   ", 4);
		data[58] = 0x01;
		data[59] = 0x80;
		data[60] = 0x09;
		data[61] = 0x60;
		tcmnd->offset = 0;
		tcmnd->size = 62;
		res = 0;
	} else if (scb[1] & 0x2) {
		/* CmdDt bit is set */
		/* We do not support it now. */
		data[1] = 0x1;
		data[5] = 0;
		tcmnd->offset = 0;
		tcmnd->size = 6;
		res = 0;
	} else if (scb[1] & 0x1) {
		/* EVPD bit set */
		if (scb[2] == 0x0) {
			data[1] = 0x0;
			data[3] = 3;
			data[4] = 0x0;
			data[5] = 0x80;
			data[6] = 0x83;
			tcmnd->offset = 0;
			tcmnd->size = 7;
			res = 0;
		} else if (scb[2] == 0x80) {
			data[1] = 0x80;
			data[3] = 4;
			memset(data + 4, 0x20, 4);
			tcmnd->offset = 0;
			tcmnd->size = 8;
			res = 0;
		} else if (scb[2] == 0x83) {
			data[1] = 0x83;
			data[3] = 12;
			data[4] = 0x2;
			data[5] = 0x2;
			data[7] = 8;
			/* FIXME: more meaningful name */
			memset(data + 8, 20, 8);
			tcmnd->offset = 0;
			tcmnd->size = 16;
			res = 0;
		}
	}

	if (!cmnd->lun)
		data[0] = 0x7f;

	return res;
}

/**
 * Execute a scsi command.
 *
 * iscsi_scsi_execute - 
 * @cmnd: ptr to command
 */

void iscsi_scsi_execute(struct iscsi_cmnd *cmnd)
{
	struct iscsi_scsi_cmd_hdr *req = (struct iscsi_scsi_cmd_hdr *)&cmnd->pdu.bhs;
	struct target_cmnd *tcmnd = cmnd->data;

	if (!(cmnd->pdu.bhs.flags & ISCSI_CMD_FINAL)) {
		cmnd->state = ISCSI_STATE_WAIT_RECEIVE;
		//list_add_tail(&cmnd->list, &conn->wait_list);
		return;
	}
	req->opcode &= ISCSI_OPCODE_MASK;

	switch (req->scb[0]) {
	case INQUIRY:
		if (build_inquiry_response(cmnd) < 0) {
			cmnd = iscsi_cmnd_sense_rsp(cmnd, ILLEGAL_REQUEST, 0x24, 0x0);
			iscsi_cmnd_init_write(cmnd);
		} else
			iscsi_cmnd_prepare_send(cmnd);
		break;
	case REPORT_LUNS:
	{
		u32 *data, size, len;
		struct iet_volume *lun;
		int rest, idx = 0;

		size = be32_to_cpu(*(u32 *)&req->scb[6]);
		if (size < 16) {
			struct iscsi_cmnd *rcmnd;
			rcmnd = iscsi_cmnd_sense_rsp(cmnd, ILLEGAL_REQUEST, 0x24, 0x0);
			assert(rcmnd);
			iscsi_cmnd_init_write(rcmnd);
			break;
		}

		len = atomic_read(&cmnd->conn->session->target->nr_volumes) * 8;
		size = min(size & ~(8 - 1), len + 8);

		target_alloc_pages(tcmnd, (size + PAGE_SIZE - 1) >> PAGE_SHIFT);
		tcmnd->offset = 0;
		tcmnd->size = size;

		data = page_address(tcmnd->pvec[idx]);
		assert(data);
		*data++ = cpu_to_be32(len);
		*data++ = 0;
		size -= 8;
		rest = PAGE_SIZE - 8;
		list_for_each_entry(lun, &cmnd->conn->session->target->volumes, list) {
			*data++ = cpu_to_be32((0x3ff & lun->lun) << 16 |
					      ((lun->lun > 0xff) ? (0x1 << 30) : 0));
			*data++ = 0;
			if ((size -= 8) == 0)
				break;
			if ((rest -= 8) == 0) {
				idx++;
				data = page_address(tcmnd->pvec[idx]);
				rest = PAGE_SIZE;
			}
		}

		iscsi_cmnd_prepare_send(cmnd);
		break;
	}
	case START_STOP:
	{
		struct iscsi_cmnd *rsp_cmnd;
		struct iscsi_scsi_rsp_hdr *rsp;
		u32 size;

		rsp_cmnd = iscsi_cmnd_scsi_rsp(cmnd);
		rsp = (struct iscsi_scsi_rsp_hdr *)&rsp_cmnd->pdu.bhs;

		size = iscsi_cmnd_read_size(cmnd);
		if (size) {
			rsp->flags |= ISCSI_FLG_RESIDUAL_UNDERFLOW;
			rsp->residual_count = cpu_to_be32(size);
		}

		iscsi_cmnd_init_write(rsp_cmnd);
		break;
	}
	case READ_CAPACITY:
	{
		u32 *data;

		target_alloc_pages(tcmnd, 1);
		data = page_address(tcmnd->pvec[0]);
		assert(data);
		data[0] = cpu_to_be32(cmnd->lun->blk_cnt - 1);
		data[1] = cpu_to_be32(1 << cmnd->lun->blk_shift);

		tcmnd->offset = 0;
		tcmnd->size = 8;

		iscsi_cmnd_prepare_send(cmnd);
		break;
	}
	case MODE_SENSE:
		if (build_mode_sense_response(cmnd) < 0) {
			cmnd = iscsi_cmnd_sense_rsp(cmnd, ILLEGAL_REQUEST, 0x24, 0x0);
			iscsi_cmnd_init_write(cmnd);
		} else
			iscsi_cmnd_prepare_send(cmnd);
		break;
	case REQUEST_SENSE:
	{
		u8 *data;

		target_alloc_pages(tcmnd, 1);
		data = page_address(tcmnd->pvec[0]);
		assert(data);
		memset(data, 0, 18);
		data[0] = 0xf0;
		data[1] = 0;
		data[2] = NO_SENSE;
		data[7] = 10;
		tcmnd->offset = 0;
		tcmnd->size = 18;
		iscsi_cmnd_prepare_send(cmnd);
		break;
	}
	case READ_6:
	case READ_10:
	{
		target_alloc_pages(tcmnd, tcmnd->pg_cnt);
		target_read_pages(cmnd->lun, tcmnd);
		iscsi_cmnd_prepare_send(cmnd);
		break;
	}
	case WRITE_6:
	case WRITE_10:
	{
		struct iscsi_cmnd *rsp_cmnd;
		u32 length;

		if (!(req->flags & ISCSI_CMD_FINAL)) {
			printk("warning nonfinal cmnd %p executed!\n", cmnd);
			break;
		}

		length = be32_to_cpu(req->data_length) - cmnd->pdu.datasize;
		if (length) {
			struct iscsi_r2t_hdr *rsp;
			u32 offset, burst;
			int sn = 0;
			LIST_HEAD(send);

			burst = cmnd->conn->session->param.max_burst_length;
			offset = cmnd->pdu.datasize;
			do {
				rsp_cmnd = iscsi_cmnd_create_rsp_cmnd(cmnd);
				iscsi_session_insert_ttt(rsp_cmnd);
				rsp_cmnd->data = cmnd;

				rsp = (struct iscsi_r2t_hdr *)&rsp_cmnd->pdu.bhs;
				rsp->opcode = ISCSI_OP_R2T;
				rsp->flags = ISCSI_FLG_FINAL;
				rsp->itt = req->itt;
				rsp->r2t_sn = cpu_to_be32(sn++);
				rsp->buffer_offset = cpu_to_be32(offset);
				if (length > burst) {
					rsp->data_length = cpu_to_be32(burst);
					length -= burst;
					offset += burst;
				} else {
					rsp->data_length = cpu_to_be32(length);
					length = 0;
				}
				list_add_tail(&rsp_cmnd->list, &send);
			} while (length);

			cmnd->state = ISCSI_STATE_SEND_R2T;
			iscsi_cmnds_init_write(&send);

		} else {
			struct iscsi_scsi_rsp_hdr *rsp;
			u32 size;

			rsp_cmnd = iscsi_cmnd_scsi_rsp(cmnd);
			rsp = (struct iscsi_scsi_rsp_hdr *)&rsp_cmnd->pdu.bhs;

			// NOTE code duplication...
			list_del_init(&cmnd->list);
			size = iscsi_cmnd_read_size(cmnd);
			if (size) {
				rsp->flags |= ISCSI_FLG_RESIDUAL_UNDERFLOW;
				rsp->residual_count = cpu_to_be32(size);
			}

			target_commit_pages(cmnd->lun, cmnd->data);
			cmnd->state = ISCSI_STATE_WAIT_COMMIT;

			target_sync_pages(cmnd->lun, cmnd->data);
			cmnd->state = ISCSI_STATE_WAIT_WRITE;

			iscsi_cmnd_init_write(rsp_cmnd);
			cmnd->state = ISCSI_STATE_SEND_RSP;
		}
		break;
	}
	case TEST_UNIT_READY:
	case VERIFY:
	case RESERVE:
	case RELEASE:
	case RESERVE_10:
	case RELEASE_10:
	{
		struct iscsi_cmnd *rsp_cmnd;
		struct iscsi_scsi_rsp_hdr *rsp;
		u32 size;

		rsp_cmnd = iscsi_cmnd_scsi_rsp(cmnd);
		rsp = (struct iscsi_scsi_rsp_hdr *)&rsp_cmnd->pdu.bhs;

		size = iscsi_cmnd_read_size(cmnd);
		if (size) {
			rsp->flags |= ISCSI_FLG_RESIDUAL_UNDERFLOW;
			rsp->residual_count = cpu_to_be32(size);
		}

		iscsi_cmnd_init_write(rsp_cmnd);
		break;
	}
	default:
		printk("%s(%d) should not come here!\n", __FUNCTION__, __LINE__);
		break;
	}
}

void iscsi_device_queue_cmnd(struct iscsi_cmnd *cmnd)
{
	queue_cmnd(cmnd, iscsi_scsi_execute);
}

/**
 * Insert a command into the session.
 * After this the command is known under this ITT
 *
 * iscsi_session_insert_cmnd - 
 * @cmnd: ptr to command
 *
 * @return    1 -> command successfully accepted
 *	    otherwise 0.
 */

int iscsi_session_insert_cmnd(struct iscsi_cmnd *cmnd)
{
	struct iscsi_session *session = cmnd->conn->session;
	u32 itt = cmnd->pdu.bhs.itt;
	int hash = ISCSI_TT_HASH(itt);
	struct iscsi_cmnd *hash_cmnd;

	dprintk(D_GENERIC, "%p:%x\n", cmnd, itt);
	if (itt == cpu_to_be32(ISCSI_RESERVED_TAG)) {
		iscsi_cmnd_reject(cmnd, ISCSI_REASON_PROTOCOL_ERROR);
		return 0;
	}

	spin_lock(&session->cmnd_tt_lock);
	for (hash_cmnd = session->cmnd_itt_hash[hash]; hash_cmnd;
	     hash_cmnd = hash_cmnd->hash_next) {
		if (hash_cmnd->pdu.bhs.itt == itt) {
			spin_unlock(&session->cmnd_tt_lock);
			iscsi_cmnd_reject(cmnd, ISCSI_REASON_TASK_IN_PROGRESS);
			return 0;
		}
	}
	cmnd->hash_next = session->cmnd_itt_hash[hash];
	session->cmnd_itt_hash[hash] = cmnd;
	spin_unlock(&session->cmnd_tt_lock);

	iscsi_conn_update_stat_sn(cmnd);
	return iscsi_session_check_cmd_sn(cmnd);
}

/**
 * Find a command with a specific ITT.
 * FIXME: command might be removed by the write thread.
 *
 * iscsi_session_find_cmnd - 
 * @session: ptr to session
 * @itt: ITT
 *
 * @return    ptr to command or NULL
 */

struct iscsi_cmnd *iscsi_session_find_cmnd(struct iscsi_session *session, u32 itt)
{
	struct iscsi_cmnd *cmnd;
	int hash;

	hash = ISCSI_TT_HASH(itt);
	spin_lock(&session->cmnd_tt_lock);
	for (cmnd = session->cmnd_itt_hash[hash]; cmnd; cmnd = cmnd->hash_next) {
		if (cmnd->pdu.bhs.itt == itt)
			break;
	}
	spin_unlock(&session->cmnd_tt_lock);
	return cmnd;
}

void remove_from_itt_hashtable(struct iscsi_cmnd *cmnd)
{
	struct iscsi_session *session = cmnd->conn->session;
	struct iscsi_cmnd *hash_cmnd, **prev_cmnd;
	int hash;

	spin_lock(&session->cmnd_tt_lock);

	hash = ISCSI_TT_HASH(cmnd->pdu.bhs.itt);
	for (prev_cmnd = &session->cmnd_itt_hash[hash];
	     (hash_cmnd = *prev_cmnd); prev_cmnd = &hash_cmnd->hash_next) {
		if (cmnd == hash_cmnd)
			break;
	}
	if (hash_cmnd)
		*prev_cmnd = cmnd->hash_next;
	else
		eprintk("%p:%x not found\n", cmnd, cmnd->pdu.bhs.itt);
	spin_unlock(&session->cmnd_tt_lock);
}

/**
 * Remove the command from the session.
 * This removes also all commands (responses) attached to this command
 *
 * iscsi_session_remove_cmnd - 
 * @cmnd: ptr to command
 */

void iscsi_session_remove_cmnd(struct iscsi_cmnd *cmnd)
{
	struct list_head *entry;

	dprintk(D_GENERIC, "%p:%x\n", cmnd, cmnd->pdu.bhs.itt);

	remove_from_itt_hashtable(cmnd);
	while (!list_empty(&cmnd->pdu_list)) {
		entry = cmnd->pdu_list.next;
		list_del(entry);
		iscsi_cmnd_remove(list_entry(entry, struct iscsi_cmnd, pdu_list));
	}

	iscsi_cmnd_remove(cmnd);
}

void iscsi_session_insert_ttt(struct iscsi_cmnd *cmnd)
{
	struct iscsi_session *session = cmnd->conn->session;
	u32 ttt;
	int hash;

	spin_lock(&session->cmnd_tt_lock);

	cmnd->pdu.bhs.ttt = ttt = session->next_ttt++;
	if (!session->next_ttt) {
		cmnd->pdu.bhs.ttt = ttt = 1;
		session->next_ttt = 2;
	}

	hash = ISCSI_TT_HASH(ttt);
	cmnd->hash_next = session->cmnd_ttt_hash[hash];
	session->cmnd_ttt_hash[hash] = cmnd;
	spin_unlock(&session->cmnd_tt_lock);
	dprintk(D_GENERIC, "%p:%x\n", cmnd, ttt);
}

struct iscsi_cmnd *iscsi_session_find_ttt(struct iscsi_session *session, u32 ttt)
{
	struct iscsi_cmnd *cmnd;
	int hash;

	hash = ISCSI_TT_HASH(ttt);
	spin_lock(&session->cmnd_tt_lock);
	for (cmnd = session->cmnd_ttt_hash[hash]; cmnd; cmnd = cmnd->hash_next) {
		if (cmnd->pdu.bhs.ttt == ttt)
			break;
	}
	spin_unlock(&session->cmnd_tt_lock);
	return cmnd;
}

void iscsi_session_remove_ttt(struct iscsi_cmnd *cmnd)
{
	struct iscsi_session *session = cmnd->conn->session;
	struct iscsi_cmnd *hash_cmnd, **prev_cmnd;
	int hash;

	dprintk(D_GENERIC, "%p:%x\n", cmnd, cmnd->pdu.bhs.ttt);
	spin_lock(&session->cmnd_tt_lock);
	hash = ISCSI_TT_HASH(cmnd->pdu.bhs.ttt);
	for (prev_cmnd = &session->cmnd_ttt_hash[hash];
	     (hash_cmnd = *prev_cmnd); prev_cmnd = &hash_cmnd->hash_next) {
		if (cmnd == hash_cmnd) {
			*prev_cmnd = cmnd->hash_next;
			break;
		}
	}
	spin_unlock(&session->cmnd_tt_lock);
	if (!hash_cmnd)
		eprintk("%p:%x not found\n", cmnd, cmnd->pdu.bhs.ttt);
	list_del_init(&cmnd->pdu_list);
	iscsi_cmnd_remove(cmnd);
}

/**
 * Push the command for execution.
 * This functions reorders the commands.
 * Called from the read thread.
 *
 * iscsi_session_push_cmnd - 
 * @cmnd: ptr to command
 */

void iscsi_session_push_cmnd(struct iscsi_cmnd *cmnd)
{
	struct iscsi_session *session = cmnd->conn->session;
	struct list_head *entry;
	u32 cmd_sn;

	dprintk(D_GENERIC, "%p:%x %u,%u\n",
		cmnd, cmnd_opcode(cmnd), cmnd->pdu.bhs.sn, session->exp_cmd_sn);
	if (cmnd->state != ISCSI_STATE_READ)
		eprintk("unexpected state %d of cmnd %p\n", cmnd->state, cmnd);

	if (cmnd->pdu.bhs.opcode & ISCSI_OP_IMMEDIATE) {
		iscsi_cmnd_execute(cmnd);
		return;
	}

	cmd_sn = cmnd->pdu.bhs.sn;
	if (cmd_sn == session->exp_cmd_sn) {
		while (1) {
			session->exp_cmd_sn = ++cmd_sn;
			iscsi_cmnd_execute(cmnd);

			if (list_empty(&session->pending_list))
				break;
			cmnd = list_entry(session->pending_list.next, struct iscsi_cmnd, list);
			if (cmnd->pdu.bhs.sn != cmd_sn)
				break;
			list_del_init(&cmnd->list);
		}
	} else {
		if (before(cmd_sn, session->exp_cmd_sn)) /* close the conn */
			eprintk("unexpected cmd_sn (%u,%u)\n", cmd_sn, session->exp_cmd_sn);

		if (after(cmd_sn, session->exp_cmd_sn + MAX_QUEUED_CMD_NR))
			eprintk("too large cmd_sn (%u,%u)\n", cmd_sn, session->exp_cmd_sn);

		list_for_each(entry, &session->pending_list) {
			struct iscsi_cmnd *tmp = list_entry(entry, struct iscsi_cmnd, list);
			if (before(cmd_sn, tmp->pdu.bhs.sn))
				break;
		}
		cmnd->state = ISCSI_STATE_PUSHED;
		assert(list_empty(&cmnd->list));

		list_add_tail(&cmnd->list, entry);
	}
}

/**
 * Check the SN of the incoming command and reject if necessary.
 *
 * iscsi_session_check_cmd_sn - 
 * @cmnd: ptr to command
 *
 * @return  1 -> command ok
 *	    0 -> otherwise
 */

static int inline iscsi_session_check_cmd_sn(struct iscsi_cmnd *cmnd)
{
	struct iscsi_session *session = cmnd->conn->session;
	u32 cmd_sn;

	cmnd->pdu.bhs.sn = cmd_sn = be32_to_cpu(cmnd->pdu.bhs.sn);
	dprintk(D_GENERIC, "%d(%d)\n", cmd_sn, session->exp_cmd_sn);
	if ((s32)(cmd_sn - session->exp_cmd_sn) >= 0)
		return 1;
	eprintk("sequence error (%x,%x)\n", cmd_sn, session->exp_cmd_sn);
	iscsi_cmnd_reject(cmnd, ISCSI_REASON_PROTOCOL_ERROR);
	return 0;
}

/**
 * Send asynchronous logout event.
 *
 * iscsi_conn_logout - 
 * @conn: ptr to connection
 * @timeout:
 *
 * @return    -errno
 */

int iscsi_conn_logout(struct iscsi_conn *conn, u32 timeout)
{
	struct iscsi_cmnd *cmnd;
	struct iscsi_async_msg_hdr *msg;

	cmnd = iscsi_cmnd_create(conn);
	if (!cmnd)
		return -ENOMEM;

	msg = (struct iscsi_async_msg_hdr *)&cmnd->pdu.bhs;

	msg->opcode = ISCSI_OP_ASYNC_MSG;
	msg->ffffffff = ISCSI_RESERVED_TAG;
	msg->flags = ISCSI_FLG_FINAL;
	msg->async_event = ISCSI_ASYNC_LOGOUT;
	msg->param3 = cpu_to_be16(timeout);
	iscsi_cmnd_init_write(cmnd);

	wake_up_itargetd(conn->session->target);
	return 0;
}

/**
 * Write out data.
 *
 * iscsi_conn_write_data - 
 * @conn: ptr to connection
 *
 * @return    
 */

int iscsi_conn_write_data(struct iscsi_conn *conn)
{
	struct file *file;
	struct socket *sock;
	ssize_t (*sendpage)(struct socket *, struct page *, int, size_t, int);
	struct target_cmnd *tcmnd;
	struct iovec *iop;
	int saved_size, size, sendsize;
	int offset, idx;
	int flags, res;

	file = conn->file;
	saved_size = size = conn->write_size;
	iop = conn->write_iop;

	if (iop) while (1) {
		res = file->f_op->write(file, iop->iov_base,
					iop->iov_len, &file->f_pos);
		dprintk(D_GENERIC, "write %#Lx:%u: %d(%ld)\n",
			(unsigned long long) conn->session->sid, conn->cid,
			res, (long) iop->iov_len);
		if (unlikely(res <= 0)) {
			if (res == -EAGAIN || res == -EINTR) {
				conn->write_iop = iop;
				goto out_iov;
			}
			goto err;
		}
		size -= res;
		iop->iov_len -= res;
		if (!iop->iov_len) {
			iop++;
			if (!iop->iov_len) {
				conn->write_iop = NULL;
				/* more data to be written? continue with tcmnd,
				 * otherwise exit
				 */
				if (size)
					break;
				goto out_iov;
			}
		} else
			iop->iov_base += res;
	}

	tcmnd = conn->write_tcmnd;
	if (!tcmnd) {
		printk("warning data missing!\n");
		return 0;
	}
	offset = conn->write_offset;
	idx = offset >> PAGE_CACHE_SHIFT;
	offset &= ~PAGE_CACHE_MASK;

	sock = conn->sock;
	sendpage = sock->ops->sendpage ? : sock_no_sendpage;
	flags = MSG_DONTWAIT;

	while (1) {
		sendsize = PAGE_CACHE_SIZE - offset;
		if (size <= sendsize) {
			res = sendpage(sock, tcmnd->pvec[idx], offset, size, flags);
			dprintk(D_GENERIC, "%s %#Lx:%u: %d(%lu,%u,%u)\n",
				sock->ops->sendpage ? "sendpage" : "writepage",
				(unsigned long long ) conn->session->sid, conn->cid,
				res, tcmnd->pvec[idx]->index, offset, size);
			if (unlikely(res <= 0)) {
				if (res == -EAGAIN || res == -EINTR) {
					goto out;
				}
				goto err;
			}
			if (res == size) {
				conn->write_tcmnd = NULL;
				conn->write_size = 0;
				return saved_size;
			}
			offset += res;
			size -= res;
			continue;
		}

		res = sendpage(sock, tcmnd->pvec[idx], offset,sendsize, flags | MSG_MORE);
		dprintk(D_GENERIC, "%s %#Lx:%u: %d(%lu,%u,%u)\n",
			sock->ops->sendpage ? "sendpage" : "writepage",
			(unsigned long long ) conn->session->sid, conn->cid,
			res, tcmnd->pvec[idx]->index, offset, sendsize);
		if (unlikely(res <= 0)) {
			if (res == -EAGAIN || res == -EINTR) {
				goto out;
			}
			goto err;
		}
		if (res == sendsize) {
			idx++;
			offset = 0;
		} else
			offset += res;
		size -= res;
	}
 out:
	conn->write_offset = (idx << PAGE_CACHE_SHIFT) + offset;
 out_iov:
	conn->write_size = size;
	if ((saved_size == size) && res == -EAGAIN)
		return res;

	return saved_size - size;

 err:
	eprintk("error %d at %#Lx:%u\n", res, (unsigned long long ) conn->session->sid, conn->cid);
	return res;
}

/**
 * Update SN of connection.
 *
 * iscsi_conn_update_stat_sn - 
 * @cmnd: ptr to command
 */

void iscsi_conn_update_stat_sn(struct iscsi_cmnd *cmnd)
{
	struct iscsi_conn *conn = cmnd->conn;
	u32 exp_stat_sn;

	cmnd->pdu.bhs.exp_sn = exp_stat_sn = be32_to_cpu(cmnd->pdu.bhs.exp_sn);
	dprintk(D_GENERIC, "%x,%x\n", cmnd_opcode(cmnd), exp_stat_sn);
	if ((int)(exp_stat_sn - conn->exp_stat_sn) > 0 &&
	    (int)(exp_stat_sn - conn->stat_sn) <= 0) {
		// free pdu resources
		cmnd->conn->exp_stat_sn = exp_stat_sn;
	} else if ((int)(exp_stat_sn - conn->exp_stat_sn) != 0) {
		eprintk("stat sequence number error (%x,%x)\n", exp_stat_sn, conn->exp_stat_sn);
	}
}

static int iscsi_init(void)
{
	printk(KERN_INFO "iSCSI Enterprise Target Software - version %s\n", IET_VERSION_STRING);

	ctr_major = register_chrdev(0, ctr_name, &ctr_fops);
	if (ctr_major < 0) {
		eprintk("failed to register the control device %d\n", ctr_major);
		return ctr_major;
	}

	iet_procfs_init();

	iscsi_cmnd_cache = kmem_cache_create("iscsi_cmnd", sizeof(struct iscsi_cmnd),
					     0, 0, NULL, NULL);
	target_init();

	return 0;
}

static void iscsi_exit(void)
{
	unregister_chrdev(ctr_major, ctr_name);

	iet_procfs_exit();

	target_exit();

	kmem_cache_destroy(iscsi_cmnd_cache);
}

module_init(iscsi_init);
module_exit(iscsi_exit);

MODULE_LICENSE("GPL");
