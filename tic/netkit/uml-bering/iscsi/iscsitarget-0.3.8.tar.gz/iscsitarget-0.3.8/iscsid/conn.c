/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <ctype.h>
#include <dirent.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

#include "iscsid.h"

#define ISCSI_CONN_NEW		1
#define ISCSI_CONN_EXIT		5

struct connection *conn_alloc(void)
{
	struct connection *conn;

	conn = xmalloc(sizeof(*conn));
	memset(conn, 0, sizeof(*conn));

	conn->state = STATE_FREE;
	conn->param = ISCSI_PARAM_INIT;

	return conn;
}

void conn_free(struct connection *conn)
{
	free(conn->initiator);
	free(conn);
}

int conn_test(struct connection *conn)
{
	int res;
	struct conn_info info;

	info.tid = conn->target->id;
	info.sid = conn->session->sid.id64;
	info.cid = conn->cid;

	res = ioctl(ctrl_fd, GET_CONN_INFO, &info);

	if (res < 0 && errno == ENOENT)
		return 1;
	else
		return 0;
}

void conn_take_fd(struct connection *conn, int fd)
{
	struct conn_info info;

	log_debug(1, "conn_take_fd: %u %u %u %Lx %d", conn->cid, conn->stat_sn, conn->exp_stat_sn,
		  (unsigned long long) conn->sid.id64, fd);

	conn->session->conn_cnt++;

	info.tid = conn->target->id;
	info.sid = conn->session->sid.id64;
	info.cid = conn->cid;
	info.stat_sn = conn->stat_sn;
	info.exp_stat_sn = conn->exp_stat_sn;
	info.fd = fd;

	ioctl(ctrl_fd, ADD_CONN, &info);
}

void conn_read_pdu(struct connection *conn)
{
	conn->iostate = IOSTATE_READ_BHS;
	conn->buffer = (void *)&conn->req.bhs;
	conn->rwsize = BHS_SIZE;
}

void conn_write_pdu(struct connection *conn)
{
	conn->iostate = IOSTATE_WRITE_BHS;
	memset(&conn->rsp, 0, sizeof(conn->rsp));
	conn->buffer = (void *)&conn->rsp.bhs;
	conn->rwsize = BHS_SIZE;
}

void conn_free_pdu(struct connection *conn)
{
	conn->iostate = IOSTATE_FREE;
	if (conn->req.ahs) {
		free(conn->req.ahs);
		conn->req.ahs = NULL;
	}
	if (conn->rsp.ahs) {
		free(conn->rsp.ahs);
		conn->rsp.ahs = NULL;
	}
	if (conn->rsp.data) {
		free(conn->rsp.data);
		conn->rsp.data = NULL;
	}
}
