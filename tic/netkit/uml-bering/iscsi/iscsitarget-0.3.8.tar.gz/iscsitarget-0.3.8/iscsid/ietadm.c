/*
 * ietadm - manage iSCSI Enterprise Target software.
 *
 * (C) 2004 FUJITA Tomonori <tomof@acm.org>
 *
 * This code is licenced under the GPL.
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>

#include "iscsid.h"
#include "iet_u.h"
#include "ietadm.h"

enum ietadm_mode {
	MODE_ADD,
	MODE_DEL,
	MODE_STOP,
};

static char program_name[] = "ietadm";

static struct option const long_options[] =
{
	{"mode", required_argument, 0, 'm'},
	{"tid", required_argument, 0, 't'},
	{"sid", required_argument, 0, 's'},
	{"cid", required_argument, 0, 'c'},
	{"lun", required_argument, 0, 'l'},
	{"name", required_argument, 0, 'n'},
	{"user", required_argument, 0, 'u'},
	{"pass", required_argument, 0, 'p'},
	{"global", no_argument, 0, 'g'},
	{"version", no_argument, 0, 'v'},
	{"help", no_argument, 0, 'h'},
	{0, 0, 0, 0},
};

static void usage(int status)
{
	if (status != 0)
		fprintf(stderr, "Try `%s --help' for more information.\n", program_name);
	else {
		printf("Usage:\n");
		printf("%s --mode add --tid=[id] --name=[name]               Add a new target\n", program_name);
		printf("%s --mode add --tid=[id] --sid=[id] --lun=[lun]      Add a new volume\n", program_name);
		printf("%s --mode add --tid=[id] --user=[name] --pass=[pass] Add a new account to the target\n", program_name);
		printf("%s --mode add --global --user=[name] --pass=[pass]   Add a new account for discovery sessions\n", program_name);
		printf("%s --mode del all                                    Stop all activity\n", program_name);
		printf("%s --mode del --tid=[id] --sid=[id] --cid=[id]       Delete a connection\n", program_name);
	}
	exit(status == 0 ? 0 : -1);
}

static int str_to_mode(char *str)
{
	int mode;

	if (!strcmp("add", str))
		mode = MODE_ADD;
	else if (!strcmp("del", str))
		mode = MODE_DEL;
	else
		mode = -1;

	return mode;
}

static int ietd_request(int fd, struct ietadm_request *req)
{
	int err;

	if ((err = write(fd, req, sizeof(*req))) != sizeof(*req)) {
		fprintf(stderr, "%s %d %d\n", __FUNCTION__, __LINE__, err);
		if (err >= 0)
			err = -EIO;
	}
	return err;
}

static int ietd_response(int fd)
{
	int err;
	struct ietadm_response res;

	if ((err = read(fd, &res, sizeof(res))) != sizeof(res)) {
		fprintf(stderr, "%s %d %d\n", __FUNCTION__, __LINE__, err);
		if (err >= 0)
			err = -EIO;
	} else
		err = res.err;

	return err;
}

static int ietd_connect(void)
{
	int fd, err;
	struct sockaddr_un addr;

	fd = socket(AF_LOCAL, SOCK_STREAM, 0);
	if (fd < 0)
		return fd;

	memset(&addr, 0, sizeof(addr));
	addr.sun_family = AF_LOCAL;
	memcpy((char *) &addr.sun_path + 1, IETADM_NAMESPACE, strlen(IETADM_NAMESPACE));

	if ((err = connect(fd, (struct sockaddr *) &addr, sizeof(addr))) < 0)
		fd = err;

	return fd;
}

static int target_handle(int mode, u32 tid, char *name, char *alias)
{
	int fd = -1, err = -EINVAL;
	struct ietadm_request req;

	if (mode == MODE_DEL) {
		fprintf(stderr, "Unsupported.\n");
		goto out;
	}
	if (!name) {
		fprintf(stderr, "You must specify a name.\n");
		goto out;
	}
	if (strlen(name) + 1 > ISCSI_NAME_LEN) {
		fprintf(stderr, "Too long name.\n");
		goto out;
	}

	if ((fd = ietd_connect()) < 0) {
		err = fd;
		goto out;
	}

	memset(&req, 0, sizeof(req));
	req.command = C_TARGET_ADD;
	req.tid = tid;
	strncpy(req.u.tadd.name, name, sizeof(req.u.tadd.name) - 1);

	if ((err = ietd_request(fd, &req)) < 0)
		goto out;

	err = ietd_response(fd);
out:
	if (fd > 0)
		close(fd);

	if (err < 0)
		fprintf(stderr, "%s %d %d\n", __FUNCTION__, __LINE__, err);
	return err;
}

static int volume_handle(int mode, u32 tid, u32 lun, char *path)
{
	int fd = -1, err = -EINVAL;

	if (mode == MODE_DEL) {
		fprintf(stderr, "Unsupported.\n");
		goto out;
	}

	if (!path)
		goto out;

	if ((fd = ctrdev_open()) < 0) {
		err = fd;
		goto out;
	}

	err = volume_add(fd, tid, lun, path, NULL);
out:
	if (fd > 0)
		close(fd);

	if (err < 0)
		fprintf(stderr, "%s %d %d\n", __FUNCTION__, __LINE__, err);
	return err;
}

static int user_handle(int mode, u32 tid, char *name, char *pass, int global)
{
	int fd = -1, err = -EINVAL;
	struct ietadm_request req;

	if (mode == MODE_DEL) {
		fprintf(stderr, "Unsupported.\n");
		goto out;
	}
	if (!name || !pass)
		goto out;

	if ((fd = ietd_connect()) < 0) {
		err = fd;
		goto out;
	}

	memset(&req, 0, sizeof(req));
	req.command = C_USER_ADD;
	req.tid = tid;
	req.u.uadd.global = global;
	strncpy(req.u.uadd.name, name, sizeof(req.u.uadd.name) - 1);
	strncpy(req.u.uadd.pass, pass, sizeof(req.u.uadd.pass) - 1);

	if ((err = ietd_request(fd, &req)) < 0)
		goto out;
	err = ietd_response(fd);
out:
	if (fd > 0)
		close(fd);
	if (err < 0)
		fprintf(stderr, "%s %d %d\n", __FUNCTION__, __LINE__, err);
	return err;
}

static int conn_handle(int mode, u32 tid, u64 sid, u32 cid)
{
	int fd = -1, err = -EINVAL;

	if (mode == MODE_ADD) {
		fprintf(stderr, "Unsupported.\n");
		goto out;
	}

	if ((fd = ctrdev_open()) < 0) {
		err = fd;
		goto out;
	}

	err = conn_close(fd, tid, sid, cid);
out:
	if (fd > 0)
		close(fd);

	if (err < 0)
		fprintf(stderr, "%s %d %d\n", __FUNCTION__, __LINE__, err);
	return err;
}

int main(int argc, char **argv)
{
	int ch, longindex;
	int err = -EINVAL, mode = -1, global = 0;
	u32 id[4], tid = 0, cid = 0, vid = 0;
	u64 sid = 0;
	char *name = NULL, *user = NULL, *pass = NULL;

	memset(id, 0, sizeof(id));

	while ((ch = getopt_long(argc, argv, "m:t:s:c:l:n:u:p:gvh",
				 long_options, &longindex)) >= 0) {
		switch (ch) {
		case 'm':
			mode = str_to_mode(optarg);
			break;
		case 't':
			tid = strtoul(optarg, NULL, 10);
			id[0]++;
			break;
		case 's':
			sid = strtoull(optarg, NULL, 10);
			id[1]++;
			break;
		case 'c':
			cid = strtoul(optarg, NULL, 10);
			id[2]++;
			break;
		case 'l':
			vid = strtoul(optarg, NULL, 10);
			id[3]++;
			break;
		case 'u':
			user = optarg;
			break;
		case 'p':
			pass = optarg;
			break;
		case 'n':
			name = optarg;
			break;
		case 'g':
			global = 1;
			break;
		case 'v':
			version();
			break;
		case 'h':
			usage(0);
			break;
		}
	}

	if (mode < 0) {
		fprintf(stderr, "You must specify the mode\n");
		goto out;
	}

	if (argv[optind] && !strcmp("all", argv[optind])) {
		if (mode != MODE_DEL)
			fprintf(stderr, "%s %d: Unsupported.\n", __FUNCTION__, __LINE__);
		else
			err = server_stop();
		goto out;
	}

	if (user || pass) {
		err = user_handle(mode, tid, user, pass, global);
		goto out;
	}

	if (id[3]) {
		if (!id[0]) {
			fprintf(stderr, "You must specify tid\n");
			exit(-1);
		}
		err = volume_handle(mode, tid, vid, argv[optind]);

	} else if (id[2]) {
		if (!id[0] || !id[1]) {
			fprintf(stderr, "You must specify tid and sid\n");
			exit(-1);
		}

		err = conn_handle(mode, tid, sid, cid);

	} else if (id[0])
		err = target_handle(mode, tid, name, NULL);
	else
		fprintf(stderr, "something wrong\n");
out:
	return err;
}
