/*
 * (C) 2004 FUJITA Tomonori <tomof@acm.org>
 *
 * This code is licenced under the GPL.
 */

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "iscsid.h"

#define CTL_DEVICE	"/dev/ietctl"
#define PROC_SESSION	"/proc/net/iet/session"

struct session_file_operations {
	int (*target_op) (int fd, u32 tid, void *arg);
	int (*session_op) (int fd, u32 tid, u64 sid, void *arg);
	int (*connection_op) (int fd, u32 tid, u64 sid, u32 cid, void *arg);
};

int ctrdev_open(void)
{
	FILE *f = NULL;
	char devname[256];
	char buf[256];
	int devn;
	int ctlfd;

	f = fopen("/proc/devices", "r");
	if (!f) {
		perror("Cannot open control path to the driver\n");
		return -1;
	}

	devn = 0;
	while (!feof(f)) {
		if (!fgets(buf, sizeof (buf), f)) {
			break;
		}
		if (sscanf(buf, "%d %s", &devn, devname) != 2) {
			continue;
		}
		if (!strcmp(devname, "ietctl")) {
			break;
		}
		devn = 0;
	}

	fclose(f);
	if (!devn) {
		printf
		    ("cannot find iscsictl in /proc/devices - "
		     "make sure the module is loaded\n");
		return -1;
	}

	unlink(CTL_DEVICE);
	if (mknod(CTL_DEVICE, (S_IFCHR | 0600), (devn << 8))) {
		printf("cannot create %s %d\n", CTL_DEVICE, errno);
		return -1;
	}

	ctlfd = open(CTL_DEVICE, O_RDWR);
	if (ctlfd < 0) {
		printf("cannot open %s %d\n", CTL_DEVICE, errno);
		return -1;
	}

	return ctlfd;
}

int volume_add(int fd, u32 tid, u32 lun, char *path, char *iomode)
{
	struct volume_info info;
	struct stat s;
	static char default_iomode[] = "fileio";

	if (stat(path, &s) && errno != EOVERFLOW)
		return -errno;

	memset(&info, 0, sizeof(info));

	info.tid = tid;
	info.lun = lun;
	info.major = major(s.st_rdev);
	info.minor = minor(s.st_rdev);

	strncpy(info.path, path, sizeof(info.path) - 1);
	if (iomode)
		strncpy(info.mode, iomode, sizeof(info.mode) - 1);
	else
		strncpy(info.mode, default_iomode, sizeof(info.mode) - 1);

	return ioctl(fd, ADD_VOLUME, &info);
}

int conn_close(int fd, u32 tid, u64 sid, u32 cid)
{
	int err;
	struct conn_info info;

	info.tid = tid;
	info.sid = sid;
	info.cid = cid;

	if ((err = ioctl(fd, DEL_CONN, &info)) < 0)
		err = errno;

	return err;
}

static int __conn_close(int fd, u32 tid, u64 sid, u32 cid, void *arg)
{
	return conn_close(fd, tid, sid, cid);
}

static int target_del(int fd, u32 tid, void *arg)
{
	struct target_info info;
	int err;

	info.tid = tid;
	if ((err = ioctl(fd, DEL_TARGET, &info)) < 0)
		err = errno;

	return err;
}

static int proc_session_parse(int fd, struct session_file_operations *ops, void *arg)
{
	FILE *f;
	char buf[8192], *p;
	u32 tid, cid;
	unsigned long long sid;
	int err;

	if ((f = fopen(PROC_SESSION, "r")) == NULL) {
		fprintf(stderr, "Can't open %s\n", PROC_SESSION);
		return errno;
	}

	while (fgets(buf, sizeof(buf), f)) {
		p = buf;
		while (isspace((int) *p))
			p++;

		if (!strncmp(p, "tid:", 4)) {
			if (sscanf(p, "tid:%u", &tid) != 1)
				break;
			if (ops->target_op)
				if ((err = ops->target_op(fd, tid, arg)) < 0)
					goto out;

		} else if (!strncmp(p, "sid:", 4)) {
			if (sscanf(p, "sid:%llu", &sid) != 1)
				break;
			if (ops->session_op)
				if ((err = ops->session_op(fd, tid, sid, arg)) < 0)
					goto out;

		} else if (!strncmp(p, "cid:", 4)) {
			if (sscanf(p, "cid:%u", &cid) != 1)
				break;
			if (ops->connection_op)
				if ((err = ops->connection_op(fd, tid, sid, cid, arg)) < 0)
					goto out;
		}
	}

	err = 0;
out:
	fclose(f);

	return err;
}

static int session_retry (int fd, u32 tid, u64 sid, void *arg)
{
	return -EAGAIN;
}

static int conn_retry (int fd, u32 tid, u64 sid, u32 cid, void *arg)
{
	return -EAGAIN;
}

struct session_file_operations conn_close_ops = {
	.connection_op = __conn_close,
};

struct session_file_operations shutdown_wait_ops = {
	.session_op = session_retry,
	.connection_op = conn_retry,
};

struct session_file_operations target_del_ops = {
	.target_op = target_del,
};

int server_stop(void)
{
	int fd;

	if ((fd = ctrdev_open()) < 0)
		return fd;

	proc_session_parse(fd, &conn_close_ops, NULL);

	while (proc_session_parse(fd, &shutdown_wait_ops, NULL) < 0)
		sleep(1);

	proc_session_parse(fd, &target_del_ops, NULL);

	close(fd);

	return 0;
}

struct session_conn_close_arg {
	u32 tid;
	u64 sid;
};

static int session_conn_close(int fd, u32 tid, u64 sid, u32 cid, void *opaque)
{
	struct session_conn_close_arg *arg = (struct session_conn_close_arg *) opaque;
	int err;

	if (arg->tid == tid && arg->sid == sid)
		err = conn_close(fd, tid, sid, cid);

	return 0;
}

struct session_file_operations session_conns_close_ops = {
	.connection_op = session_conn_close,
};

int session_conns_close(u32 tid, u64 sid)
{
	int fd, err;
	struct session_conn_close_arg arg = {tid, sid};

	if ((fd = ctrdev_open()) < 0)
		return fd;
	err = proc_session_parse(fd, &session_conns_close_ops, &arg);
	close(fd);

	return err;
}
