/*
 * Copyright (C) 2002-2003 Ardis Technolgies <roman@ardistech.com>
 *
 * Released under the terms of the GNU GPL v2.0.
 */

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "iscsid.h"

#define DEFAULT_NR_WTHREADS	8

struct target *targets;

static int target_next_id;

void *xmalloc(size_t size)
{
	void *ptr;

	if (size == 0)
		;
	ptr = malloc(size);
	if (ptr == NULL)
		;
	return ptr;
}

char *xstrdup(const char *str)
{
	size_t len;
	char *buf;

	len = strlen(str) + 1;
	buf = xmalloc(len);
	memset(buf, 0, len);
	memcpy(buf, str, len - 1);

	return buf;
}

int user_add(u32 tid, char *name, char *pass, int global)
{
	struct user *user;
	struct target *target = NULL;

	log_debug(1, "%u %s %s %d", tid, name, pass, global);

	if (!global)
		if ((target = target_find_id(tid)) == NULL)
			return -ENOENT;

	if (!name || !pass)
		return -EINVAL;

	user = xmalloc(sizeof(*user));
	user->name = xstrdup(name);
	user->password = xstrdup(pass);

	if (global) {
		user->next = iscsi_discover_users;
		iscsi_discover_users = user;
	} else {
		user->next = target->users;
		target->users = user;
	}

	return 0;
}

static void volume_free(struct target_volume *volume)
{
	free(volume->path);
	if (volume->mode)
		free(volume->mode);
	free(volume);
}

static struct target_volume *volume_alloc(struct target *target, u32 lun, char *path, char *mode)
{
	struct target_volume *volume;

	if (!path)
		return NULL;

	volume = xmalloc(sizeof(*volume));
	memset(volume, 0, sizeof(*volume));
	volume->lun = lun;
	volume->path = xstrdup(path);
	if (mode)
		volume->mode = xstrdup(mode);

	volume->next = target->volumes;
	target->volumes = volume;

	return volume;
}

void target_free(struct target *target)
{
	free(target->name);
	free(target);
}

struct target *target_alloc(u32 id, char *name)
{
	struct target *target;

	if (target_find_id(id) || !name || target_find_name(name))
		return NULL;

	target = xmalloc(sizeof(*target));
	memset(target, 0, sizeof(*target));

	target->id = id;
	target->name = xstrdup(name);

	target->default_param = IET_PARAM_INIT;

	target->nr_wthreads = DEFAULT_NR_WTHREADS;
	target->volumes = NULL;

	target->next = targets;
	targets = target;

	return target;
}

#define _SET_PARAM(x) info.x = target->default_param.x

static int target_configure(int fd, struct target *target)
{
	int res;
	struct param_info info;

	info.tid = target->id;

	info.is_target_param = 1;

	_SET_PARAM(flags);
	_SET_PARAM(max_connections);
	_SET_PARAM(max_data_pdu_length);
	_SET_PARAM(max_burst_length);
	_SET_PARAM(first_burst_length);
	_SET_PARAM(default_wait_time);
	_SET_PARAM(default_retain_time);
	_SET_PARAM(max_outstanding_r2t);
	_SET_PARAM(error_recovery_level);

	if ((res = ioctl(fd, ISCSI_PARAM_SET, &info)) < 0)
		fprintf(stderr, "Can't set target param %d %d\n", info.tid, errno);
	return res;
}

int target_add(int fd, u32 tid)
{
	int err = -ENOENT;
	struct target_info info;
	struct target *target;

	if ((target = target_find_id(tid)) == NULL)
		return err;

	memset(&info, 0, sizeof(info));

	info.tid = target->id;
	memcpy(info.name, target->name, sizeof(info.name) - 1);

	info.nr_wthreads = target->nr_wthreads;
	if ((err = ioctl(fd, ADD_TARGET, &info)) < 0) {
		fprintf(stderr, "can't create a target %d %u\n", errno, info.tid);
		return err;
	}

	if ((err = target_configure(fd, target)) < 0)
		fprintf(stderr, "can't configure the target %d %u\n", err, info.tid);

	return err;
}

int target_start(int fd, u32 tid)
{
	int err = -ENOENT;
	struct target *target;

	if ((target = target_find_id(tid)) == NULL)
		return err;

	if ((err = ioctl(fd, START_TARGET, &target->id)) < 0)
		err = errno;
	return err;
}

static char *target_sep_string(char **pp)
{
	char *p = *pp;
	char *q;

	for (p = *pp; isspace(*p); p++)
		;
	for (q = p; *q && !isspace(*q); q++)
		;
	if (*q)
		*q++ = 0;
	else
		p = NULL;
	*pp = q;
	return p;
}

static void target_sep_bool(char **pp, u32 *flags, int mask)
{
	char *p;

	p = target_sep_string(pp);
	if (!p)
		return;
	switch (*p) {
	case 'y': case 'Y':
		*flags |= mask;
		break;
	case 'n': case 'N':
		*flags &= ~mask;
		break;
	}
}

#define BUFSIZE 4096

void config_scan(char *configfile)
{
	FILE *config;
	struct target *target;
	char buf[BUFSIZE];
	char *p, *q;
	int lun, skip;

	config = fopen(configfile, "r");
	if (!config)
		return;

	target = NULL;
	skip = 1;
	while (fgets(buf, BUFSIZE, config)) {
		q = buf;
		p = target_sep_string(&q);
		if (!p || *p == '#')
			continue;

		if (!strcasecmp(p, "Target")) {
			p = target_sep_string(&q);
			if (!p) {
				skip = 1;
				continue;
			}
			skip = 0;
			target = target_find_name(p);
			if (!target) {
				log_debug(1, "creaing target %u: %s", target_next_id, p);
				target = target_alloc(target_next_id++, p);
			}
		} else if (!strcasecmp(p, "Alias")) {
			if (skip)
				continue;
			p = target_sep_string(&q);
			target->alias = strdup(p);
		} else if (!strcasecmp(p, "MaxConnections")) {
			if (skip)
				continue;
/* 			target->default_param.max_connections = strtol(q, &q, 0); */
		} else if (!strcasecmp(p, "MaxSessions")) {
			if (skip)
				continue;
			target->default_param.max_sessions = strtol(q, &q, 0);
		} else if (!strcasecmp(p, "InitialR2T")) {
			if (skip)
				continue;
			target_sep_bool(&q, &target->default_param.flags,
					SESSION_FLG_INITIAL_R2T);
		} else if (!strcasecmp(p, "ImmediateData")) {
			if (skip)
				continue;
			target_sep_bool(&q, &target->default_param.flags,
					SESSION_FLG_IMMEDIATE_DATA);
		} else if (!strcasecmp(p, "MaxRecvDataSegmentLength")) {
			if (skip)
				continue;
			target->default_param.max_data_pdu_length = strtol(q, &q, 0);
		} else if (!strcasecmp(p, "MaxBurstLength")) {
			if (skip)
				continue;
			target->default_param.max_burst_length = strtol(q, &q, 0);
		} else if (!strcasecmp(p, "FirstBurstLength")) {
			if (skip)
				continue;
			target->default_param.first_burst_length = strtol(q, &q, 0);
		} else if (!strcasecmp(p, "DefaultTime2Wait")) {
			if (skip)
				continue;
			target->default_param.default_wait_time = strtol(q, &q, 0);
		} else if (!strcasecmp(p, "DefaultTime2Retain")) {
			if (skip)
				continue;
			target->default_param.default_retain_time = strtol(q, &q, 0);
		} else if (!strcasecmp(p, "MaxOutstandingR2T")) {
			if (skip)
				continue;
			target->default_param.max_outstanding_r2t = strtol(q, &q, 0);
		} else if (!strcasecmp(p, "DataPDUInOrder")) {
			if (skip)
				continue;
			target_sep_bool(&q, &target->default_param.flags,
					SESSION_FLG_DATA_PDU_INORDER);
		} else if (!strcasecmp(p, "DataSequenceInOrder")) {
			if (skip)
				continue;
			target_sep_bool(&q, &target->default_param.flags,
					SESSION_FLG_DATA_SEQUENCE_INORDER);
		} else if (!strcasecmp(p, "ErrorRecoveryLevel")) {
			if (skip)
				continue;
		} else if (!strcasecmp(p, "Wthreads")) {
			if (skip)
				continue;
			target->nr_wthreads = strtol(q, &q, 0);
		} else if (!strcasecmp(p, "Lun")) {
			char *path, *mode;

			if (skip)
				continue;
			lun = strtol(q, &q, 10);
			path = target_sep_string(&q);
			mode = target_sep_string(&q);

			volume_alloc(target, lun, path, mode);
		} else if (!strcasecmp(p, "User")) {
			char *name, *pass;

			name = target_sep_string(&q);
			pass = target_sep_string(&q);

			if (target)
				user_add(target->id, name, pass, 0);
			else
				user_add(0, name, pass, 1);
		}
	}
	fclose(config);

	for (target = targets; target; target = target->next) {
		struct target_volume *volume;

		if (!target->volumes) {
			log_warning("need to shutdown target %s", target->name);
			/* close all sessions */
			continue;
		}

		if (target_add(ctrl_fd, target->id) < 0) {
			log_warning("failed to add target %s", target->name);
			continue;
		}

		while (target->volumes) {
			volume = target->volumes;
			if (volume_add(ctrl_fd, target->id, volume->lun,
				       volume->path, volume->mode) < 0)
				log_warning("failed to add volume%s", volume->path);

			target->volumes = volume->next;

			volume_free(volume);
		}

		/* FIXME: is this a good place to add this? */
		if (use_isns) {
			target->isns_node = initialize_storage_node(target->name, target->alias);
			RegNode(target->isns_node);
		}

		target_start(ctrl_fd, target->id);
	}
}

struct target *target_find_name(const char *name)
{
	struct target *target;

	log_debug(1, "target_find_name: %s", name);
	for (target = targets; target; target = target->next) {
		if (!strcmp(target->name, name))
			break;
	}
	return target;
}

struct target *target_find_id(u32 id)
{
	struct target *target;

	log_debug(1, "target_find_id: %u", id);
	for (target = targets; target; target = target->next) {
		if (target->id == id)
			break;
	}
	return target;
}
