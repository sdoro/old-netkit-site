#ifndef _IET_ADM_H
#define _IET_ADM_H

#define IETADM_NAMESPACE "IET_ABSTRACT_NAMESPACE"
#define IET_NAME_LEN	128

enum ietadm_command {
	C_TARGET_ADD,
	C_USER_ADD,
	C_CONN_CLOSE,
};

struct msg_target_add {
	char name[ISCSI_NAME_LEN];
	char alias[ISCSI_NAME_LEN];
};

struct msg_user_add {
	u32 tid;
	char name[IET_NAME_LEN];
	char pass[IET_NAME_LEN];
	u32 global;
};

struct ietadm_request {
	u32 command;

	u32 tid;
	u64 sid;
	u32 cid;
	u32 lun;

	union {
		struct msg_target_add tadd;
		struct msg_user_add uadd;
	} u;
};

struct ietadm_response {
	int err;
};

#endif
