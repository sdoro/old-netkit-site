#error kernel code not supported on SunOS 4
